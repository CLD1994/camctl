#!/bin/bash
set -uo pipefail
cd /tmp/camctl-pairing-test-contract-20261108
export PYTHONPATH="$PWD/apps/camctl/src"
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PY=/workspaces/camctl/apps/camctl/.venv311/bin/python
"$PY" --version
"$PY" -m pytest -p asyncio -p pytest_mock apps/camctl/tests/integration/devices/test_action6_result_pages.py::test_segmented_formal_adapter_pairs_only_new_files_after_complete_scan -q --junitxml=/tmp/camctl-pairing-test-contract-evidence-20261108/device.xml
result=$?
echo "$result" > /tmp/camctl-pairing-test-contract-evidence-20261108/device.exit
exit "$result"

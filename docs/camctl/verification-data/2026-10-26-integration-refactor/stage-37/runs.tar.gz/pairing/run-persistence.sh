#!/bin/bash
set -uo pipefail
cd /tmp/camctl-pairing-test-contract-20261108
export PYTHONPATH="$PWD/apps/camctl/src"
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
PY=/workspaces/camctl/apps/camctl/.venv311/bin/python
"$PY" --version
"$PY" apps/camctl/scripts/sync_resources.py
sync_status=$?
echo "$sync_status" > /tmp/camctl-pairing-test-contract-evidence-20261108/sync.exit
if [ "$sync_status" -ne 0 ]; then exit "$sync_status"; fi
"$PY" -m pytest -p asyncio -p pytest_mock apps/camctl/tests/integration/persistence/test_segment_result_sets.py apps/camctl/tests/integration/persistence/test_segment_scan_pairing.py -q --durations=0 --junitxml=/tmp/camctl-pairing-test-contract-evidence-20261108/persistence.xml
result=$?
echo "$result" > /tmp/camctl-pairing-test-contract-evidence-20261108/persistence.exit
exit "$result"

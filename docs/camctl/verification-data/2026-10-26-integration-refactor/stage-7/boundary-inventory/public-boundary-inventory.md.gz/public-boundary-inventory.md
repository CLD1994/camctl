# camctl 集成测试公开边界候选清单

## 基准与范围

本清单固定在 `dbea9317ba2821111e0069cfe3e9d1ebb3c99ace`。调查时工作区 HEAD 已是 `47cb7c6b302def953bab5c5d4709c8b6311823fe`；后续 HEAD 修改不作为该快照已解决的证据。候选位置和摘要从 `git show dbea9317:<path>` 读取。650 个 Python 集成测试文件的 SHA-256 与 AST 输入逐文件相同；329 个受跟踪生产 Python 源也从 base 提交中的 Git blob 解析。完整文件路径、SHA-256、字节数、行数、AST 节点数见 JSON 文件摘要清单。

两个指定根中的 Python 集成测试共 650 个：`apps/camctl/tests/integration` 595 个，`tests/integration` 55 个。生产目录另解析 329 个受跟踪 Python 源文件，提取 Runtime 类型/字段和正式消费路径。根集成目录另外有 2 个 TypeScript、4 个 JavaScript 模块和 1 个 C 源；JSON 记录其 base SHA 与行数。当前环境没有 TS/JS/C AST 解析器，因此未做语法树分类，Python 结果不能替代该部分。

## AST 候选统计

以下数字是需要按测试目标复核的候选数量，不是违规数；没有运行测试。待办集合另有 26 个原始词面命中，其中 8 个匹配生产 Runtime 字段，1 个函数属性写入另列为未决候选，17 个由异常链遍历、测试等待列表、测试夹具计数或普通成员积累构成的上下文控制项不计入 Runtime 内部待办状态候选；完整记录在 JSON。

| AST 候选类型 | 位置数 | 文件数 |
| --- | ---: | ---: |
| Runtime 类导入 | 37 | 25 |
| Runtime 类构造 | 37 | 22 |
| Runtime 字段直接写入 | 177 | 38 |
| Runtime 字段 dataclasses.replace | 4 | 3 |
| 仓储 Command 类导入 | 27 | 12 |
| 仓储 Command 类构造 | 52 | 16 |
| 直接调用 Command.plan | 41 | 19 |
| commit_operation 导入 | 85 | 55 |
| commit_operation 调用 | 179 | 53 |
| pending 集合写入或修改 | 9 | 3 |
| 私有 Runtime/辅助函数/推进函数引用 | 13 | 7 |

扫描 Python `Import`/`ImportFrom` 别名和真实调用，包含函数内局部导入；直接别名导入 `commit_operation` 已解析后计数。Runtime 字段候选以生产 Runtime 类型字段集和测试赋值/替换表达式为依据。完整行号、上下文、片段、来源 SHA、分工、分类和未决判断均在 JSON `candidate_locations`。

AST 对局部名字和变量流只做有限静态判断，无法完整推导动态导入、反射、`getattr`、跨函数测试夹具返回类型或条件执行。`possible_deadhelper_import_only` 只表示私有辅助函数的导入名在当前文件没有 AST `Name/Load` 引用，不能单独证明死代码。177 个 Runtime 属性写候选在 38 个文件中，对象真实类型须逐条核对，不能因变量名含 `runtime` 就判定违规。`dataclasses.replace` 只保留运行时变量及其字段匹配的四项候选，分布在三个文件；排除普通 request/event 对象的替换，flow 变量的真实类型仍须复核。

## `commit_operation` 的目标分区

P3 计划第 111–120 行明确指定 `apps/camctl/tests/integration/persistence/test_transactions.py` 为完整事件事务专项，并在第 115 行将 `commit_operation` 称为 private（私有实现）。此文件 29 次直接调用属于计划中的事务内核目标；不能仅凭私有函数名将其定为业务测试违规。P4 计划第 123–125 行列出 `integration/test_commit_recovery.py`；该文件 2 次调用作为提交未知恢复内核目标。

P3/P4 之外的 148 次直接调用保留未决。局部导入的别名已复核，未发现 `transaction_module.commit_operation` 这类模块属性形式的调用。`operations/test_obtain_check_identity.py` 同时通过公开 `OperationRepository.begin_attempt/finish_attempt` 检查业务结果，也存在直接 `BeginAttemptCommand.plan` / `commit_operation` 的拒绝与身份矩阵。应按各测试目标区分；若目标是完整业务行为，可通过 `OperationRepository` 进入。若目标是事务内核或受正式文档支持的事件范围校验，应明确该层契约。

`persistence/test_segment_result_page_inputs.py` 有直接 `SaveResultPageCommand.plan` 和 `commit_operation`；生产代码存在公开 `CaptureRepository.save_result_page`，可作为业务保存行为的迁移目标并保留全部拒绝、边界和重放断言。历史、事件、固定读取事实和分段存储测试也要按目标判断是否使用公开仓储、H1 类型验证或内核专项，不能把 `commit_operation` 私有一项变成全库裁决。

## Runtime 与正式调用方

`outputs/test_cleanup_delete_save_recovery.py` 通过 `cleanup_factory` 调生产 `session_cleanup_assembly`，然后替换 `runtime.outputs` / `runtime.operations` 故障注入端口，再调用 `delete_source_file(runtime, item_id)`。正式清理流程的 `__all__` 导出 `delete_source_file`，但这不自动使 `CleanupRuntime` 内部字段成为公开边界。该候选迁移时必须保留每个数据库故障阶段、原请求重送、实际删除次数与终态断言。

`LocalWorkPort.required_settlements()`、`settle()` 有 `session/service.py` 的正式协议定义，并由生产会话读取实际责任及推进收场。这是合法的正式生产契约，明确不列为违规。`RuntimeDeps/build_runtime/execute_command/close_runtime`、`WorkFileContext`、`FileTaskExecutor`、`Supervisor`、`HostArtifactPort`、`EventContext/validate_event`、`ReadCoverage` 与公开仓储完整操作均列为正式边界对照项。正式 CLI 在 `cli.py` 调用公开生命周期入口；生产会话也直接消费 `LocalWorkPort`。证据路径、行号和 SHA 在 JSON `public_contract_controls`。

## 已分配及未分配候选

以下 22 个文件属于当前四组的分工清单；分工只表示负责人范围，候选仍须依据正式契约复核。

- **outputs**（9 个）：test_cleanup_delete_save_recovery.py、test_cleanup_member_reuse_rejection.py、test_cleanup_query_cancel_before_delete.py、test_cleanup_residual_recovery.py、test_cleanup_round_handoff.py、test_cleanup_terminal_absence.py、test_delete_rejected_error_graph.py、test_error_diagnostics.py、test_result_error_diagnostics.py
- **bootstrap**（8 个）：test_cancel_ready_runtime.py、test_cancel_work_file_first_result.py、test_cleanup_flow.py、test_cleanup_original_config.py、test_cleanup_query_default_recovery.py、test_media_local_settlement.py、test_osmo_file_cleanup.py、test_work_file_history.py
- **capture**（4 个）：test_binding_failure_file_input_recovery.py、test_device_photo_flow.py、test_host_photo_complete_history_recovery.py、test_host_photo_storage.py
- **history**（1 个）：test_report_selection.py

完整分工及 SHA 在 JSON `actor_assignments`；候选文件的分配标记在 `candidate_files` 和各候选记录。未列出的候选保持未分配，不表示已合规或已迁移。`test_binding_failure_keeps_timelapse_files.py`、`test_binding_failure_retained_file_transactions.py` 是先前阶段路径，不算本轮分工；capture 组本轮只含 `test_binding_failure_file_input_recovery.py`。

## 迁移映射和未决项

`.agents/rules/testing.md` 要求集成测试通过文档化的公开函数、对象、命令、协议或文件边界；仅能 import 不代表公开契约。`docs/camctl/module-contracts.md` 说明仓储端口提供完整业务操作，流程通过窄端口合作，SQLite 执行层集中管理连接与事务。建议按目标选择入口：CLI 运行生命周期用 `build_runtime`、`execute_command`、`close_runtime`；尝试操作使用 `OperationRepository.begin_attempt/finish_attempt`；结果页保存使用 `CaptureRepository.save_result_page`；H1 静态事件校验使用 `EventContext/validate_event`，读取完整性使用 `ReadCoverage`。P3/P4 内核目标按计划保留；其它持久化候选先确认目标，再决定仓储公开入口。

私有推进名审查另记录 5 个名称匹配调用：其中 `_settle_local_work` 是一个生产私有会话推进候选，另外四个 `_advance` 是测试文件自有辅助函数，测试辅助函数内走公开 `capture_handler` 或 `advance_winddown`。

仍待逐项确认：177 个 Runtime 字段写的真实对象类型；9 个待办集合写入或清空候选（8 个匹配 Runtime 字段，1 个是 cleanup 测试工厂的函数属性）是否可由公开恢复入口表达；13 个私有辅助函数和 Runtime 引用的实际目标，以及辅助函数是否被使用；未处于 P3/P4 的持久化测试属公开仓储契约、事件事实还是内核目标；TS/JS/C 根集成源的 AST 分类。

调查过程中曾有一次意外广域文本搜索触及 `verification-data` 下的大证据目录；该输出没有纳入候选、统计、摘要哈希或结论，发现后立即停止递归搜索。该目录未被本清单扫描或记录。没有运行测试。

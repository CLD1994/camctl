import json,subprocess,time
from pathlib import Path
p=Path('/tmp/camctl-merge-implement-20261031')
m=json.loads((p/"deployment-command.json").read_text())
start=time.monotonic()
print("run",m["source_commit"],flush=True)
with (p/"deployment-entry.log").open("w") as f:
 r=subprocess.run(m["argv"],cwd=m["cwd"],stdout=f,stderr=subprocess.STDOUT)
(p/"deployment-exit.json").write_text(json.dumps({"exit_code":r.returncode,"entry_wall_seconds":time.monotonic()-start}))
print("exit",r.returncode,"elapsed",time.monotonic()-start,flush=True)
raise SystemExit(r.returncode)

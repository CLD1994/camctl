import json,subprocess,time,os
from pathlib import Path
p=Path('/tmp/camctl-merge-implement-20261031')
m=json.loads((p/"maintenance-command.json").read_text())
start=time.monotonic()
print("run",m["source_commit"],flush=True)
with (p/"maintenance-entry.log").open("w") as f:
 r=subprocess.run(m["argv"],cwd=m["cwd"],env={**os.environ,**m["env"]},stdout=f,stderr=subprocess.STDOUT)
(p/"maintenance-exit.json").write_text(json.dumps({"exit_code":r.returncode,"wall_seconds":time.monotonic()-start}))
print("exit",r.returncode,"elapsed",time.monotonic()-start,flush=True)
raise SystemExit(r.returncode)

#!/usr/bin/env python3
"""External Python 3.11 reproduction of an immediate process-group probe race."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

CHILD_SOURCE = '''\
import multiprocessing as mp
import time
from multiprocessing.shared_memory import SharedMemory

def worker():
    time.sleep(0.001)

if __name__ == "__main__":
    # Leave a small batch of registered segments for the tracker to clean at EOF.
    segments = [SharedMemory(create=True, size=1) for _ in range(256)]
    for segment in segments:
        segment.close()
    process = mp.get_context("spawn").Process(target=worker)
    process.start()
    process.join()
'''
DEFAULT_PYTHON = "/workspaces/camctl/apps/camctl/.venv311/bin/python"


def group_members(pgid: int) -> list[dict[str, object]]:
    result: list[dict[str, object]] = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            stat_fields = (entry / "stat").read_text().rsplit(")", 1)[1].strip().split()
            state, ppid, group = stat_fields[0], int(stat_fields[1]), int(stat_fields[2])
            if group == pgid:
                command = (entry / "cmdline").read_bytes().replace(b"\0", b" ").decode(
                    errors="replace").strip()
                result.append({"pid": int(entry.name), "state": state, "ppid": ppid,
                               "pgid": group, "command": command})
        except (FileNotFoundError, ProcessLookupError, PermissionError, IndexError, ValueError):
            continue
    return sorted(result, key=lambda item: int(item["pid"]))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--python", default=DEFAULT_PYTHON)
    parser.add_argument("--runs", type=int, default=50)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    executable = Path(args.python).resolve()
    if not executable.is_file():
        parser.error(f"Python executable not found: {executable}")

    script = Path(__file__).resolve().with_name("spawn_resource_tracker_child.py")
    script.write_text(CHILD_SOURCE, encoding="utf-8")
    interpreter_version = subprocess.check_output([str(executable), "-V"], text=True).strip()
    command = [str(executable), str(script)]
    observations: list[dict[str, object]] = []

    for index in range(args.runs):
        process = subprocess.Popen(command, start_new_session=True,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        pgid = process.pid
        command_exit = process.wait(timeout=15)
        check_started = time.monotonic_ns()
        try:
            os.killpg(pgid, 0)
            immediate_group_exists = True
        except ProcessLookupError:
            immediate_group_exists = False
        immediate_members = group_members(pgid) if immediate_group_exists else []

        group_gone = not immediate_group_exists
        if immediate_group_exists:
            deadline = time.monotonic() + 2.0
            while time.monotonic() < deadline:
                try:
                    os.killpg(pgid, 0)
                except ProcessLookupError:
                    group_gone = True
                    break
                time.sleep(0.0005)
        observations.append({
            "run": index + 1,
            "command_pid_pgid": pgid,
            "command_exit_code": command_exit,
            "immediate_killpg_zero_succeeded": immediate_group_exists,
            "immediate_members": immediate_members,
            "group_gone_within_2s_without_signal": group_gone,
            "time_from_first_probe_ms": round((time.monotonic_ns() - check_started) / 1e6, 3),
        })

    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    result = {
        "kind": "external_stdlib_resource_tracker_race_diagnostic",
        "command": shlex.join([sys.executable, str(Path(__file__).resolve()),
                                "--python", str(executable), "--runs", str(args.runs),
                                "--output", str(output)]),
        "tested_child_command": command,
        "start_new_session": True,
        "python_version": interpreter_version,
        "child_scenario": "256 SharedMemory registrations plus one joined multiprocessing spawn worker; no SIGTERM/SIGKILL sent",
        "immediate_group_hits": sum(bool(item["immediate_killpg_zero_succeeded"]) for item in observations),
        "runs": observations,
    }
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "runs"},
                     ensure_ascii=False, indent=2))
    print(f"full result: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

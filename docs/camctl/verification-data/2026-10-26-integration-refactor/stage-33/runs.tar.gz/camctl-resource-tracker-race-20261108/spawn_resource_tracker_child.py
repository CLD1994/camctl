import multiprocessing as mp
import time
from multiprocessing.shared_memory import SharedMemory

def worker():
    time.sleep(0.001)

if __name__ == "__main__":
    # Leave a small batch of registered segments for the tracker to clean at EOF.
    segments = [SharedMemory(create=True, size=1) for _ in range(256)]
    for segment in segments:
        segment.close()
    process = mp.get_context("spawn").Process(target=worker)
    process.start()
    process.join()

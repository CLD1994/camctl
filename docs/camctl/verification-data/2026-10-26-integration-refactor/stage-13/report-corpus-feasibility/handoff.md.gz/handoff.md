# 4200 动作历史数据样本可行性事实

## 范围与原件保护

本调查只检查节点 `report-4200-1` 的数据库文件：

`/tmp/camctl-resume-20261030/evidence/history-cost-audit/report-4200-1/temp/test_large_window_releases_ove0/state.db`

在复制前后，`lsof` 和 `fuser` 都没有报告打开该数据库或 WAL/SHM 的进程；按准确临时目录检查进程命令行，也没有匹配的 pytest 使用者。复制前的 1 秒稳定性复查、复制完成后的复查及最终复查中，三文件的设备号、inode、字节数、mtime 和 SHA-256 均一致。调查没有用 SQLite 打开原件。

原始三文件逐字节复制到新 scratch：

`/tmp/camctl-resume-20261030/evidence/report-corpus-feasibility/scratch-levaugud/`

复制前哈希与来源一致：主库 `df80224748e0cd267626ff461518307e6f33bb391483c1ec412cd2191989a866`，空 WAL `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`，SHM `fd4c9fda9cd3f9ae7c962b0ddf37232294d55580e1aa165aa06129b8549389eb`。SQLite 只读连接指向 scratch 副本，`mode=ro` 且设置了 `query_only=ON`；查询后副本及原件哈希仍与原始复制值相同。

## 数据规模与身份字段

| 项目 | 副本读取结果 |
|---|---:|
| plans | 3 行 |
| actions | 4206 行；计划 ID 1/2/3 分别有 3/4200/3 个动作 |
| outputs | 4 行 |
| history_transactions | 23 行 |
| history_events | 4244 行；事件 ID 1–4244，事务 ID 1–23 |

主库为 6,483,968 字节（约 6.184 MiB），SQLite 报告 1583 页、每页 4096 字节、空闲页 0；页数乘页大小与主库字节数一致。WAL 为 0 字节，SHM 为 32,768 字节，三文件合计 6,516,736 字节（约 6.215 MiB）。日志模式为 `wal`。

`database_metadata` 只有一行，包含 `application_id=camctl`、`instance_id=6f883c5103f940f4ae2a1c91a3cfc460`、`format_version=5`，以及 `staging_path`、`ready_path`、`processing_path` 三个路径字段。它们当前分别为 `/srv/camctl/staging`、`/srv/camctl/ready`、`/srv/camctl/processing`。

可核对版本字段包括 SQLite `PRAGMA schema_version=114`、`user_version=0`、`application_id=0`，表内 `database_metadata.format_version=5`，以及 `history_events.event_version=1`（4244 行全为版本 1）。历史中有 12 种 `event_type`。另有 `entity_snapshots.format_version`、`reports.format_version` 和 `segment_sets.version` 字段。41 张表中没有单独的 schema/config/registry 表，也没有整体登记版本字段；登记兼容性仍需将事件类型和版本与对应代码登记核对。

## 旧临时目录绑定检查

我按表分批扫描 41 张用户表中的 TEXT、CHAR、CLOB、JSON 及 `_json` 字段，每批最多读取 128 行，搜索该节点的完整旧临时目录前缀。`database_metadata`、计划、动作、产物及 `history_events.body_json` 等数据均未发现该前缀，因此旧 pytest temp 绝对路径匹配数为 0，没有路径命中样例可列。

库元数据确实保存上述三个 `/srv/camctl/...` 绝对路径。它们不是本次旧 pytest temp 路径，但说明这份库仍携带部署路径字段；是否影响后续历史读取或跨运行复用，需要由对应消费者确认。

## 一次性压缩诊断

仅对 scratch 主库用 1 MiB 分块、gzip level 6 做了一次压缩和解压：6,483,968 字节压成 749,892 字节；本次本机压缩记录 0.078 秒，解压 0.037 秒，解压后 SHA-256 与原主库相同。它只是该副本的一次读写诊断，不能推导 pytest 47.2 秒准备时间的变化、提速比例或其他运行环境表现。

## 可供讨论的范围

数据库内容具有完整的 4206 动作和 4244 历史事件规模，物理数据量约 6.2 MiB；从体量和数据形状看，值得讨论“真实入口生成一次、历史模块后续只读消费”的样本路线。这里没有实现 fixture 或缓存。

数据库本身不能证明这些状态是由真实公开入口生成，还是由测试支持、仓储事务或直接准备数据写入。此次也没有运行历史模块消费者，不能证明它只读、能跨 `instance_id` 或 `format_version` 复用，或不依赖 `/srv/camctl/...` 路径。跨运行缓存的身份与失效规则、按格式重建时对 23 个事务及事件关系的保留要求都未验证。root 可据此讨论三条路线；本调查不选择缓存策略、不推定失效规则，也不改 4200/4096 或相关断言。

## 产物

- 结构化事实：[facts.json](./facts.json)
- 原始副本与一次性压缩文件保留在上面的 scratch 目录。
- 未运行测试，未修改测试或生产代码。

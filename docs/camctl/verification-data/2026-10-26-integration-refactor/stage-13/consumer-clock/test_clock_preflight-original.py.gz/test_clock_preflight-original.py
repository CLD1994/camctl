import json
import pytest
from integration.support.capture import capture_test_session
from integration.support.result_cases import CaseClock
from integration.capture import result_consumer_fixtures as module
from camctl.persistence.models import DbExecutorError

NOW=module._NOW

@pytest.mark.asyncio
@pytest.mark.parametrize('consumer,wall,mono', [
    ('photo', NOW, 5_000_000_000),
    ('record', NOW+60_000_000, 65_000_000_000),
    ('winddown', NOW+60_000_000, 65_000_000_000),
    ('cancel', NOW+60_000_000, 65_000_000_000),
    ('timelapse', NOW+700_000_000, 5_000_000_000),
])
async def test_world_clock_and_worker(tmp_path, monkeypatch, consumer, wall, mono):
    clock=CaseClock(NOW,5_000_000_000)
    reopened=[]
    original=module.restart_capture_database
    async with capture_test_session():
        async def restart(owned):
            old=await module.capture_database(owned)
            new=await original(owned)
            with pytest.raises(DbExecutorError):
                await old.read(lambda current: 1)
            assert await new.read(lambda current: 1)==1
            reopened.append(True)
            return new
        monkeypatch.setattr(module,'restart_capture_database',restart)
        owned,runtime,action,handler=await module.consumer_world(tmp_path,consumer,clock=clock)
        try:
            assert (clock.wall,clock.monotonic)==(wall,mono)
            assert (runtime.wall_us(),runtime.monotonic_ns())==(wall,mono)
            assert reopened == ([True] if consumer=='timelapse' else [])
            runs=owned.connection.execute('SELECT responsibility_key,attempts_used,max_attempts_used,timeout_s_json,retry_interval_s_json FROM operation_runs ORDER BY id').fetchall()
            attempts=owned.connection.execute('SELECT run_id,attempt_no,status,intent_event_id,result_event_id FROM operation_attempts ORDER BY id').fetchall()
            events=owned.connection.execute('SELECT id,transaction_id,occurred_at FROM history_events ORDER BY id').fetchall()
            assert runs and attempts and events
            assert any(row[1]==1 and row[2]==3 for row in runs)
            assert all(row[2] is not None for row in events)
            print('CLOCK_EVIDENCE',json.dumps({'consumer':consumer,'clock':[clock.wall,clock.monotonic],'runs':runs,'attempts':attempts,'events':events,'restart_confirmed':bool(reopened)},ensure_ascii=False))
        finally:
            owned.connection.close()

@pytest.mark.asyncio
async def test_strict_factory_none_and_input_time(tmp_path):
    seen=[]
    async def strict(owned, *, driver):
        seen.append((owned, driver))
        return None
    async with capture_test_session():
        clock=CaseClock(NOW,5_000_000_000)
        owned,runtime,action,handler=await module.consumer_world(tmp_path,'photo',start=False,
            runtime_factory=strict,clock=clock,now_us=NOW+2_000_000)
        try:
            assert runtime is None and len(seen)==1
            assert (clock.wall,clock.monotonic)==(NOW,5_000_000_000)
            assert owned.connection.execute('SELECT scheduled_at FROM actions WHERE id=?',(action,)).fetchone()==(NOW+2_000_000,)
        finally: owned.connection.close()

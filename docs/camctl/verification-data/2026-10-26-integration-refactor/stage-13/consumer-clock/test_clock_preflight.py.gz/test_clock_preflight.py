import json
from decimal import Decimal
from camctl.operations.attempts import AttemptConfig
from integration.support.result_cases import begin_result_attempt
import pytest
from integration.support.capture import capture_test_session
from integration.support.result_cases import CaseClock
from integration.capture import result_consumer_fixtures as module
from camctl.persistence.models import DbExecutorError

NOW=module._NOW

@pytest.mark.asyncio
@pytest.mark.parametrize('consumer,wall,mono', [
    ('photo', NOW, 5_000_000_000),
    ('record', NOW+60_000_000, 65_000_000_000),
    ('winddown', NOW+60_000_000, 65_000_000_000),
    ('cancel', NOW+60_000_000, 65_000_000_000),
    ('timelapse', NOW+700_000_000, 5_000_000_000),
])
async def test_world_clock_and_worker(tmp_path, monkeypatch, consumer, wall, mono):
    clock=CaseClock(NOW,5_000_000_000)
    reopened=[]
    original=module.restart_capture_database
    async with capture_test_session():
        async def restart(owned):
            old=await module.capture_database(owned)
            new=await original(owned)
            with pytest.raises(DbExecutorError):
                await old.read(lambda current: 1)
            assert await new.read(lambda current: 1)==1
            reopened.append(True)
            return new
        monkeypatch.setattr(module,'restart_capture_database',restart)
        owned,runtime,action,handler=await module.consumer_world(tmp_path,consumer,clock=clock)
        try:
            assert (clock.wall,clock.monotonic)==(wall,mono)
            assert reopened == ([True] if consumer=='timelapse' else [])
            if consumer != 'cancel':
                ticket=begin_result_attempt(owned,action,AttemptConfig(3,Decimal("1.25"),Decimal("2")),clock.wall)
                actual=owned.connection.execute("SELECT attempts_used,max_attempts_used,timeout_s_json,retry_interval_s_json FROM operation_runs WHERE id=?",(ticket.run_id,)).fetchone()
                assert actual == (1,3,'1.25','2')
                intent=owned.connection.execute("SELECT h.occurred_at,t.operation_key FROM operation_attempts a JOIN history_events h ON h.id=a.intent_event_id JOIN history_transactions t ON t.id=h.transaction_id WHERE a.run_id=? AND a.attempt_no=?",(ticket.run_id,ticket.attempt_id)).fetchone()
                assert intent[0] == wall and intent[1]
            runs=owned.connection.execute('SELECT responsibility_key,attempts_used,max_attempts_used,timeout_s_json,retry_interval_s_json FROM operation_runs ORDER BY id').fetchall()
            attempts=owned.connection.execute('SELECT run_id,attempt_no,status,intent_event_id,result_event_id FROM operation_attempts ORDER BY id').fetchall()
            events=owned.connection.execute('SELECT id,transaction_id,occurred_at FROM history_events ORDER BY id').fetchall()
            assert runs and attempts and events
            expected_start = (1,3,'10','3') if consumer in ('record','winddown') else (1,1,'30',None)
            assert runs[0][0] == 'start/1' and runs[0][1:] == expected_start
            if consumer in ('record','winddown','cancel'):
                assert runs[1] == ('stop/1',1,3,'10','3')
            assert all(row[2] is not None for row in events)
            print('CLOCK_EVIDENCE',json.dumps({'consumer':consumer,'clock':[clock.wall,clock.monotonic],'runs':runs,'attempts':attempts,'events':events,'restart_confirmed':bool(reopened)},ensure_ascii=False))
        finally:
            owned.connection.close()

@pytest.mark.asyncio
async def test_strict_factory_none_and_input_time(tmp_path):
    seen=[]
    async def strict(owned, *, driver):
        seen.append((owned, driver))
        return None
    async with capture_test_session():
        clock=CaseClock(NOW,5_000_000_000)
        owned,runtime,action,handler=await module.consumer_world(tmp_path,'photo',start=False,
            runtime_factory=strict,clock=clock,now_us=NOW+2_000_000)
        try:
            assert runtime is None and len(seen)==1
            assert (clock.wall,clock.monotonic)==(NOW,5_000_000_000)
            assert owned.connection.execute('SELECT scheduled_at FROM actions WHERE id=?',(action,)).fetchone()==(NOW+2_000_000,)
        finally: owned.connection.close()

本批START预算表更正

原设计把部分factory的start_config装配默认值3/10/3写成了实际START预算，这个表述不准确。**本批真实photo/timelapse样本的START grant为1/30/None**。三元组依次表示最大次数、调用期限秒数和重试间隔秒数；None保留原义。原audit.json、handoff.md及Stage12压缩件不改，以本更正并列核对。

证据一：已只读核查timelapse-public-start-1/tmp下全部14份state.db。operation_runs中START均为attempts_used=1、max_attempts_used=1、timeout_s_json=30、retry_interval_s_json=NULL；对应operation_attempts也为1/30/NULL。14份均为延时样本，完整相对路径列在correction.json。来源是timelapse-public-start-1/execution.json及result.json（c677基线、14pass收据）；目标测试SHA256为5be3c06f0855662f274ba2ccb53b3f984b55c4e57eb4f23635825e0f79f713af。

证据二：/tmp/camctl-resume-20261030/evidence-consumer-clock/comparison.json的$.photo.runs与$.timelapse.runs中，baseline/current的start/1均为[1,1,"30",null]；列顺序为已用次数、最大次数、期限、重试间隔。$.record.runs则仍为START[1,3,"10","3"]。旧源baseline.json和新源narrow3.json均记录运行前后源码散列稳定；确切PID、源码散列及选中行已收入correction.json。提取SQL与列定义来自同目录test_clock_baseline.py和test_clock_preflight.py。

生产来源是c67742cb13f2e4c116325f3d577d778ff01c42fa的apps/camctl/src/camctl/capture/handlers.py:1131-1139：普通录像才使用self.start_config，其他拍摄START构造max_attempts=1及_start_call_timeout(action)，未提供retry_interval_s，因而保存None。:3014-3026又区分期限来源：本批短调用回退30秒；有output_storage的照片任务及StartReturn.COMPLETED的延时任务使用冻结execution_spec_json里的start_call_timeout_s。不能把本批30秒泛化到所有长COMPLETED设备任务。

PhaseA最早narrow.log里的photo/timelapse两失败来自新诊断的any(row[1]==1 and row[2]==3 for row in runs)断言。该断言把三次额度错误套在仅有一次START的样本上；narrow.json与narrow3.json组件源码散列相同，且old/new comparison预算相等，因此不能据这两失败登记生产问题。

本更正不改变CHECK结论：大型history factory的CHECK3/10/3与consumer默认CHECK3/1.25/2继续分别保留。原record的START1/10/None专例仍须按该consumer及存储契约判断；photo分支能保存None，不代表可以更改record设备配置或把None改成0/3。

本次仅生成correction.json和correction.md；没有新pytest运行、源码或生产修改。correction.json记录原审计及Stage12原件散列，并核对写入更正前后字节相同。

"""报告入选会话：真实受理历史、SQL 页与固定窗口的资源边界。"""
import asyncio
from pathlib import Path
from dataclasses import replace

import pytest

from camctl.contracts.history_values import INITIAL_BOUNDARY
from camctl.contracts.values import ConsistencyError
from camctl.history.queries import ReportScopeRequest
from camctl.persistence.repositories.history import HistoryRepository

from .test_report_scope import (
    _boundary, _finish_action, _submit, _submit_diagnostic, _to_wm, finished_photo,
)
from .test_restore_paths import two_item_world, _grant_item, owned


def _read(selection, entity, parent=None):
    cursor = None
    found = []
    while True:
        page = selection.read_page(entity, parent_id=parent, cursor=cursor)
        found.extend(page.items)
        if page.next_cursor is None:
            return found
        cursor = page.next_cursor


@pytest.mark.asyncio
async def test_selection_pages_preserve_targets_and_necessary_ancestors(finished_photo):
    owned, path = finished_photo
    await _submit(owned, path, '1')
    await _finish_action(owned)
    await _submit(owned, path, '2')
    await _submit_diagnostic(owned, path, 'bad')
    request = ReportScopeRequest(_boundary(owned.connection), 0, _to_wm(owned.connection), 1)
    repository = HistoryRepository(path / 'state.db')
    with repository.open_report_selection(request) as selection:
        assert _read(selection, 'plan') == [1, 2]
        assert _read(selection, 'action', 1) == [1]
        assert _read(selection, 'action', 2) == [2]
        assert _read(selection, 'output', 1) == [1]
        assert _read(selection, 'output', 2) == []
        assert _read(selection, 'delivery', 1) == []
        assert _read(selection, 'diagnostic') == [1]


@pytest.mark.asyncio
async def test_old_h_excludes_new_targets_and_their_ancestors(finished_photo):
    owned, path = finished_photo
    await _submit(owned, path, '1')
    before = _boundary(owned.connection)
    await _submit(owned, path, '2')
    # H 后目录中仍有第二计划的目标；其损坏不能回填或污染旧 H。
    owned.connection.execute('PRAGMA foreign_keys=OFF')
    owned.connection.execute('DELETE FROM plans WHERE id=2')
    request = ReportScopeRequest(before, 0, _to_wm(owned.connection), 1)
    with HistoryRepository(path / 'state.db').open_report_selection(request) as selection:
        assert _read(selection, 'plan') == [1]
        assert _read(selection, 'action', 1) == [1]
        assert _read(selection, 'action', 2) == []
    with HistoryRepository(path / 'state.db').open_report_selection(replace(request, boundary=INITIAL_BOUNDARY)) as selection:
        assert _read(selection, 'plan') == []


@pytest.mark.asyncio
@pytest.mark.parametrize('field,value', [('instance_id', 'other-db'), ('boundary', INITIAL_BOUNDARY),
    ('from_wm', 1), ('to_wm', 9999), ('entity', 'diagnostic'), ('parent_id', 1)])
async def test_cursor_rejects_different_scope_or_parent_role(finished_photo, field, value):
    owned, path = finished_photo
    await _submit(owned, path, '1')
    await _submit(owned, path, '2')
    request = ReportScopeRequest(_boundary(owned.connection), 0, _to_wm(owned.connection), 1)
    with HistoryRepository(path / 'state.db').open_report_selection(request) as selection:
        cursor = selection.read_page('plan').next_cursor
        assert cursor is not None
        with pytest.raises(ConsistencyError):
            selection.read_page('plan', cursor=replace(cursor, **{field: value}))
        assert selection._cache == {}
        with pytest.raises(ConsistencyError):
            selection.read_page('plan')


@pytest.mark.asyncio
@pytest.mark.parametrize('error_type', [RuntimeError, asyncio.CancelledError])
async def test_session_scope_is_readonly_and_exception_exit_releases_candidates(finished_photo, error_type):
    owned, path = finished_photo
    await _submit(owned, path, '1')
    request = ReportScopeRequest(_boundary(owned.connection), 0, _to_wm(owned.connection), 1)
    selection = HistoryRepository(path / 'state.db').open_report_selection(request)
    with pytest.raises(error_type):
        with selection:
            assert _read(selection, 'plan') == [1]
            for field in ('request', 'instance_id'):
                with pytest.raises(AttributeError):
                    setattr(selection, field, None)
            raise error_type('writer stopped')
    assert selection._cache == {}
    with pytest.raises(ConsistencyError):
        selection.read_page('plan')


@pytest.mark.asyncio
async def test_missing_materialized_target_is_not_silently_omitted(finished_photo):
    owned, path = finished_photo
    await _submit(owned, path, '1')
    request = ReportScopeRequest(_boundary(owned.connection), 0, _to_wm(owned.connection), 1)
    # 故障注入：报告目录仍保存动作，但当前必要主行丢失。
    owned.connection.execute('PRAGMA foreign_keys=OFF')
    owned.connection.execute('DELETE FROM actions WHERE id=1')
    with HistoryRepository(path / 'state.db').open_report_selection(request) as selection:
        with pytest.raises(ConsistencyError):
            selection.read_page('action', parent_id=1)


@pytest.mark.asyncio
@pytest.mark.parametrize('cache_budget', [4096, 1])
async def test_delivery_target_only_fills_obtain_ancestors_not_source_entities(two_item_world, monkeypatch, cache_budget):
    from camctl.history import report_selection
    monkeypatch.setattr(report_selection, '_CACHE_LIMIT', cache_budget)
    world = two_item_world
    _grant_item(world, world.item_ids[0])
    from_wm = _to_wm(world.owned.connection)
    _grant_item(world, world.item_ids[1])
    request = ReportScopeRequest(_boundary(world.owned.connection), from_wm, _to_wm(world.owned.connection), 32)
    with world.history.open_report_selection(request) as selection:
        assert _read(selection, 'delivery', 2) == [2]
        assert _read(selection, 'plan') == [2]
        assert _read(selection, 'action', 2) == [2]
        assert _read(selection, 'delivery', 2) == [2]
        assert _read(selection, 'action', 1) == []
        assert _read(selection, 'output', 1) == []
        if cache_budget == 1:
            assert selection._cache['plan'] is None
            assert selection._cache['action'] is None


@pytest.mark.asyncio
@pytest.mark.parametrize('cache_budget', [4096, 0])
@pytest.mark.parametrize('entity,table,row_id,parent', [
    ('action', 'plans', 1, 1),
    ('output', 'actions', 1, 1), ('output', 'plans', 1, 1),
    ('delivery', 'actions', 2, 2), ('delivery', 'plans', 2, 2),
    ('plan', 'plans', 1, None), ('plan', 'actions', 2, None),
    ('action', 'actions', 1, 1), ('output', 'outputs', 2, 1),
    ('delivery', 'deliveries', 2, 2),
    ('diagnostic', 'plan_file_diagnostics', 2, None),
])
async def test_independent_entry_rejects_missing_target_or_any_required_owner(
    two_item_world, tmp_path, monkeypatch, cache_budget, entity, table, row_id, parent,
):
    from camctl.history import report_selection
    monkeypatch.setattr(report_selection, '_CACHE_LIMIT', cache_budget)
    world = two_item_world
    for item in world.item_ids:
        _grant_item(world, item)
    await _submit_diagnostic(world.owned, tmp_path, 'one')
    await _submit_diagnostic(world.owned, tmp_path, 'two')
    request = ReportScopeRequest(_boundary(world.owned.connection), 0, _to_wm(world.owned.connection), 1)
    world.owned.connection.execute('PRAGMA foreign_keys=OFF')
    world.owned.connection.execute(f'DELETE FROM {table} WHERE id=?', (row_id,))
    probe = _QueryProbe(world.history, monkeypatch)
    with world.history.open_report_selection(request) as selection:
        # 每个入口都是第一次读取；不依赖先读根对象，也不交付部分 Page。
        with pytest.raises(ConsistencyError):
            selection.read_page(entity, parent_id=parent)
        assert selection._cache == {}
        with pytest.raises(ConsistencyError):
            selection.read_page(entity, parent_id=parent)
    import gc
    import sqlite3
    gc.collect()
    assert all(reference() is None for reference in probe.candidates)
    for connection in probe.connections:
        with pytest.raises(sqlite3.ProgrammingError):
            connection.execute('SELECT 1')


@pytest.mark.asyncio
@pytest.mark.parametrize('cache_budget', [4096, 0])
async def test_all_five_targets_keep_pages_parent_filter_and_legal_empty(
    two_item_world, tmp_path, monkeypatch, cache_budget,
):
    from camctl.history import report_selection
    monkeypatch.setattr(report_selection, '_CACHE_LIMIT', cache_budget)
    world = two_item_world
    for item in world.item_ids:
        _grant_item(world, item)
    await _submit_diagnostic(world.owned, tmp_path, 'one')
    await _submit_diagnostic(world.owned, tmp_path, 'two')
    request = ReportScopeRequest(_boundary(world.owned.connection), 0, _to_wm(world.owned.connection), 1)
    cases = [('plan', [(None, [1, 2])]), ('action', [(1, [1]), (2, [2]), (999, [])]),
             ('output', [(1, [1, 2]), (2, []), (999, [])]),
             ('delivery', [(1, []), (2, [1, 2]), (999, [])]), ('diagnostic', [(None, [1, 2])])]
    for entity, parents in cases:
        with world.history.open_report_selection(request) as selection:
            for parent, expected in parents:
                assert _read(selection, entity, parent) == expected
            assert (selection._cache[entity] is None) == (cache_budget == 0)
        # 无窗口候选时，即使 caller 的父 ID 不存在也仍是合法空页。
        with world.history.open_report_selection(replace(request, from_wm=request.to_wm)) as selection:
            assert _read(selection, entity, 999 if parents[0][0] is not None else None) == []


@pytest.mark.asyncio
@pytest.mark.parametrize('table', ['actions', 'plans'])
async def test_late_corruption_is_visible_before_candidate_limit(finished_photo, monkeypatch, table):
    from camctl.history import report_selection
    monkeypatch.setattr(report_selection, '_CACHE_LIMIT', 1)
    owned, path = finished_photo
    _submit_many(owned, 8, 1)
    await _finish_many(owned, 8)
    _submit_many(owned, 2, 2)
    await _finish_many(owned, 3, action_id=9)
    request = ReportScopeRequest(_boundary(owned.connection), 0, _to_wm(owned.connection), 1)
    owned.connection.execute('PRAGMA foreign_keys=OFF')
    owned.connection.execute(f'DELETE FROM {table} WHERE id=?', (9 if table == 'actions' else 2,))
    repository = HistoryRepository(path / 'state.db')
    for entity, parent in [('action', 1), ('output', 1)]:
        with repository.open_report_selection(request) as selection:
            # 正常候选已超过 LIMIT=2，损坏 ID 更晚；第一页也必须先失败。
            with pytest.raises(ConsistencyError):
                selection.read_page(entity, parent_id=parent)
            assert selection._cache == {}


@pytest.mark.asyncio
async def test_delivery_window_does_not_validate_unselected_source_reference_chain(two_item_world):
    world = two_item_world
    _grant_item(world, world.item_ids[0])
    from_wm = _to_wm(world.owned.connection)
    _grant_item(world, world.item_ids[1])
    request = ReportScopeRequest(_boundary(world.owned.connection), from_wm, _to_wm(world.owned.connection), 1)
    world.owned.connection.execute('PRAGMA foreign_keys=OFF')
    world.owned.connection.execute('DELETE FROM outputs WHERE id=2')
    world.owned.connection.execute('DELETE FROM actions WHERE id=1')
    world.owned.connection.execute('DELETE FROM plans WHERE id=1')
    with world.history.open_report_selection(request) as selection:
        assert _read(selection, 'delivery', 2) == [2]
        assert _read(selection, 'plan') == [2]
        assert _read(selection, 'action', 2) == [2]
        assert _read(selection, 'output', 1) == []


def _submit_many(owned, count, request_id):
    from camctl.acceptance.input import ParsedInput
    from camctl.acceptance.service import CommandMode, PlanDisposition, ProcessInput
    from camctl.contracts.values import new_operation_key
    from camctl.persistence.models import DbOutcomeKind
    from camctl.persistence.repositories.acceptance import AcceptanceRepository
    from .test_report_scope import _Catalog, _plan_body, _past_schedule
    body = _plan_body(str(request_id), _past_schedule())
    prototype = body['actions'][0]
    body['actions'] = [dict(prototype, name=f'shot-{index}') for index in range(count)]
    result = AcceptanceRepository().process_input(
        ProcessInput(ParsedInput('many.json', body), _Catalog(), CommandMode.RUN, 1),
        new_operation_key(), owned)
    assert result.kind is DbOutcomeKind.COMPLETED, result.error
    assert result.value.plan_disposition is PlanDisposition.REGISTERED, result.value


def _same_readonly_database(database, uri, path):
    """只匹配该状态库的只读 SQLite URI，接受等价的 URI 编码与参数顺序。"""
    import os
    from urllib.parse import parse_qs, unquote, urlsplit

    if not uri:
        return False
    raw = os.fsdecode(database)
    parts = urlsplit(raw)
    if parts.scheme != 'file' or parts.netloc not in ('', 'localhost'):
        return False
    if parse_qs(parts.query).get('mode') != ['ro']:
        return False
    try:
        return os.path.samefile(unquote(parts.path), path)
    except (FileNotFoundError, OSError):
        return False


class _QueryProbe:
    """在目标状态库的业务短读连接上观察分页与资源收场。"""
    def __init__(self, repository, monkeypatch):
        import sqlite3
        import weakref
        path = repository.path.resolve()
        original_connect = sqlite3.connect
        self.steps = 0
        self.connections = []
        self.sql = []
        self.candidates = []
        probe = self

        class Record:
            def __init__(self, row):
                self.row = row
            def __getitem__(self, key):
                return self.row[key]

        class ObservedConnection(sqlite3.Connection):
            def execute(self, sql, *args, **kwargs):
                was_in_transaction = self.in_transaction
                reads = set()
                statement = [None]
                observed = getattr(self, '_probe_attached', False)
                if observed:
                    def authorize(action, table, column, _database, _source):
                        if action == sqlite3.SQLITE_READ:
                            reads.add((table, column))
                        return sqlite3.SQLITE_OK
                    self.set_authorizer(authorize)
                    self.set_trace_callback(lambda value: statement.__setitem__(0, value))
                try:
                    cursor = super().execute(sql, *args, **kwargs)
                finally:
                    if observed:
                        self.set_authorizer(None)
                if not observed and not was_in_transaction and self.in_transaction:
                    # 状态库完成结构核验后，在业务读事务的边界开始观测。
                    self._probe_attached = True
                    self._probe_kind = None
                    probe.connections.append(self)
                    def row_factory(cursor, row):
                        value = sqlite3.Row(cursor, row)
                        if self._probe_kind == 'candidate':
                            value = Record(value)
                            probe.candidates.append(weakref.ref(value))
                        return value
                    def advance():
                        probe.steps += 100
                        return 0
                    self.set_progress_handler(advance, 100)
                    self.row_factory = row_factory
                elif observed:
                    columns = cursor.description or ()
                    touches_changes = any(table == 'report_entity_changes' for table, _ in reads)
                    kind = ('candidate' if touches_changes and len(columns) == 2 else
                            'page' if touches_changes and len(columns) == 1 else None)
                    self._probe_kind = kind
                    if kind is not None:
                        assert statement[0] is not None
                        probe.sql.append((kind, statement[0]))
                return cursor

        def connect(database, *args, **kwargs):
            if _same_readonly_database(database, kwargs.get('uri'), path):
                assert 'factory' not in kwargs
                kwargs['factory'] = ObservedConnection
            return original_connect(database, *args, **kwargs)

        monkeypatch.setattr(sqlite3, 'connect', connect)


@pytest.fixture
def report_selection_corpus(tmp_path):
    """一次生成的完整库副本；只读历史专项不在每次运行重新受理。"""
    from contextlib import closing
    import gzip
    import hashlib
    import json
    import shutil
    import sqlite3
    import time

    started = time.perf_counter()
    assets = Path(__file__).parent / 'fixtures'
    manifest = json.loads((assets / 'report-selection-4200.json').read_text())
    archive = assets / 'report-selection-4200.sqlite.gz'
    def digest(file):
        hasher = hashlib.sha256()
        with file.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                hasher.update(chunk)
        return hasher.hexdigest()
    assert digest(archive) == manifest['gzip_sha256']
    state = tmp_path / 'state.db'
    with gzip.open(archive, 'rb') as source, state.open('wb') as target:
        shutil.copyfileobj(source, target, 1024 * 1024)
    assert state.stat().st_size == manifest['database_bytes']
    assert digest(state) == manifest['database_sha256']
    uri = f"{state.resolve().as_uri()}?mode=ro"
    connection = sqlite3.connect(uri, uri=True, isolation_level=None)
    try:
        connection.execute('PRAGMA query_only=ON').close()
        assert connection.execute('PRAGMA query_only').fetchone() == (1,)
        assert connection.execute('PRAGMA journal_mode').fetchone() == (manifest['journal_mode'],)
        assert connection.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        metadata = connection.execute('SELECT instance_id,format_version,staging_path,ready_path,processing_path FROM database_metadata').fetchone()
        assert metadata == (manifest['database_instance_id'], manifest['database_format_version'],
                            *manifest['metadata_paths'].values())
        for table, count in manifest['counts'].items():
            assert connection.execute(f'SELECT COUNT(*) FROM {table}').fetchone() == (count,)
        assert [count for _, count in connection.execute(
            'SELECT plan_id,COUNT(*) FROM actions GROUP BY plan_id ORDER BY plan_id')] == manifest['actions_per_plan']
        boundary = _boundary(connection)
        assert (boundary.txn_id, boundary.last_event_id) == (
            manifest['history_boundary']['transaction_id'], manifest['history_boundary']['last_event_id'])
        assert connection.execute('SELECT MAX(id) FROM history_events').fetchone() == (boundary.last_event_id,)
        # 三份计划由各自完整受理事务建立；前一事务末尾就是旧节点的准备边界。
        plans = connection.execute(
            'SELECT p.id,t.id,t.first_event_id,t.last_event_id FROM plans p '
            'JOIN history_events e ON e.id=p.created_event_id '
            'JOIN history_transactions t ON t.id=e.transaction_id ORDER BY p.id').fetchall()
        assert [row[0] for row in plans] == [1, 2, 3]
        def end_of_previous_transaction(txn_id):
            result = connection.execute('SELECT last_event_id FROM history_transactions WHERE id=?',
                                        (txn_id - 1,)).fetchone()
            assert result is not None
            return result[0]
        def watermark(end):
            return int(connection.execute('SELECT COALESCE(MAX(change_seq),0) FROM history_events WHERE id<=?',
                                          (end,)).fetchone()[0])
        early_sparse_wm = watermark(plans[0][3])
        output_boundary = end_of_previous_transaction(plans[1][1])
        output_window_end = watermark(output_boundary)
        early = watermark(end_of_previous_transaction(plans[2][1]))
        output_events = connection.execute('SELECT created_event_id FROM outputs ORDER BY id').fetchall()
        assert len(output_events) == 4
        assert all(plans[0][3] < event_id <= output_boundary for (event_id,) in output_events)
        assert plans[0][3] < output_boundary < plans[1][2] <= plans[1][3] < plans[2][2]
        print('CORPUS_SETUP', {'seconds': time.perf_counter() - started,
            'sha256': manifest['database_sha256'], 'boundary': (boundary.txn_id, boundary.last_event_id),
            'journal': manifest['journal_mode'], 'metadata': metadata,
            'plan_transactions': plans, 'output_boundary': output_boundary,
            'watermarks': (early_sparse_wm, output_window_end, early)}, flush=True)
        yield connection, tmp_path, early_sparse_wm, output_window_end, early
    finally:
        close_started = time.perf_counter()
        connection.close()
        assert digest(state) == manifest['database_sha256']
        assert digest(archive) == manifest['gzip_sha256']
        print('CORPUS_CLOSE', {'seconds_including_hashes': time.perf_counter() - close_started,
            'database_unchanged': True, 'archive_unchanged': True}, flush=True)


@pytest.mark.asyncio
async def test_large_window_releases_overflow_once_and_keyset_pages_do_not_rescan_window(report_selection_corpus, monkeypatch):
    import gc
    import time
    started = time.perf_counter()
    connection, path, early_sparse_wm, output_window_end, early = report_selection_corpus
    request = ReportScopeRequest(_boundary(connection), 0, _to_wm(connection), 17)
    repository = HistoryRepository(path / 'state.db')
    # 前一计划的产物 4 与后一计划的动作 4 共用整数编号；此窗口只包含前一计划的变化。
    assert connection.execute('SELECT source_action_id FROM outputs WHERE id=4').fetchone()[0] == 1
    assert connection.execute('SELECT plan_id FROM actions WHERE id=4').fetchone()[0] == 2
    output_window = replace(request, from_wm=early_sparse_wm, to_wm=output_window_end)
    with repository.open_report_selection(output_window) as selection:
        assert _read(selection, 'output', 1) == [1, 2, 3, 4]
        assert _read(selection, 'output', 2) == []
        assert _read(selection, 'action', 2) == []
    probe = _QueryProbe(repository, monkeypatch)
    with repository.open_report_selection(request) as selection:
        assert _read(selection, 'plan') == [1, 2, 3]
        probe.steps = 0
        first = selection.read_page('action', parent_id=2)
        preflight_steps = probe.steps
        assert first.items == tuple(range(4, 21))
        assert selection._cache['action'] is None
        assert sum(len(rows) for rows in selection._cache.values() if rows is not None) <= 4096
        gc.collect()
        # 仅三份计划候选保留；超限的动作候选已在返回第一页前释放。
        assert sum(reference() is not None for reference in probe.candidates) == 3
        cursor = first.next_cursor
        vm_pages = []
        actual = list(first.items)
        while cursor is not None:
            probe.steps = 0
            page = selection.read_page('action', parent_id=2, cursor=cursor)
            vm_pages.append(probe.steps)
            actual.extend(page.items)
            cursor = page.next_cursor
        assert actual == list(range(4, 4204))
        assert _read(selection, 'action', 3) == [4204, 4205, 4206]
        candidate_sql = [sql for kind, sql in probe.sql if kind == 'candidate']
        assert len(candidate_sql) == 2  # 固定窗口的 plan/action 各一次，跨父对象不重查。
        page_sql = [sql for kind, sql in probe.sql if kind == 'page']
        assert all(' IN (' not in sql for sql in page_sql)
        assert max(vm_pages) < preflight_steps // 8
        from contextlib import closing
        import sqlite3
        with closing(sqlite3.connect(f"{repository.path.resolve().as_uri()}?mode=ro", uri=True,
                                     isolation_level=None)) as connection:
            connection.execute('BEGIN').close()
            plans = tuple(row[3] for row in connection.execute('EXPLAIN QUERY PLAN ' + page_sql[0]))
            candidate_plan = tuple(row[3] for row in connection.execute('EXPLAIN QUERY PLAN ' + candidate_sql[1]))
        assert any('actions_plan_members' in row for row in plans)
        assert any('report_changes_by_entity' in row for row in plans)
        assert not any('TEMP B-TREE FOR ORDER BY' in row for row in plans)
        print({'preflight_vm_steps': preflight_steps, 'page_vm_min': min(vm_pages),
               'page_vm_max': max(vm_pages), 'pages': len(vm_pages) + 1,
               'candidate_queries': len(candidate_sql), 'unrelated_outputs': 4,
               'query_plan': plans, 'candidate_query_plan': candidate_plan})
    gc.collect()
    assert all(reference() is None for reference in probe.candidates)
    import sqlite3
    for connection in probe.connections:
        with pytest.raises(sqlite3.ProgrammingError):
            connection.execute('SELECT 1')
    # 稀疏的末窗口不随当前已有的 4200 个无关动作遍历主表。
    probe.sql.clear()
    probe.steps = 0
    sparse = replace(request, from_wm=early)
    with repository.open_report_selection(sparse) as selection:
        assert _read(selection, 'action', 3) == [4204, 4205, 4206]
        assert _read(selection, 'action', 2) == []
        assert all(kind != 'page' for kind, _ in probe.sql)
    print({'sparse_vm_steps': probe.steps, 'sparse_candidates': len(probe.sql)})
    assert probe.steps < preflight_steps // 8
    probe.sql.clear()
    probe.steps = 0
    with repository.open_report_selection(replace(request, to_wm=early_sparse_wm)) as selection:
        assert _read(selection, 'action', 1) == [1, 2, 3]
        assert _read(selection, 'action', 2) == []
        assert all(kind != 'page' for kind, _ in probe.sql)
    print({'early_sparse_vm_steps': probe.steps})
    assert probe.steps < preflight_steps // 8

    print('CORPUS_CALL', {'seconds': time.perf_counter() - started}, flush=True)


async def _finish_many(owned, count, *, action_id=1):
    import time
    from camctl.capture.handlers import capture_handler
    from camctl.capture.results import FileKind
    from camctl.contracts.values import new_operation_key
    from camctl.persistence.models import DbOutcomeKind
    from camctl.persistence.repositories.scheduling import SchedulingRepository, StartActionRequest
    from .test_report_scope import _ActivityDriver, _PAGE_EVIDENCE
    from ..support.capture import capture_runtime
    from camctl.capture.timelapse import CaptureWaitConfig
    from ..capture.test_capture_contract import ResultsDouble, _entry
    now = int(time.time() * 1_000_000)
    started = SchedulingRepository().start_action(StartActionRequest(action_id, now, now), new_operation_key(), owned)
    assert started.kind is DbOutcomeKind.COMPLETED, started.error
    from camctl.persistence.repositories.scheduling import StartOutcome
    assert started.value.outcome is StartOutcome.STARTED, started.value
    activity_id = owned.connection.execute('SELECT id FROM device_activities WHERE action_id=?', (action_id,)).fetchone()[0]
    runtime = await capture_runtime(
        owned, driver=_ActivityDriver(activity_target=str(activity_id)), evidence=_PAGE_EVIDENCE,
        results=ResultsDouble({activity_id: tuple(_entry(f'photo-{action_id}-{index}', kind=FileKind.PHOTO) for index in range(count))}),
        wall_us=lambda: int(time.time() * 1_000_000), monotonic_ns=time.monotonic_ns,
        wait_config=lambda params: CaptureWaitConfig(target_duration_ms=600_000, driver_margin_ms=0))
    await capture_handler("camera_take_photo")(action_id, runtime)
    assert owned.connection.execute('SELECT COUNT(*) FROM outputs WHERE source_action_id=?', (action_id,)).fetchone()[0] == count


@pytest.mark.asyncio
async def test_initialization_rejects_future_or_partial_h(finished_photo):
    from camctl.contracts.history_values import HistoryBoundary
    owned, path = finished_photo
    await _submit(owned, path, '1')
    await _finish_action(owned)
    boundary = _boundary(owned.connection)
    repository = HistoryRepository(path / 'state.db')
    for wrong in (HistoryBoundary(boundary.txn_id + 1, boundary.last_event_id + 1),
                  HistoryBoundary(boundary.txn_id, boundary.last_event_id - 1)):
        with pytest.raises(ConsistencyError):
            repository.open_report_selection(ReportScopeRequest(wrong, 0, _to_wm(owned.connection), 1))


@pytest.mark.asyncio
async def test_read_failure_and_database_replacement_close_bound_session(finished_photo, monkeypatch):
    from ..persistence.test_runtime import _create_valid_database
    owned, path = finished_photo
    await _submit(owned, path, '1')
    await _submit(owned, path, '2')
    request = ReportScopeRequest(_boundary(owned.connection), 0, _to_wm(owned.connection), 1)
    repository = HistoryRepository(path / 'state.db')
    with repository.open_report_selection(request) as selection:
        cursor = selection.read_page('plan').next_cursor
        import sqlite3
        original_connect = sqlite3.connect
        attempts = []
        def failed_connection(database, *args, **kwargs):
            if _same_readonly_database(database, kwargs.get('uri'), repository.path):
                attempts.append(database)
                raise OSError('read page failure')
            return original_connect(database, *args, **kwargs)
        with monkeypatch.context() as patch:
            patch.setattr(sqlite3, 'connect', failed_connection)
            with pytest.raises(OSError, match='read page failure'):
                selection.read_page('plan', cursor=cursor)
        assert len(attempts) == 1
        assert selection._cache == {}
        with pytest.raises(ConsistencyError):
            selection.read_page('plan')

    # 继续使用原会话和游标，将同一路径替换为另一个完整状态库。
    from camctl.persistence.runtime import DbConfig, DbOpenMode, open_existing
    import os
    state_path = path / 'state.db'
    replacement_path = path / 'replacement.db'
    from contextlib import closing
    try:
        _create_valid_database(replacement_path)
        replacement = open_existing(replacement_path, DbOpenMode.EXISTING_RW, DbConfig())
        with closing(replacement.connection):
            replacement_id = replacement.metadata.instance_id
            assert replacement_id != owned.metadata.instance_id
            replacement_checkpoint = replacement.connection.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()
            assert replacement_checkpoint == (0, 0, 0)
        with repository.open_report_selection(request) as selection:
            cursor = selection.read_page('plan').next_cursor
            assert cursor is not None
            assert selection.instance_id == owned.metadata.instance_id
            assert cursor.instance_id == owned.metadata.instance_id
            assert selection.read_page('plan', cursor=cursor).items == (2,)
            checkpoint = owned.connection.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()
            assert checkpoint == (0, 0, 0)
            owned.connection.close()
            for database in (state_path, replacement_path):
                assert not database.with_name(database.name + '-wal').exists()
                assert not database.with_name(database.name + '-shm').exists()
            os.replace(replacement_path, state_path)
            with pytest.raises(ConsistencyError):
                selection.read_page('plan', cursor=cursor)
            assert selection._cache == {}
            with pytest.raises(ConsistencyError):
                selection.read_page('plan', cursor=cursor)
    finally:
        owned.connection.close()

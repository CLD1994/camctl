#!/bin/sh
exec "/workspaces/camctl/apps/camctl/.venv311/bin/python" "/tmp/camctl-resume-20261031/evidence/file-result-ownership-check/first-temp/test_default_file_consumers_co0/consumer-probe.py" "$@"

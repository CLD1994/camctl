from pathlib import Path
import json
with Path('/tmp/camctl-resume-20261031/evidence/file-result-ownership-check/diagnostic-temp/test_default_file_consumers_co0/consumer-tools.log').open('a') as log: log.write('probe\n')
print(json.dumps({'streams':[{'codec_type':'video'}],'format':{'duration':'75.125'}}))

from pathlib import Path
import sys
with Path('/tmp/camctl-resume-20261031/evidence/file-result-ownership-check/diagnostic-temp/test_default_file_consumers_co0/consumer-tools.log').open('a') as log: log.write('repair\n')
Path(sys.argv[-1]).write_bytes(b'original complete repaired bytes')

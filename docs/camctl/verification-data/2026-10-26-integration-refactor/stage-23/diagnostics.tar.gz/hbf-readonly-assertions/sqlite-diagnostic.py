import importlib.util,pathlib,sqlite3,tempfile
p=pathlib.Path('tests/integration/_hbf_readonly_probe.py')
s=importlib.util.spec_from_file_location('probe',p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
with tempfile.TemporaryDirectory() as d:
 path=pathlib.Path(d)/'test.db'
 with sqlite3.connect(path) as c: c.execute('CREATE TABLE original (value INTEGER)')
 for mode,readonly,expected in [('uri-ro',True,True),('query-only',False,True),('rw',False,False)]:
  c=sqlite3.connect(path.as_uri()+'?mode='+('ro' if readonly else 'rw'),uri=True,isolation_level=None)
  if mode=='query-only': c.execute('PRAGMA query_only=ON')
  before=c.execute('SELECT name,sql FROM sqlite_master ORDER BY name').fetchall()
  q=c.execute('PRAGMA query_only').fetchone()[0]; actual=m.main_database_readonly(c)
  after=c.execute('SELECT name,sql FROM sqlite_master ORDER BY name').fetchall()
  assert actual is expected and before==after and not c.in_transaction
  print(mode,'query_only=',q,'readonly=',actual,'unchanged=',before==after)
  c.close()

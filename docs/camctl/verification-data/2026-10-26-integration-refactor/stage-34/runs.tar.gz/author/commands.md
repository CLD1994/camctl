工作区：/tmp/camctl-withdrawal-session-20261108
基线：4a42c1610e4c938968b535cad1304e36edd1ba46
提交：2a21e0d08f973cdf2f9a929eed9106e76a7f950b
解释器：/workspaces/camctl/apps/camctl/.venv311/bin/python（3.11.17）
资源准备：在工作区运行 `/workspaces/camctl/apps/camctl/.venv311/bin/python apps/camctl/scripts/sync_resources.py`，输出“已同步 28 项包资源”。

以下测试均从工作区根运行，均设置 `PYTHONPATH="$PWD/apps/camctl/src:$PWD/apps/camctl/tests" PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`，Python 命令为上方解释器的 `-m pytest`；退出码与输出分别保存在对应 `.exit` 和 `.log` 文件，JUnit 文件名与日志相同。各结果中的耗时是 pytest 报告的时间。

- red：`-p pytest_asyncio.plugin apps/camctl/tests/unit/outputs/test_withdrawal_session.py -q --junitxml=/tmp/camctl-withdrawal-session-evidence-20261108/red.xml`；新增类型尚不存在，收集时报 ImportError，退出 2。
- green：同一命令将 `red.xml` 改为 `green.xml`；1 passed，0.45 秒，退出 0。
- matrix-first：`-p pytest_asyncio.plugin apps/camctl/tests/integration/bootstrap/test_cancel_ready_runtime.py::test_original_withdrawal_result_is_saved_after_failure -q -x --junitxml=/tmp/camctl-withdrawal-session-evidence-20261108/matrix-first.xml`；9 passed，6.58 秒，退出 0。
- bootstrap-files：`-p pytest_asyncio.plugin apps/camctl/tests/integration/bootstrap/test_cancel_ready_runtime.py apps/camctl/tests/integration/bootstrap/test_cancel_ready_transactions.py -q --junitxml=/tmp/camctl-withdrawal-session-evidence-20261108/bootstrap-files.xml`；31 passed、6 failed，22.76 秒；受限流程引用了普通流程局部变量，退出 1。修正共享装配。
- bootstrap-files-final：同上命令将 `bootstrap-files.xml` 改为 `bootstrap-files-final.xml`；37 passed，36.05 秒，退出 0。
- cancellation-files：`-p pytest_asyncio.plugin apps/camctl/tests/integration/cancellation/test_cancellation_contract.py apps/camctl/tests/integration/cancellation/test_target_types.py -q --junitxml=/tmp/camctl-withdrawal-session-evidence-20261108/cancellation-files.xml`；10 passed，4.58 秒，退出 0。
- publication-unit-repaired：`-p pytest_asyncio.plugin apps/camctl/tests/unit/outputs/test_canceled_publication_isolated.py -q --junitxml=/tmp/camctl-withdrawal-session-evidence-20261108/publication-unit-repaired.xml`；48 passed、15 subtests passed，0.71 秒，退出 0；本文件独立进程执行。
- unit-files：`-p pytest_asyncio.plugin -p pytest_mock apps/camctl/tests/unit/outputs/test_withdrawal_session.py apps/camctl/tests/unit/outputs/test_copy_handoff_database.py apps/camctl/tests/unit/bootstrap/test_flow_events.py -q --junitxml=/tmp/camctl-withdrawal-session-evidence-20261108/unit-files.xml`；13 passed、8 failed，1.55 秒，退出 1。旧替身缺失当前拷贝保存、文件资格、交付状态及取消发起者状态输入。
- unit-files-repaired：同上命令将 `unit-files.xml` 改为 `unit-files-repaired.xml`；21 passed，1.23 秒，退出 0。
- assembly：`-p pytest_asyncio.plugin -p pytest_mock apps/camctl/tests/unit/bootstrap/test_withdrawal_assembly.py -q --junitxml=/tmp/camctl-withdrawal-session-evidence-20261108/assembly.xml`；1 passed，0.71 秒，退出 0。

基线复核在 /opt/devcontainer/.codex/worktrees/de38/camctl、同 Python 和同环境变量下分别执行：

- baseline-unrelated：`-p pytest_asyncio.plugin apps/camctl/tests/unit/outputs/test_canceled_publication_isolated.py::CancelSettlementTests::test_cleaned_photo_cache_preserves_cancel_recovery_identity -q`；1 passed、2 subtests passed、4 subtests failed，2.63 秒，退出 1。缺少检查副本来源协作者隔离；补合法替身后完整隔离文件通过。
- baseline-unit：`-p pytest_asyncio.plugin -p pytest_mock apps/camctl/tests/unit/outputs/test_copy_handoff_database.py apps/camctl/tests/unit/bootstrap/test_flow_events.py -q`；12 passed、8 failed，1.49 秒，退出 1；同上 8 个旧替身失败均被证实存在于基线。

各进程同工作区顺序运行；隔离单元文件单独进程。`source.patch` 是基线到提交的完整差异，`source.sha256` 为其摘要，`commit.txt` 和 `status.txt` 记录提交及工作区状态。没有进行完整组件套件、容量、安装包或真实设备验收。

后续提交 5f8033cd0aedfc4e519e3181de8a727a032eaa47 为故障详情补充断言；`source.patch`、`commit.txt`、`status.txt`、`source.sha256` 更新至这一提交。以下命令与 matrix-first 相同但不带 `-x`，分别使用相应的 XML 路径：

- matrix-error：9 项中 3 passed、6 failed，6.56 秒，退出 1。首次断言错误地要求取消明细详情包含交付错误全部字段；正式契约只允许对应登记的详情字段。
- matrix-error-final：按契约分别核对交付完整错误及取消明细登记详情；9 passed，7.00 秒，退出 0。

增量提交 55d9473adc08d3da6b87be0a01a026d8b3c8bfdf 新增一项取消流程接续见证。以下从同一工作区根使用相同 Python 和环境变量，依次运行：

- bridge：`-p pytest_asyncio.plugin apps/camctl/tests/integration/bootstrap/test_cancel_ready_transactions.py::test_cancel_flow_resumes_committed_unknown_with_original_withdrawal -q --junitxml=/tmp/camctl-withdrawal-session-evidence-20261108/bridge.xml`；1 passed，1.24 秒，退出 0。
- bridge-file：`-p pytest_asyncio.plugin apps/camctl/tests/integration/bootstrap/test_cancel_ready_transactions.py -q --junitxml=/tmp/camctl-withdrawal-session-evidence-20261108/bridge-file.xml`；23 passed，15.68 秒，退出 0。

该测试显式以同一 WithdrawalSession 调用 cancel_flow，并换用同库可靠数据库连接；它不是默认 run 自动恢复的证据。`source.patch`、`commit.txt`、`status.txt`、`source.sha256` 已更新至增量提交。

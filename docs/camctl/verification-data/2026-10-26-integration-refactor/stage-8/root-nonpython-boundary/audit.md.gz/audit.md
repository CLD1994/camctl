# 根集成目录非 Python 边界静态调查

## 基准与方法

本调查固定在 `f44e37ab293a62512bc0bfad431cc89fcec1c19e`，按 `git show <commit>:<path>` 读取七个目标文件。开始时工作树 HEAD 为 `f5e962b1ca2ede79fdca2bd477ca1e751653d860`；分析依据仍是固定的 `f44e37ab` 对象。

本地 TypeScript 7.0.2 的原生同步 API 可取得 JavaScript/TypeScript AST：`API.updateSnapshot`、`getDefaultProjectForFile`、`program.getSourceFile` 和 `getSyntacticDiagnostics`。本地包导出 `./unstable/ast` 与 `./unstable/sync`，旧 `createSourceFile` 不在本地 AST 声明中。六个 TS/MJS 文件共解析 16,610 个 AST 节点、49 个导入声明和 1,221 个调用节点；语法诊断均为 0。随后逐组阅读导入、调用、属性访问、赋值位置、动态导入和正式调用方。AST 解析不证明类型身份、完整数据流或运行行为。

C 文件按实际调用逐项核对公开头文件，并对固定版本临时副本执行 `gcc -std=c11 -Wall -Wextra -Werror -fsyntax-only ...`；退出码为 0。这只是语法检查，不是 C AST、链接、运行或行为验证。没有运行 Node 集成测试或 pytest，也没有构建客户端、执行 camctl 或操作设备。

## 结论摘要

六个 TS/MJS 源没有导出声明，也没有 `eval`、`Function` 构造器或 `Reflect` 调用。`client_driver.ts` 和 `device_capability_browser.ts` 会调用真实 `Application`、`Files` 服务，并在相应场景启动真实 HTTP 服务和 Chromium 页面；它们没有给 `Application.store` 或私有字段赋值。两个驱动在初始化、关闭和读取回执时直接访问 `Application.store` 的方法，这是需要 root 判定的有限边界候选：客户端正式设计约定业务行为与成功证据，但说明内部模块、HTTP 路由和表结构名称由实现决定；根集成 README 又明确记录了真实 `Application`/`Files` 的服务复用。

四个 MJS 文件按正式 README 承担规格、登记或 Schema 检查。它们不证明 camctl 的报告生成器、事件事务提交或历史恢复。`report-dependency-conditions.test.mjs` 使用测试自有解释器读取实际登记文件，明确不模拟 SQL 或历史恢复。它不调用生产报告生成器，也不应被当成生成器集成证据。

C 驱动通过 `camctl_host.h` 声明的注册回调、初始化、提交和领取接口。它的 `exit` 分支直接从 `main` 返回而不调用 `camctl_host_stop`；当前 Python 消费者的收场流程释放回调闸门、终止仍由测试进程持有的子进程组，再终止 C 驱动。因此现有 C 组合是公开 API 调用者，但不能作为优雅 `stop` 行为的覆盖证据。

这些是静态候选和边界说明，不是违规裁决。准确调用点、正式依据、文件摘要及未决项见同目录 JSON。

## 七个文件

| 文件 | SHA-256 | 静态判断 |
| --- | --- | --- |
| `tests/integration/client_driver.ts` | `7335ba4eeb24801ea7c5c5e779ec35d0d2243df1bb876cabd2fda0bce3fd833d` | 测试侧命令入口，使用真实 `Application`/`Files` 服务；`store` 初始化、关闭和部分原始读回是待 root 判定的边界候选。没有私有字段写入。 |
| `tests/integration/device_capability_browser.ts` | `20660f3f69f69d4762d96e30e5f7c6818a190592e1e7e18ecf27cbf453c92b19` | 用真实服务准备事实，再经 HTTP 与浏览器检查能力重载和可见结果；Store 只用于装配、收场及确认保存前后不变。 |
| `tests/integration/event-transitions.test.mjs` | `edf16e55fa9fd0b3f07d77d3adeada4c8b4d59f8b19a50b21d870075e1bee06e` | 读取实际登记、SQL 和枚举，调用事件设计检查器并验证规则反例；README 明确不代表生产事件提交或恢复。 |
| `tests/integration/report-dependencies.test.mjs` | `959a55fc3086e48932424dc5ac21f8f218d5221d0afa1b79b6cd28875d438f35` | 读取实际公共 Schema、登记、枚举、错误和规格 SQL，调用登记检查器；不验证 CLI 生成报告。 |
| `tests/integration/report-dependency-conditions.test.mjs` | `9f061a4cd3a2019d00a12b5e0263d8b63c9ddcf237fad1b0c8e69181a88e90ac` | 独立的测试解释器按实际字段登记检查条件映射；没有导入产品或检查器模块，不模拟 SQL/历史恢复。 |
| `tests/integration/video-coverage-protocol.test.mjs` | `f6b80024f1525ace66ef8d00c0b7d2e8e467754b6e01c07e5774acda88424c46` | 用 Ajv 校验公共状态报告 Schema 中视频覆盖字段的正反例；不证明组件实际输出该格式。 |
| `tests/integration/motor_host_driver.c` | `97ccee2759878164719f5b386d225d54609babf07a704c8d035006ba4ba2be19` | 只调用公开 host 接口，但当前消费者以外部终止做收场，没有验证公开 `camctl_host_stop`。语法检查通过，未链接或运行。 |

## 后续核验建议

后续若要运行，应把设计/Schema 检查与真实生产者集成分开记录；先由 root 确定客户端服务对象和 Store 读回是否属于本次可接受的测试边界，再决定是否调整两个 TS 驱动。对 C host 的停止语义，只有当它属于本轮验收目标时，才需要安排通过公开 `camctl_host_stop` 的调用路径；当前外部强制收场反映的是测试父进程的清理路径。

本报告未扫描大型历史验证证据目录，未重做 Python 文件全量盘点，也未运行任何测试。JSON 记录目标文件与支持文档的完整摘要、AST 计数、调用位置和未决问题。

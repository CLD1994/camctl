# 结果消费者与 host 仓储端口独立评审

结论：最终组合 `c82a7e16415fecbf5135044b973d8e8477d88c72` 在本次三个文件的改动边界内未发现新增阻断项。该组合的完整两文件运行仍有两项原有 HBF-02 失败，因此不能宣称完整门禁通过。只评审最终组合，不接收中间提交 `249ce679` 为独立结果。

## 运行时与恢复边界

`consumer_world` 仅新增末尾可选 `control` 参数；默认分支仍按实际活动 ID 创建原控制替身。新 `_world` 预先传入 `ResultPort`、受约束的控制返回和 `CaseClock`，结果脚本由 `result_driver` 写入 `ResultPort.delegate`，通过原 `session_capture_assembly` 的结果端口进入正式处理器。五类场景仍由原 `consumer_world` 完成准备：photo/timelapse 没有 STOP，record/winddown/cancel 保留 STOP，目录输入和 `3/1.25/2` 结果预算保留。硬编码的控制观察 ID 为 1；这两个测试使用 `independent_activity=False` 且无前置动作，正式受理产生的活动 ID 确为 1。若该装配前提变化，控制脚本必须改为按真实活动 ID 设置。

closed 用例仍先保存完整原结果尝试，再用当前测试会话的 `capture_factory` 在已有 `BusinessDatabase` worker 上创建新工厂及运行时。原 `_runtime(owned, driver=runtime.driver)` 也走同一会话的 `capture_runtime → session.runtime → session.factory`；生产装配将传入的控制端口放入 `runtime.driver`。恢复工厂继续使用同一控制对象、原证据合同、`3/1.25/2` 预算、原时钟 UTC、固定 `5_000_000_000` 纳秒单调钟，且不注入 STOP 或目录端口。新结果端口是独立实例；再次查询设备会触发原断言。timelapse 准备阶段原有的 worker 重启保留，closed 恢复阶段没有新增重启。

时钟输入由源码静态核对：初始 UTC 为 `1750000000000000` 微秒、单调钟为 `5000000000` 纳秒；record/winddown/cancel 准备后分别为 UTC 加 `60000000` 微秒、单调钟加 `60000000000` 纳秒；timelapse 准备后 UTC 加 `700000000` 微秒，单调钟保持原值。留存数据库中的事件 UTC 与基线一致。这不是逐次单调钟读取轨迹，不能仅凭数据库相同推断所有未持久化配置完全等价。

host 的两个未知提交用例在 `save_host_photo_complete` 和 `verify_operation` 公开同步仓储方法上按 action ID 1 限定拦截。`repository_port` 将替身的 `delegate` 转调映射回实际被拦截仓储实例，真实保存仍先完成，随后原未知回执或核实错误按原方式交付；原请求/key、独立核实连接及重试断言不变。`binding_check` 同次设备消失场景未在此提交迁移。

## 验证与限制

AST 对照显示两文件的 19 个测试函数及参数化装饰器不变；三个文件的断言数量分别为 `10→10`、`145→145`、`16→16`。`git diff --check` 通过。冻结运行记录 PID 57266、源码树 `9c2b982a`、完整命令、退出码 1；XML 是 42 节点、40 通过、2 失败，与基线节点和结果映射一致。冻结前后的 `src` 与 `tests` 文件 SHA 清单完全相同，包含本次修改文件，排除清单中说明的缓存文件。评审没有重跑 pytest。

两项失败均在 `test_jpeg_photo_unknown_complete_reuses_original_request_and_pair[raw/jpeg]`，实际 `verify_operation` 的核实连接 `PRAGMA query_only` 为 0，原断言要求 1；基线和冻结运行同样失败。此失败在仓储包装的核实阶段出现，不计作本次新增回归，也不算通过。

作者的 14 对数据库、11 张表对照显示所比字段除随机 `device_activities.task_key` 及其历史表示外一致；排除键、表范围见 `frozen-audit.txt`。数据库对照不能证明单调钟实际调用序列、端口调用轨迹、未纳入表、元数据或文件字节相同。旧基线命令与测试文件脏源码 SHA 记录不完整，不能用本次冻结记录追补。根协调者仍需以统一冻结运行确认组合后的完整受影响范围。

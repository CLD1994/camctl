# 历史测试剩余接口边界调查

只读静态调查；未运行测试，未修改仓库。HEAD `86956015ccd75ae76d34c8185e76a583db2d3f5a`，生产 `apps/camctl/src` 树 `9c2b982aa4050c25646e40b6500ebad3a84a8661`。下述建议未经执行验证，节点数量由装饰器静态计算，不代表收集结果。

## 权威边界与关键发现

- `docs/camctl/module-contracts.md:62-100` 规定 Page 的空页继续、游标绑定、故障不能当成结束，消费者集成测试须验证资源释放和并发提交；`historical-state-query.md:114-181` 规定固定 H、C、短读及候选路径，`implementation.md:206` 规定读取返回前释放查询和事务。`testing.md` 的集成接口边界要求正式公开入口，禁止把私有对象布局或调用图作为功能预期。
- **4096 是正式规格固定的第一版内部工程上限，不是用户配置或对象总数限制。** `docs/camctl/database/report-changes.md:103-126` 规定以关联行数量判断，最多读 4097 条，预查询一次；超限在交付首批前释放并转向按 ID 续读。`historical-state-query.md:181` 明确引用该专题。`implementation.md:71` 的一般容量待细化不能覆盖此专题具体规定。应保留跨阈值真实见证及路径成本，不读取 `_cache` 布局；公开配置不支持 0/1，不能宣称强制模式已等价迁移。
- 静态发现可能的规格差异：`report_selection.py:123-136` 以 DISTINCT/UNION 去重并根据整个会话 `_remaining+1` 设限，规格 `report-changes.md:117-126` 却要求按关联行数、无 DISTINCT。4200 不同动作不足以证伪重复关联的分支。需单独核实输入和 SQL 语义，再与用户讨论；不在此修改生产或声称运行失败。
- 大窗口见证 `test_large_window...` 真实数据为 4200 动作，17 每页，248 页；覆盖完整 ID、父对象、前后稀疏窗口、首批前预检、非重复预查询及每页 SQLite 工作量。它未直接证明重复变化按关联数计量；也不能因为保留结果而宣称保留内存释放、真实超限及性能证据。

## 报告选择：原目标到可行证据

- `test_cursor_rejects_different_scope_or_parent_role` 6 个 field/value：保留篡改后的游标拒绝、会话之后拒绝；删除 `_cache == {}` 仅在以可观察的资源释放补足其责任后。`test_session_scope_is_readonly_and_exception_exit_releases_candidates` 2 类异常：保留只读属性、异常后拒绝；真实只读连接关闭用既有 `_QueryProbe` 连接检查，候选记录弱引用仅反映特定行表示，不能独立替代有界内存证据。
- `test_delivery_target_only_fills_obtain_ancestors_not_source_entities` 4096/1 两节点：保留交付、取得路径的父对象及未选源不出现、重复读取；1 为强制溢出，无法通过配置承接，需讨论用真实超过 4096 的数据或保留局部策略测试，不能直接合并降规模。
- `test_independent_entry_rejects_missing_target_or_any_required_owner` 11 个实体/表/ID/父对象 × 4096/0 = 22 节点：保留每个独立首次入口、缺失目标及祖先、错误不交付部分 Page、会话失效、连接关闭；删除私有字段空断言可用失败后的公开读取和 SQLite 连接关闭替代。0 模式没有公开开关；若想证明真实超限路径中 11 个损坏分区，需每个相同损坏在超限真实只读副本执行，不能用单个大窗口替代所有分区。原记录弱引用有实现相关性，资源证据需分别评价。
- `test_all_five_targets_keep_pages_parent_filter_and_legal_empty` 4096/0 两节点：保留五类对象、各父过滤、每页 1、空范围和不存在父 ID 的合法空页；`_cache[entity]` 属布局断言。0 模式同上需讨论真实超限或局部测试承接。
- `test_late_corruption_is_visible_before_candidate_limit` actions/plans 两节点：保持晚于第一页的必要行缺失与第一页即错误，不能仅从 1 改为默认而假装证明相同溢出路径；可构造 4096 以上真实候选并在同等目标与父范围上损坏晚 ID，再以 Page 抛错观察，准备成本尚未测量。
- `test_read_failure_and_database_replacement_close_bound_session`：SQLite 只读连接异常、真实替换同路径另一状态库、原游标拒绝及会话失效均属公开结果，可保留现有注入及连接资源证据；不需要 `_cache` 断言。`test_old_h...`、目标缺失、初始 H、delivery 不校验未选来源的场景应原样保留。
- `test_large_window_releases_overflow_once_and_keyset_pages_do_not_rescan_window`：保留原语料、页大小、248 页 ID、所有稀疏和同 ID 跨实体目标。现有 sqlite3.connect 包装和 progress/trace 可观察候选及每页 SQL、事务结束/连接关闭和 VM 工作量；避免断言具体内部缓存布局、行包装和私有函数调用次数。精确候选查询一次及索引续读是专题契约，SQL 观察应以表访问、绑定范围和结果/工作量为证，而非固定空格或列序。当前 `_QueryProbe` 依赖列数识别候选/页并以弱引用统计包装行，需验证可否不绑定 SQL 形状地承接；不能用最终 Page 结果断言声称已证明释放或无重扫。保留每页工作量阈值、稀疏窗口及相关查询计划阈值，任何改变须逐项列出覆盖差异。

## 分段历史：原目标到可行证据

- `test_complete_segment_rows_without_legacy_restore` initial/current 两节点：保留两路径所有成员、缺口、范围及主行；`restore_entity` 被替换为失败只是内部调用图。可用真实资源大小/批次测有界行为，但不能单凭结果证明没有全量恢复。
- 两个 `test_current_*between_candidate_pages`：分别在原固定 H 后插入新版本、提交完成；保留 batch_size=1、原旧版本及成员完整/原状态与范围 output_id 未变，以及后续业务事实。原通过 `_read_connection` 第四次退出推进，`calls > 4` 仅证明实现次数。考虑在匹配目标只读 SQLite 连接的事务结束/trace 处确定实际候选页之间同步，再通过独立合法公开仓储输入提交；须先证明提交发生在第一个候选页后、下一页前并确实有剩余候选，避免仅以连接次数替代。SQLite 回调内重入写入或锁争用需设计安全的同步点；尚未验证可行性。完成场景当前 `commit_operation` + `_completion_command` 是否正式仓储边界要先核对，不以私有测试装配宣称业务入口。
- `test_current_near_h_never_decodes_old_history_and_main_reader_is_finite`：20 成员、13 个后续版本、batch 3、同 H 的历史工作量与完整成员；`decode_event_row` 包装和 `_seed_entity_rows` 禁用都绑定实现。`handle.stats['events'] == 0` 是暴露字段但尚未找到文档保证，不能单靠可导入当公开契约；可利用 SQLite trace/authorizer 观察无不必要历史正文读取、每次抓取及数据量，资源量用原相同规模和阈值。无法由 SQL 证明 Python 解码次数，若精确零解码仍要保留，属于局部策略证据或需商讨公开能力。
- `test_candidate_pages_reuse_verified_current_transaction_range`：原 `_connect` 与特定 SQL 字符串统计 ≤2；可在 sqlite3.connect 包装上观察查询种类、事务及工作量，不固定 SQL 字符或强制具体调用次数；复用本身是性能策略，保留现有 ≤2 阈值的必要性与可观察等价需讨论，不应删除当作同等覆盖。
- `test_verified_range_cache_rejects_metadata_or_instance_changes` 3 个 range/previous/instance 损坏：保留 `current_boundary()` 抛 `ConsistencyError`；改用随后实际合法读取/继续检测损坏作为清除资格的外部见证。内部 `_current_range is None` 不能证明本身公开契约。
- `test_connection_failure_cannot_leave_a_new_range_marked_verified`：在真正只读 SQLite connect 上注入失败并恢复后，提供损坏范围、验证实际拒绝而非私有缓存清空。`test_external_view_read_failure_clears_range_qualification` 使用 SQLite authorizer 注入故障，再通过有效业务读和损坏边界检查拒绝；需设计证明同仓储和正确视图，不可直接改 `_current_range`。
- `test_external_restore_view_cannot_borrow_another_instances_verified_range` hit/miss/unbound 三节点：调用方提供数据库 B 的合法连接及相同 H 给 A，三种仓储生命周期均须拒绝。hit 可由公开 `current_boundary()` 建立，unbound 用新仓储；miss 直接写 `_current_range=None` 没有公开控制，单靠重新构造并不能证明与原 miss 等价，需讨论。数据库身份可从公开元数据核对而非 `_instance_id`。
- `test_old_full_action_entry_refuses_segment_growth`：保留 `restore_entity` 与 `restore_primary_at_h` 的拒绝/成功；`restore_within` 文档要求调用方持有该仓储实例读事务。不能以任意 `sqlite3.connect` 推定符合这一内部拥有的事务要求；在不改生产情况下，确认已有公开视图入口后替换，否则视为真实接口/测试可达性缺口，不能悄悄删除该分区。
- `test_empty_filtered_page_continues_and_query_failure_is_not_eof`：保留空页有续游标及下一页版本。原 `handle._db` 删除派生表触发错误，需通过 sqlite3.connect 在目标派生数据库连接设置 authorizer 或代理注入读取失败；必须匹配临时派生库，确认在目标读取阶段才触发，返回错误而非空 Page。生产派生库名和内部表是故障边界识别条件而非功能预期。
- `test_disk_failure_closes_partial_handle_and_does_not_change_business`：原 monkeypatch `_put` 及检查 `_db/_temporary`；可在 sqlite3.connect 创建派生库及实际 SQLite 写入边界注入 disk-full，观察临时目录创建/移除、业务 H 与 5 成员不变。需验证注入发生在部分写入之后且已建立临时文件，避免首次连接失败代替原故障。
- `test_snapshot_maintenance_uses_stream_source`：保留实际 `load_entity_images`、`prepare_snapshot`、完整消费和保存；禁用 `restore_within` 是调用图。流式与有界资源须用原大小、文件/内存测量验证，`chunks` 非 tuple 是具体表示。`test_snapshot_seed_keeps_database_instance_before_bounded_read` 在公开方法之间替换状态库身份，需经 SQLite 外部状态或同步边界控制，不依赖 monkeypatch 被测公开方法推进；需证明时序和错误未变。
- `test_large_growth_crosses_page_and_disk_cache_capacity` 保留 256/2048、batch 7、2046 缺口、原 Python 峰值增长两条门槛、SQLite VM 增长 <12 倍、最大取回 ≤7、快照 chunk ≤65536、实际磁盘 >2 MiB。使用 sqlite3.connect 包装捕获真实派生连接 PRAGMA 和文件体积、关闭、业务库读取度量，替代 `history._connect` 与 `handle._db`；应区分 2 MiB 与 -2048 是现行实现参数/测试见证，不能把精确参数当公开配置。`test_growth...` 16/64/256，峰值 <4,000,000、末值比首值 <1,500,000、projection <3*size+30，同样评估 stats 是否有正式契约，再通过 SQLite 读取量替代；不得静默丢预算。
- `test_owner_child_id_index_avoids_repeated_prefix_reads` 是指定 SQL 和索引的局部性能证据（96 行、步数 <1/3），不是调用历史公开入口；保留为存储索引专项或以实际公开历史读取的同等规模、SQLite 测量替代，不能简单删除。

## 最小实施批次与讨论

1. 先做不改生产、无规模变化的会话失效/游标/各损坏结果：只将私有缓存状态替换为公开读取失败及现有 SQLite 关闭观察，保持全部参数及输入。强制 0/1 的参数仍保留待议，不能将此阶段叫做完整公开迁移。
2. 单独处理分段范围/连接故障及真实跨页并发：先证明 SQLite 同步与错误注入时序，再保留每个原 H 和业务断言。原命中/未命中及 `restore_within` 的正式视图缺口先决定承接方式。
3. 最后对 4200/248 页及 256/2048 容量测试逐条标注原阈值和证据，构造重复关联数越界专项；在能证明等价前保留旧专项，不承诺提速。是否下移纯内部策略、如何承接无公开开关的 0/1 场景均需用户决定。

代码位置和冻结 Git blob：`test_report_selection.py` 5fd808a49f61423cfc40077d90b7c91ae4cf0a85；`test_record_segment_history.py` e856cb1075b96f13d1f23baf054f8355abbe7066；`src/camctl/history/report_selection.py` 39a9005e8c3924717346e02bddeecc2a97ad5b8b；`src/camctl/history/bounded.py` 0a2cea2331d33c5453fce5a80af7ca9e3904e253；`src/camctl/persistence/repositories/history.py` 002f9b0fc9a64cb725275d706d4d071619c6d118；`docs/camctl/database/report-changes.md` 134e4e5535efe75924aaa6584ba34fe73242450c；`historical-state-query.md` cf30a48455a7801abe095b79c1b7461f58b982a2；`module-contracts.md` 648a91f19cf2bc0be0c97d412a1db16d388b8893；`implementation.md` 7a46b807524fad14b8d5c893886b5c2990dab20a；`.agents/rules/testing.md` bec047fdfd6688c80e839cbfd78263ef881a80a2。

### 重复关联与容量口径的影响

例如同一个对象有 4097 条区间内变化关联，规格按 4097 条关联判为超过 4096 并进入按 ID 续读；现有 SQL 去重后可能只交付一个唯一对象候选，因而选择缓存路径。此静态差异针对路径选择和预查询工作量上界的证据，不直接证明最终对象集合或排序错误；SQL 引擎为了去重可能处理多少行或占用多少内存，尚未测量，不能声称有无内存问题。规格要求避免为了少量唯一对象而无界扫描重复关联；此处仍需结合真实执行和完整 SQL 核对。现有大窗口断言 4200 个不同动作、候选查询次数、页工作量、缓存条目及弱引用，未单独构造 4097 条指向同一对象的关联并证明关联数触发溢出，因此不应声称它保护了该重复关联的容量口径。

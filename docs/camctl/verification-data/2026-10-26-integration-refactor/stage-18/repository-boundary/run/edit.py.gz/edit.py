from pathlib import Path
p=Path('apps/camctl/tests/integration/capture')
def load(name): return (p/name).read_text()
def save(name,s): (p/name).write_text(s)
def replace(s,old,new,count=1):
 assert s.count(old)>=count,(old,s.count(old)); return s.replace(old,new,count)
def imports(s): return s.replace('import pytest\n','import pytest\n\nfrom support.repository_ports import repository_port\n',1)
def wrap(s, needle, prefix):
 assert needle in s,needle
 return s.replace(needle, prefix+'\n'+''.join('    '+line if line.strip() else line for line in needle.splitlines(keepends=True)),1)
name='test_binding_failure_keeps_timelapse_files.py';s=imports(load(name))
s=replace(s,'        runtime.capture = saves\n','',3)
s=wrap(s,'        await advance(world.action_id, runtime)\n','        with repository_port(CaptureRepository, saves, ("finish_binding_failure",),\n                matches=lambda _name, args, _kwargs: args[0].action_id == world.action_id):')
s=wrap(s,'        await capture_handler(world.handler)(world.action_id, runtime)\n','        with repository_port(CaptureRepository, saves, ("finish_binding_failure",),\n                matches=lambda _name, args, _kwargs: args[0].action_id == world.action_id):')
s=wrap(s,'        with pytest.raises(ConsistencyError):\n            await capture_handler(world.handler)(world.action_id, runtime)\n','        with repository_port(CaptureRepository, saves, ("finish_binding_failure",),\n                matches=lambda _name, args, _kwargs: args[0].action_id == world.action_id):')
save(name,s)
name='test_binding_failure_retained_file_transactions.py';s=imports(load(name))
s=replace(s,'        runtime.capture = saves\n','',2)
needle='        await capture_handler(world.handler)(world.action_id, runtime)\n'
for _ in range(2):
 # pick first unwrapped occurrence (original line has 8 spaces, nested line has 12)
 s=wrap(s,needle,'        with repository_port(CaptureRepository, saves, ("finish_binding_failure",),\n                matches=lambda _name, args, _kwargs: args[0].action_id == world.action_id):')
save(name,s)
name='test_capture_contract.py';s=imports(load(name))
s=replace(s,'        runtime.capture = spy\n','');s=replace(s,'            recovery.capture = spy\n','')
match='            with repository_port(CaptureRepository, spy, ("save_file_observation",),\n                    matches=lambda _name, args, _kwargs: args[0].observer_action_id == action_id\n                    and args[0].file_identity == "original"):'
s=wrap(s,'            with pytest.raises(ConsistencyError):\n                await capture_handler(handler)(action_id, runtime)\n',match)
s=wrap(s,'            await capture_handler(handler)(action_id, recovery)\n',match)
save(name,s)
name='test_natural_wait_source_transitions.py';s=imports(load(name))
s=replace(s,'    runtime.capture = InterruptedPage()\n','    page_spy = InterruptedPage()\n')
s=wrap(s,"        with pytest.raises(ConsistencyError, match='模拟进程结束'): await advance(aid, runtime)\n", "        with repository_port(CaptureRepository, page_spy, ('save_result_page',),\n                matches=lambda _name, args, _kwargs: args[0].ticket.responsibility_key == f'results/{aid}'):")
save(name,s)
name='test_result_file_fact_saves.py';s=imports(load(name));s=replace(s,'    runtime.capture = spy\n','');s=replace(s,'        resumed.capture = spy\n','')
match='        with repository_port(CaptureRepository, spy, (f"save_file_{stage}",),\n                matches=lambda _name, args, _kwargs: args[2].connection.execute(\n                    "SELECT 1 FROM device_files WHERE id=? AND observer_action_id=? "\n                    "AND json_extract(locator_json, \'$.path\')=?",\n                    (args[0].file_id, action_id, "/DCIM/original.mp4")).fetchone() is not None):'
s=wrap(s,'        try:\n            await _consume(runtime, consumer, action_id, handler)\n        except ConsistencyError:\n            # 正式处理器可在本次停止，原工厂继续拥有完整保存申请。\n            pass\n',match)
s=wrap(s,'        await _consume(resumed, consumer, action_id, handler)\n',match)
save(name,s)

# 覆盖对照

基线和修改后均运行同一五文件，Python 3.11.17、同一生产 src 树 9c2b982aa4050c25646e40b6500ebad3a84a8661；实际命令、PID、时长、退出码见 baseline.json、after.json，完整结果见对应 XML 和日志。共享支持树 9b3ae86c98da39f3e731d950a902a023a077c5c8；tests/support 树 984e573c4be3b506043c7ceae5d8af49f9788e8c，repository_ports.py Git blob 46635059d99889d70cac6358df08cd2a8ae72184。

- 绑定失败收尾：原 `runtime.capture` 的 `finish_binding_failure` 观察／投影、提交前与提交后故障改为同名公开仓储边界，按 action_id 限定；原完整 request、key、发生时刻 formed_at + 5,000,000、设备文件和完整活动、动作、尝试及事务前缀、SQLite 实际故障命中、冷重开及原键重送断言保留。终态重入仍安装观察以证明无第二次保存。
- 绑定文件事务：同一仓储边界按 action_id 限定；预览优先完整目录顺序、原键与所有文件关联、无效输入、部分文件不完整、原动作及运行事实保持原断言。收尾重入同样观察没有重复保存。
- 拍摄合同：`save_file_observation` 按 observer_action_id 与 original 文件身份限定，原投影故障两次、原 key 和请求时间、原连接重开及同 factory 重试、设备调用和记录断言保留。后续真实数据库重启及重新装配的冷恢复仍独立。
- 自然等待：`save_result_page` 按 RESULTS 原责任键限定，在真实提交后交付原异常；原等待时长、单调钟、票据、结果页及恢复前历史边界和冷重开断言保留。
- 文件事实：presence、ownership、completion 三个方法各只拦截原动作与原文件路径对应的文件 id；原三种投影或提交故障及命中、原请求 key 和时间、单次结果读取、真实数据库重开与同 factory 恢复、原文件事实断言保留。

改动未调整参数化规模、时间预算、动作及文件范围或生产源码。具体输入及数据库事实以五文件现存断言和 diff 为准，测试通过数不单独证明覆盖等价。

补充：原绑定准备阶段类级 `close_result_check_unconfirmed` 只拦截对应 action_id，仍先真实提交再交付中断。自然等待的未知页与文件完成保存、未锚定起始的未知页保存分别按 RESULTS 责任键或原动作和原文件定位限定；原首次提交与未知回执次数、实际票据、due 前后时刻、原请求与 key 相等、重开边界和设备调用断言均保持。测试中的其他字段及 SchedulingRepository 类级替换不属于此批修改。

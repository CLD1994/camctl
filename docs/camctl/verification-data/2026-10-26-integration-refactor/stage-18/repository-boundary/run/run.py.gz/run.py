import os, subprocess, time, json, pathlib
root=pathlib.Path('/tmp/camctl-resume-20261030/repository-boundary-finish')
ev=pathlib.Path('/tmp/camctl-resume-20261030/evidence/repository-boundary-finish')
names=['test_binding_failure_keeps_timelapse_files.py','test_binding_failure_retained_file_transactions.py','test_capture_contract.py','test_natural_wait_source_transitions.py','test_result_file_fact_saves.py']
phase=os.environ['PHASE']
argv=['/workspaces/camctl/apps/camctl/.venv311/bin/python','-m','pytest',*[str(root/'apps/camctl/tests/integration/capture'/n) for n in names],'-q',f'--basetemp={ev / (phase+"-tmp")}',f'--junitxml={ev / (phase+".xml")}']
env=os.environ.copy(); env['PYTHONPATH']=f'{root}/apps/camctl/src:{root}/apps/camctl/tests'
start=time.time()
with (ev/(phase+'.log')).open('w') as out:
 p=subprocess.Popen(argv,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 (ev/(phase+'.json')).write_text(json.dumps({'pid':p.pid,'argv':argv,'cwd':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD:apps/camctl/src'],cwd=root,text=True).strip(),'support_tree':subprocess.check_output(['git','rev-parse','HEAD:apps/camctl/tests/integration/support'],cwd=root,text=True).strip(),'start':start},indent=2))
 rc=p.wait()
 meta=json.loads((ev/(phase+'.json')).read_text());meta.update(exit=rc,end=time.time(),elapsed_s=time.time()-start);(ev/(phase+'.json')).write_text(json.dumps(meta,indent=2))

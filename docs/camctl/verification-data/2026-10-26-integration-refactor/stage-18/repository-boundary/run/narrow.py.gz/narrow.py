from pathlib import Path
p=Path('apps/camctl/tests/integration/capture')
f=p/'test_binding_failure_retained_file_transactions.py';s=f.read_text();old='''        original_close = CaptureRepository.close_result_check_unconfirmed
        closed = []

        def close(repository, request, key, save_owned):
            receipt = original_close(repository, request, key, save_owned)
            assert receipt.kind is DbOutcomeKind.COMPLETED, receipt.error
            closed.append((request, key))
            return replace(receipt, handoff_error=_ClosedBeforeBusiness())

        formed_at = runtime.wall_us()
        with monkeypatch.context() as patch:
            patch.setattr(CaptureRepository, "close_result_check_unconfirmed", close)
            with pytest.raises(_ClosedBeforeBusiness):
                await advance(action_id, runtime)
''';new='''        closed = []

        class CloseObserver(CaptureRepository):
            def close_result_check_unconfirmed(self, request, key, save_owned):
                receipt = super().close_result_check_unconfirmed(request, key, save_owned)
                assert receipt.kind is DbOutcomeKind.COMPLETED, receipt.error
                closed.append((request, key))
                return replace(receipt, handoff_error=_ClosedBeforeBusiness())

        formed_at = runtime.wall_us()
        with repository_port(CaptureRepository, CloseObserver(), ("close_result_check_unconfirmed",),
                matches=lambda _name, args, _kwargs: args[0].action_id == action_id):
            with pytest.raises(_ClosedBeforeBusiness):
                await advance(action_id, runtime)
''';assert old in s;s=s.replace(old,new);s=s.replace('import pytest\n\nfrom support.repository_ports import repository_port\nimport pytest_asyncio','import pytest\nimport pytest_asyncio\n\nfrom support.repository_ports import repository_port');f.write_text(s)
f=p/'test_natural_wait_source_transitions.py';s=f.read_text();s=s.replace('from pathlib import Path\n','from pathlib import Path\nfrom types import SimpleNamespace\n',1)
old='''    save = getattr(CaptureRepository, name)
    requests = []
    unknown_count = 1 if save_kind == 'page' else 2
    def uncertain(repository, command, key, connection):
        requests.append((command, key))
        if len(requests) <= unknown_count:
            if committed and len(requests) == 1:
                assert save(repository, command, key, connection).kind is DbOutcomeKind.COMPLETED
            return DbOutcome(DbOutcomeKind.UNKNOWN)
        return save(repository, command, key, connection)
    monkeypatch.setattr(CaptureRepository, name, uncertain)
    try:
''';new='''    requests = []
    unknown_count = 1 if save_kind == 'page' else 2
    observer = SimpleNamespace(delegate=CaptureRepository())
    def uncertain(command, key, connection):
        requests.append((command, key))
        if len(requests) <= unknown_count:
            if committed and len(requests) == 1:
                assert getattr(observer.delegate, name)(command, key, connection).kind is DbOutcomeKind.COMPLETED
            return DbOutcome(DbOutcomeKind.UNKNOWN)
        return getattr(observer.delegate, name)(command, key, connection)
    setattr(observer, name, uncertain)
    def matches(_name, args, _kwargs):
        if save_kind == 'page':
            return args[0].ticket.responsibility_key == f'results/{aid}'
        return args[2].connection.execute(
            "SELECT 1 FROM device_files WHERE id=? AND observer_action_id=? "
            "AND json_extract(locator_json, '$.path')=?",
            (args[0].file_id, aid, '/DCIM/a.OSV')).fetchone() is not None
    try:
''';assert old in s;s=s.replace(old,new,1)
start=s.index('    try:\n        wall[0] = due+100',s.index('async def test_unknown_original_save_crosses_stop'))
end=s.index('    finally:\n        owned.connection.close()',start)
chunk=s[start+len('    try:\n'):end];s=s[:start]+'    try:\n        with repository_port(CaptureRepository, observer, (name,), matches=matches):\n'+''.join('    '+line if line.strip() else line for line in chunk.splitlines(keepends=True))+s[end:]
old='''    save = CaptureRepository.save_result_page
    requests = []
    def uncertain(repository, command, key, connection):
        requests.append((command, key))
        if len(requests) == 1 and save_mode != 'reliable':
            if save_mode == 'after_commit':
                assert save(repository, command, key, connection).kind is DbOutcomeKind.COMPLETED
            return DbOutcome(DbOutcomeKind.UNKNOWN)
        return save(repository, command, key, connection)
''';new='''    requests = []
    observer = SimpleNamespace(delegate=CaptureRepository())
    def uncertain(command, key, connection):
        requests.append((command, key))
        if len(requests) == 1 and save_mode != 'reliable':
            if save_mode == 'after_commit':
                assert observer.delegate.save_result_page(command, key, connection).kind is DbOutcomeKind.COMPLETED
            return DbOutcome(DbOutcomeKind.UNKNOWN)
        return observer.delegate.save_result_page(command, key, connection)
    observer.save_result_page = uncertain
''';assert old in s;s=s.replace(old,new,1)
start=s.index("        monkeypatch.setattr(CaptureRepository, 'save_result_page', uncertain)")
end=s.index('    finally:\n        owned.connection.close()',start)
chunk=s[start:].split('\n',1)[1][:end-start-len(s[start:].split('\n',1)[0])-1]
s=s[:start]+"        with repository_port(CaptureRepository, observer, ('save_result_page',),\n                matches=lambda _name, args, _kwargs: args[0].ticket.responsibility_key == f'results/{aid}'):\n"+''.join('    '+line if line.strip() else line for line in chunk.splitlines(keepends=True))+s[end:]
f.write_text(s)

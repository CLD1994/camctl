import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path('/tmp/camctl-resume-20261030/capture-boundary-combined-next'); out=pathlib.Path('/tmp/camctl-resume-20261030/evidence/capture-boundary-combined-next'); os.chdir(root)
def manifest():
 result={}
 for base in ('apps/camctl/src','apps/camctl/tests'):
  for p in sorted(pathlib.Path(base).rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo'):
    result[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 return result
before=manifest(); (out/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
files=['test_binding_failure_keeps_timelapse_files.py', 'test_binding_failure_retained_file_transactions.py', 'test_capture_contract.py', 'test_natural_wait_source_transitions.py', 'test_result_file_fact_saves.py', 'test_recording_start_runtime.py', 'test_record_file_completion_wait.py', 'test_timelapse_host_timer.py', 'test_action6_control_elapsed.py', 'test_action6_segmented_normal.py', 'test_action6_segmented_recovery.py', 'test_result_consumer_saves.py', 'test_host_photo_flow.py', 'test_action6_lifecycle_recovery.py', 'test_action6_budget_cold_recovery.py', 'test_action6_duplicate_segment_keys.py', 'test_action6_native_cancel_scope.py', 'test_native_segment_completion.py']
argv=['/workspaces/camctl/apps/camctl/.venv311/bin/python','-m','pytest']+['apps/camctl/tests/integration/capture/'+x for x in files]+['-q','--basetemp',str(out/'temp'),'--junitxml',str(out/'result.xml')]
env=os.environ.copy(); env['PYTHONPATH']=str(root/'apps/camctl/src')+':'+str(root/'apps/camctl/tests'); t=time.monotonic()
with (out/'log').open('w') as log:
 p=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt={'pid':p.pid,'argv':argv,'cwd':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'python':sys.version,'pythonpath':env['PYTHONPATH'],'preflight':'import-preflight.log','source_before':'source-before.json','src_tree':subprocess.check_output(['git','rev-parse','HEAD:apps/camctl/src'],text=True).strip(),'started_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()}
 (out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n'); print('pytest PID',p.pid,flush=True)
 code=p.wait()
after=manifest(); (out/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n'); receipt.update(ended_utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),exit=code,wall_s=time.monotonic()-t,source_unchanged=before==after,source_after='source-after.json',git_status=subprocess.check_output(['git','status','--short'],text=True)); (out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n'); print('exit',code,'wall',receipt['wall_s'],'unchanged',receipt['source_unchanged'],flush=True)

import sqlite3, pathlib, json
root=pathlib.Path('/tmp/camctl-resume-20261030/evidence/action6-remaining-clocks')
base=root/'baseline/tmp'; final=root/'final2/tmp'
queries={
 'runs':'select id,action_id,kind,responsibility_key,activity_id,status,attempts_used,max_attempts_used,timeout_s_json,retry_interval_s_json,retry_wait_required from operation_runs order by id',
 'attempts':'select id,run_id,attempt_no,status,max_attempts_used,timeout_s_json,retry_interval_s_json,effect_state from operation_attempts order by id',
 'events':'select id,event_type,occurred_at,clock_status from history_events order by id',
 'activities':'select id,action_id,stop_supported,sent_at,started_at,result_wait_margin_ms,extra_wait_ms_used,expected_check_at,control_elapsed_ns,completion_basis,result_set_state from device_activities order by id',
 'sets':'select id,action_id,activity_id,run_id,current_attempt_id,current_final_page_event_id,source_kind,source_event_id,target_duration_ms,state,member_count,assessment_json from segment_sets order by id',
 'inspections':'select id,action_id,set_id,member_id,source_device_file_id,target_json,budget_json,state,result_json from segment_inspections order by id',
 'files':'select id, identity_key from device_files order by id',
}
paths=sorted(p.relative_to(base) for p in base.glob('*/state.db') if not p.parent.is_symlink()); diffs=[]; lines=[]
for rel in paths:
 a=sqlite3.connect(base/rel); b=sqlite3.connect(final/rel)
 for name,q in queries.items():
  x=a.execute(q).fetchall(); y=b.execute(q).fetchall()
  if x!=y: diffs.append((str(rel),name,x,y))
  lines.append((str(rel),name,len(x),x))
(root/'db-baseline.json').write_text(json.dumps(lines,ensure_ascii=False,indent=2))
(root/'db-differences.json').write_text(json.dumps(diffs,ensure_ascii=False,indent=2))
print('databases',len(paths),'comparisons',len(lines),'differences',len(diffs))
for rel,name,x,y in diffs: print(rel,name,'baseline',x,'final',y)

import ast, pathlib, subprocess
names={'_world','_configured','_sent_world','_sent_runtime','_wait_world','world'}
files=subprocess.check_output(['git','ls-files','*.py'],text=True).splitlines()
for file in files:
 try: tree=ast.parse(pathlib.Path(file).read_bytes(),filename=file)
 except (SyntaxError,ValueError): continue
 for n in ast.walk(tree):
  if isinstance(n,ast.ImportFrom) and n.module and any(x in n.module for x in ('test_recording_start_runtime','test_record_file_completion_wait','test_timelapse_host_timer')):
   print(file,n.lineno,'IMPORT',n.module,[(a.name,a.asname) for a in n.names])
  elif isinstance(n,ast.Attribute) and n.attr in names and isinstance(n.value,ast.Name) and any(x in n.value.id for x in ('record','timelapse','completion')):
   print(file,n.lineno,'ATTRIBUTE',ast.unparse(n))
  elif isinstance(n,ast.Constant) and isinstance(n.value,str) and n.value in names:
   print(file,n.lineno,'STRING',repr(n.value))

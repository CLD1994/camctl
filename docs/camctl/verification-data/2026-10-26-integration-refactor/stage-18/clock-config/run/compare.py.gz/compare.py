import sqlite3,json,pathlib
base=pathlib.Path('/tmp/camctl-resume-20261030/evidence/clock-config-finish')
tables={
'operation_runs':'id,action_id,kind,responsibility_key,activity_id,status,attempts_used,max_attempts_used,timeout_s_json,retry_interval_s_json,retry_wait_required,error_json',
'operation_attempts':'id,run_id,attempt_no,status,max_attempts_used,timeout_s_json,retry_interval_s_json,effect_state,error_json',
'device_activities':'id,action_id,task_key,state_query_supported,stop_supported,safe_repeat_stop,start_return_meaning,completion_mode,ownership_mode,dispatch_state,activity_state,occupancy_state,sent_at,started_at,result_wait_margin_ms,extra_wait_ms_used,expected_check_at,control_elapsed_ns,completion_basis,last_error_json',
'history_events':'id,event_type,event_version,occurred_at,clock_status,change_seq'}
def scan(name):
 result={}
 for p in sorted((base/(name+'-tmp')).glob('*/state.db')):
  try:
   with sqlite3.connect(f'file:{p}?mode=ro',uri=True) as db:
    result[str(p.relative_to(base/(name+'-tmp')))]={k:db.execute('select '+v+' from '+k+' order by id').fetchall() for k,v in tables.items()}
  except sqlite3.Error as e: result[str(p.relative_to(base/(name+'-tmp')))]={'error':str(e)}
 (base/(name+'-db.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
 return result
a,b=scan('baseline'),scan('final'); keys=sorted(a.keys()|b.keys()); differences={k:{'before':a.get(k),'after':b.get(k)} for k in keys if a.get(k)!=b.get(k)}
(base/'db-differences.json').write_text(json.dumps(differences,ensure_ascii=False,indent=2))
print('baseline',len(a),'final',len(b),'different',len(differences));print('\n'.join(differences))

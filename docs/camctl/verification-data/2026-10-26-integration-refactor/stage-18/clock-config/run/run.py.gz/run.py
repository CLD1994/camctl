import os, subprocess, json, time, sys
from pathlib import Path
base=Path('/tmp/camctl-resume-20261030/evidence/clock-config-finish')
name=sys.argv[1]
cmd=['/workspaces/camctl/apps/camctl/.venv311/bin/python','-m','pytest','apps/camctl/tests/integration/capture/test_recording_start_runtime.py','apps/camctl/tests/integration/capture/test_record_file_completion_wait.py','apps/camctl/tests/integration/capture/test_timelapse_host_timer.py','-q','--tb=short','--basetemp',str(base/(name+'-tmp')),'--junitxml',str(base/(name+'.xml'))]
env=os.environ.copy(); env['PYTHONPATH']='apps/camctl/src:apps/camctl/tests'
start=time.time()
with (base/(name+'.log')).open('w') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 (base/(name+'.json')).write_text(json.dumps(dict(pid=p.pid,argv=cmd,cwd=os.getcwd(),head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),start=start,pythonpath=env['PYTHONPATH']),indent=2))
 code=p.wait()
 data=json.loads((base/(name+'.json')).read_text());data.update(exit=code,end=time.time(),elapsed=time.time()-start);(base/(name+'.json')).write_text(json.dumps(data,indent=2))

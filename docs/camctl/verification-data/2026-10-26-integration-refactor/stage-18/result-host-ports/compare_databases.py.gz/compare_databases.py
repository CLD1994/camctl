import sqlite3
from pathlib import Path
base=Path('/tmp/camctl-resume-20261030')
tables=['actions','device_activities','operation_runs','operation_attempts','history_events','device_files','recording_processing','outputs','result_page_files','cancel_items','baseline_read_calls']
ignore={'operation_runs':{'session_key'},'baseline_read_calls':{'call_key','result_save_key'}}
for stem,count in [('test_real_result_consumers_sav',10),('test_closed_result_consumers_u',4)]:
 for i in range(count):
  cs=[]
  for label in ('baseline','final'):
   p=base/f'result-host-ports-{label}'/f'{stem}{i}'/'state.db'
   cs.append(sqlite3.connect(f'file:{p}?mode=ro&immutable=1',uri=True))
  print(stem,i)
  for table in tables:
   cols=[r[1] for r in cs[0].execute(f'pragma table_info({table})') if r[1] not in ignore.get(table,set())]
   sql='select '+','.join('"'+s+'"' for s in cols)+' from '+table+' order by id'
   rows=[c.execute(sql).fetchall() for c in cs]
   if rows[0]!=rows[1]:
    print(' DIFFER',table,'row_counts',len(rows[0]),len(rows[1]))
    for n,(a,b) in enumerate(zip(*rows)):
     diff=[(col,x,y) for col,x,y in zip(cols,a,b) if x!=y]
     if diff: print('  row',n,diff)
  for c in cs:c.close()

# `test_forged_original_page_ownership_rolls_back_whole_group` 单次准备耗时诊断

## 范围与运行记录

本次只在冻结提交 `7e7882fdf2663fba02a4e30eb0c00e75a36ba1b4` 的独立工作树中，诊断 `apps/camctl/tests/integration/persistence/test_segment_file_pairing.py::test_forged_original_page_ownership_rolls_back_whole_group` 的原有30个参数节点。15个 `case` 与 `bounded=False/True` 的矩阵、输入 `_world(tmp_path, [_entry('orphan.LRF')])` 及两条原断言均保留。临时patch只包围准备、快照、目标提交、断言和观察连接关闭计时；AST核对确认参数装饰器与两条断言未变化。

唯一运行由 PID `42687` 启动，Python `3.11.17`、pytest `9.1.1`、SQLite `3.53.1`，进程墙钟 `5.965128s`，JUnit记录测试段 `4.889s`，30 passed。完整 argv、cwd、`PYTHONPATH`、环境、起止时间和预同步资源清单见 `facts.json` 与原始 `run.json`。资源同步得到27个文件、594,015字节，manifest SHA-256 为 `1b67c4e63ea9f413eeafddab96d5470f8d8ee42f798326f152933d36c32b78d9`。

本次只运行这一个pytest目标，没有运行复制原型或第二轮计时。原始JUnit和日志保存在 `results.xml`、`run.log`；临时修改保存在 `patch.diff`。运行时目标文件SHA-256为 `b6c45bb6dfd508537150da9304ffb491195c94256aa09737f99f88bddc1f1185`，恢复后SHA-256为 `9befaa2e3ade947194cb5857d480c86aded8b6f70aceefd2136c327073c2c558`。冻结源、临时patch及其余相关文件的前后SHA都列在 `facts.json`；恢复后独立工作树干净，生产源码未改。

## 分项耗时

以下各项分别取30个参数节点的单次观测。p95采用最近秩法；总和是这30个观测之和。首次准备包含一个 `449.431ms` 的高值，因此只报告本轮实测，不外推稳定性能。

| 阶段 | 总和 | 中位数 | p95 | 最大值 |
| --- | ---: | ---: | ---: | ---: |
| `_world`完整准备 | 3358.669 ms | 100.335 ms | 109.771 ms | 449.431 ms |
| 提交前12表快照 | 9.805 ms | 0.313 ms | 0.482 ms | 0.586 ms |
| 目标 `commit_operation` | 146.332 ms | 4.993 ms | 6.032 ms | 6.397 ms |
| `receipt.kind`断言 | 0.030 ms | 0.001 ms | 0.002 ms | 0.002 ms |
| 提交后快照和相等断言 | 4.441 ms | 0.139 ms | 0.211 ms | 0.265 ms |
| 观察SQLite连接关闭 | 23.604 ms | 0.708 ms | 1.135 ms | 1.210 ms |

`--durations=0`另外记录fixture的teardown阶段：日志显示29条 `0.01s` teardown，另有31项低于 `0.005s` 的duration被pytest汇总隐藏。隐藏项还包括setup，汇总信息无法将隐藏项逐一对应到teardown。持久化目录的autouse fixture每个节点退出 `capture_test_session`；该fixture负责实际worker/supervisor收场。上表的“观察SQLite连接关闭”只是测试函数中的 `owned.connection.close()`，不能代表业务worker关闭耗时。

完整180条计时样本已从原始 `run.log` 提取至 `phase-timings.jsonl`，每行带参数、阶段、路径与操作key，便于复核。

## 准备过程与独立性

冻结源码显示每个节点都调用同一个 `_world` 和同一条 `orphan.LRF` 输入。`_world`调用`consumer_world`后，继续建立结果检查、保存结果页并读取该页。`consumer_world`先新建并初始化状态库，再通过 `accept_input`、`SchedulingRepository`、`capture_runtime` 及真实拍摄处理器建立状态；设备控制输入由契约替身提供。相关位置：

- `test_segment_file_pairing.py:48-63,190-199`
- `result_consumer_fixtures.py:207-216,235-276`
- `persistence/conftest.py:7-11`
- `support/capture.py:80-99,139-177`

因此矩阵节点**使用相同的行为准备来源与参数输入**，但运行时数据不是同一个DB快照：30个节点各自有不同tmp路径、DB文件、数据库实例身份和随机操作key。实际结果页事件号均为19；指定的8张表行数向量在30个库中相同：`device_files=1`、`result_page_files=1`、`history_transactions=11`、`history_events=20`、`operation_runs=3`、`operation_attempts=3`、`actions=1`、`device_activities=1`。30个目标key都不同，且回滚后均未出现在各自历史事务中。两条原断言都通过，证实每个目标提交返回 `rolled_back` 且12表快照与提交前相同。

teardown后用SQLite只读URI `mode=ro&immutable=1` 检查30份实际case库，没有写库。每份DB大小均为819,200字节、格式版本为5，SHA-256彼此不同，journal mode均为`delete`，没有WAL/SHM sidecar。三项绑定路径字段为`staging_path`、`ready_path`、`processing_path`；每份路径都指向各自测试目录，目录仍存在。

## 对“生成一次完整只读来源，再给每个历史用例独立副本”的判断

**同一准备流程重复执行这一点已得到源码和本轮数据支持；复用一份数据库文件是否能保持正式合同，尚未证实。** 文档说明分别初始化的状态库有不同实例身份（`docs/architecture/initialization.md:45-49`）；三个交接目录的规范绝对路径保存在数据库元信息中，运行配置不符时会报错且不会自动重绑（`docs/architecture/configuration.md:97-103`）。本轮30份库的实例身份与这三条路径确实分别不同。将某一库原样复制到另一节点的tmp目录会留下原目录路径；把身份或路径改成副本值又会触及初始化身份及路径绑定规则。如何在复制后维持这些规则，需要另行评审。

现有源库在关闭后是无WAL/SHM sidecar的单个DB文件，这只能说明此次运行留下了单文件形态；没有证明它可直接作为跨运行缓存，也没有证明复制、改写元数据或重新开worker后会被正式入口接受。任何后续实验都需保留每节点的新DB owner/runtime、新操作key及真实worker/supervisor收场，不得共享可变命令或运行时。

准备计时总和约3.36秒，目标提交约0.15秒。这是一轮带计时插桩的诊断数据，不足以证明缓存有收益或保持合同。本报告不实现样本、不改变测试矩阵、不声称优化后时长；是否值得验证复制方案由root判断。

## 输出文件

- `facts.json`：冻结提交、文件哈希、命令环境、原始运行结果、逐阶段统计、30个DB摘要、文档依据和限制。
- `phase-timings.jsonl`：180行原始阶段样本。
- `run.log`、`results.xml`、`run.json`、`patch.diff`：本次原始运行收据和临时计时patch。

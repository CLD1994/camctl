import json
import sys
import time
from pathlib import Path
import pytest

records = []

def trace(frame, event, arg):
    code = frame.f_code
    if code.co_filename.endswith('/tests/integration/test_camctl_report_roundtrip.py') and code.co_name in ('test_state_db_failure_delivers_log_copy', '_run_fault_round'):
        if event in ('call', 'line', 'return', 'exception'):
            records.append({'time': time.monotonic(), 'function': code.co_name, 'line': frame.f_lineno, 'event': event})
        return trace
    return trace

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    previous = sys.gettrace()
    sys.settrace(trace)
    try:
        yield
    finally:
        sys.settrace(previous)
        Path('/tmp/camctl-report-fault-clock-evidence-20261107/after/trace.json').write_text(json.dumps(records, indent=2))

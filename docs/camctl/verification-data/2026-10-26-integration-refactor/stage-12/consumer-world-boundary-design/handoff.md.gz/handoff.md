共享consumer_world准备边界的只读设计

默认ClockPort阶段可以独立推进，不依赖后置预算None等未决语义。现有正式工厂已经支持wall_us和monotonic_ns；问题在于共享测试准备创建工厂之后又替换生产运行对象的字段。最小方案是在创建工厂前传入测试自己持有的CaseClock，随后只修改这个测试时钟对象。保留consumer_world原关键字、runtime_factory调用形态及四元组返回；大型history工厂与一个带显式初始时钟的报告准备同期调整闭包，避免共享helper的推进与真实工厂脱节。

范围和证据

- 固定基线：caaba927facbf47a3c0596486d5fde71081c7724；生产树9c2b982aa4050c25646e40b6500ebad3a84a8661。
- 只读取该提交的Git对象和AST，没有改任何仓库文件，没有执行模块、pytest或数据库准备。audit.json保留被读来源SHA256、80个直接调用点、15个runtime_factory调用点、14个工厂定义的原代码与输入资料。
- 80调用点属于43个源文件。这是静态调用点数量，不是参数实例或已通过用例数。support/bootstrap_consumers.consumer_world是另一同名helper，已经排除。
- runtime字段赋值的71条候选来自直接导入者及共享helper的AST名称匹配。它包含通过runtime路径修改外部替身return_value的语句，也可能有同文件中另一个运行对象；不能把71条都宣称为同一种非法行为。audit逐条给出方法、位置及原代码，以下明确列出本方案的范围。
- Root说明本轮history owner修改的是test_record_segment_history.py与test_report_selection.py。本审计不写它们。test_segment_bounded_completion_history.py未出现在本审计的目标自定义factory调用清单，不作为本轮已迁移文件。
- 现有partial35pass不证明共享helper已经迁移。本方案尚未实施，也没有新的验证通过声明。预算表来自原源码与生产默认装配的对照，不冒充新的数据库运行收据。

正式契约及调用链

apps/camctl/tests/integration/support/README.md:11明确拍摄沿session_capture_assembly、capture_flow及实际会话推进；固定存储格式专项可以使用公开仓储。session_capture_assembly定义于src/camctl/bootstrap/capture_assembly.py:663，参数已有wall_us、monotonic_ns、devices、drivers、results、wait_config、工具请求及恢复边界。其说明明确允许受控时钟，默认使用系统钟；factory每轮按设备创建运行对象，原保存、录像锚点、重试门槛等由同一工厂持有。

当前默认链为consumer_world→test_capture_contract._runtime→support.capture.capture_runtime/capture_assembly→session_capture_assembly→capture_handler。support.capture.capture_assembly:20-77把check_config等测试输入转换成正式devices配置，随后调用生产工厂；生产result_check默认3/10/3见capture_assembly.py:1001-1012。consumer_world自己覆盖CHECK为3/1.25/2。这里的三元组始终表示max_attempts/timeout_s/retry_interval_s，单位秒；None单独保留。

仓储边界不需要新增生产API。shared support.repository_ports.repository_port已经在指定公开类方法上委派真实仓储；_PreparationBoundary可在原方法实际提交之后返回原receipt加handoff_error，停在原start/stop/conclude/release节点。不能把一个新仓储实例赋给runtime.capture，也不能用另一个节点来替代原中断。

默认consumer的原输入与时序

| consumer | 开始与准备结束 | 必须保持的条件 |
|---|---|---|
| photo | 初始运行读数(_NOW,5e9ns)；真实START结果提交后停止，尚未消费被测RESULTS | action与activity可以不同；photo_taken原证据和原key、时刻保留。 |
| record/winddown | 初始(_NOW,5e9ns)，真实START后推进到(_NOW+60s,5e9+record_control_elapsed_ns)，未给elapsed时为65e9ns；真实STOP及conclude后停止 | UTC固定按旧代码到_NOW+60s，mono可以按独立elapsed参数推进；不能把二者都改成统一时长。CHECK默认3/1.25/2。 |
| cancel | 先在原时刻保存真实取消开始/固定/生效；随后UTC到_NOW+60s、mono到65e9ns；真实STOP提交后停止 | 不把取消受理当取消生效，不改变停止节点与结果保存顺序。 |
| timelapse | 原START后实际关闭旧worker；新工厂UTC=_NOW+700s，默认mono仍为5e9ns，丢弃原单调等待锚点 | 这是冷worker/新工厂边界，不能改成同工厂只推进700秒，也不能擅自把mono加700e9。 |
| start=False | 返回已受理及正式调度开始的前态，不调用handler；custom callback可以合法返回None | 不强行构造runtime、不推进时钟、不把自定义options换成默认值。 |

now_us控制受理、调度窗口和计划时刻；原默认运行时初值是_NOW，而不是自动等于now_us。保留该区别。原max_delay_ms默认5000；pending_capture_group的另一个动作窗口60000以及invalid_sibling自己的窗口也分别保留。record的公开CheckDecisionSave仍以既有60000ms和control_elapsed_ns=60e9的原准备输入提交，不因时钟重构顺手改写业务依据。

全部自定义factory

15个调用点对应14个定义；photo factory有两个调用点。除history大型准备外，其余14个调用点都是start=False。12个定义只接受owned及driver关键字，另两个bootstrap callback接受owned, **_options；不得统一给它们追加必填参数。

| 定义位置 | 原时钟及推进 | 原实际装配预算/特殊输入 |
|---|---|---|
| capture/recording_start_fixtures.py:56 unstarted | 返回None；后续独立RecordStartCase.runtime初始_NOW/7e9 | START默认3/0.75/1，QUERY2/0.5/1；stop_config逐案；CHECK无覆盖3/10/3。 |
| capture/test_action6_control_elapsed.py:124 assemble | _NOW/5e9→真实重开后的_NOW+75s/1e9 | START/STOP/CHECK3/10/3；冷恢复不能冒称仍有连续控制时长。 |
| capture/test_natural_wait_source_transitions.py:263 assemble | _NOW/5e9→wall due+100us、mono+=(startup+1200)ms；冷重开后wall再+5s，mono保持 | CHECK1/1/0；wait=(1000,200,0,startup)ms；原STOP confirmed/failed/UNKNOWN分区。 |
| capture/test_natural_wait_time_eligibility.py:97 assemble | _NOW/5e9；取消时wall+100000us而mono不动；due=_NOW+(startup+1200)ms，调用者各自推进 | CHECK默认3/1/0或传入check_config，经devices.result_check；原等待四分量。 |
| capture/test_public_capture_entry.py:_photo_factory.factory | wall固定_NOW、mono默认5e9或now列表；重开后mono再+3e9 | START/CHECK3/10/3；无stopper；两个调用点。 |
| capture/test_timelapse_host_timer.py:283 assemble | wall不动，mono5e9→15e9 | CHECK3/1.25/2；HostCatalog目标10秒；typed stop证据。 |
| history/test_record_segment_history.py:540 runtime_factory | 原工厂闭包_NOW/5e9，旧helper再覆盖runtime到_NOW+60s/65e9 | CHECK/START/STOP3/10/3；这是唯一start=True的custom factory。必须显式闭包同一测试clock及预装StopPort，不得灌入3/1.25/2。 |
| support/bootstrap_recovery.py:record_world.runtime_factory | 初始formed_at/99e9；成功record再+60s/+60e9；reconnect再+100s/+100e9 | START3/10/1、STOP1/10/1、QUERY2/10/1；CHECK默认3/10/3；unknown/lowered不先加60。 |
| support/bootstrap_result_recovery.py:held_result_close.runtime_factory | 初始_NOW/99e9；record+60s/+60e9、timelapse+700s/+700e9；关闭申请前wall再+1s，重连再+100s/+100e9 | START3/10/0、STOP1/10/0、CHECK1/1.25/0；旧错误和结果关闭原key不变。 |
| support/capture_guard_cases.py:known_failure_case.build | _NOW/5e9→_NOW+75s/80e9→_NOW+80s/85e9 | CHECK3/1.25/2；READ默认3/10/3；segment_size4，repair_margin2，真实READ及工具。 |
| support/native_capture_cases.py:native_world.assemble | _NOW/5e9，外部推进返回的两个数组 | CHECK1/1/0；wait=(1000,200,0,0)ms。 |
| support/native_capture_cases.py:native_fault_world.assemble | _NOW/5e9，原factory/连接工厂/数组由调用方持有 | CHECK3/1.25/2从devices读取，显式check_config=None；保留真实SQLite故障、连接线程及关闭。 |
| support/natural_sources.py:unanchored_source_world.assemble | _NOW/5e9，返回wall及原options/factory，mono闭包不替换 | CHECK1/1/0；wait=(1000,200,0,startup)ms；原control恢复声明。 |
| support/result_cases.py:ResultCase._runtime | 自有CaseClock；record/winddown到_NOW+60s/5e9+elapsed；cancel到_NOW+60s/65e9；timelapse UTC+700s后cold | CHECK默认3/1.25/2，assembly_options逐案覆盖；stopper已在装配前创建。它调用consumer_world时始终start=False，再自行准备。 |

可执行最小阶段A：只完成默认时钟归属

1. consumer_world尾部新增可选clock=None；不删除、重排现有关键字，不改变runtime_factory(owned, driver=control)调用，不改变(owned,runtime,action_id,handler)返回。复用support.result_cases.CaseClock现有测试时钟形态（wall、monotonic、wall_us()、monotonic_ns()），不另建同一时间事实的第二份权威。
2. 默认factory在第一次创建前把clock.wall_us和clock.monotonic_ns放入正式装配输入；原runtime_options仍按原次序覆盖其余输入。record/winddown/cancel只推进clock字段，timelapse在原实际worker关闭/新工厂节点调整UTC。移除这些分支对runtime.wall_us/monotonic_ns的赋值，不包装成另一个读取/设置runtime字段的helper。
3. 默认start=False且调用方已有runtime_options时间回调时，保持原回调，不触发helper的自动时间推进。需要后续时钟变化的调用方可以逐个传入自己的CaseClock，再只推进这个对象。
4. 自定义callback保持原调用形态；start=False的14处不需要新增参数，也不需要重装其clock或预算。唯一自动推进的history回调由root协调同步：在_large_fixture外层创建测试clock，callback闭包这个对象并在原session.runtime创建时注入，consumer_world调用显式传同一个clock。让其CHECK继续从生产默认取得3/10/3；不要给callback合并consumer默认options。
5. reporting/test_result_error_generation.py:_exhausted_world也同期接收/持有测试clock：将旧runtime_options里固定_NOW/5e9的两个时间lambda改为同一clock的输入，仍保留CHECK2/1.25/0及wait target600000ms。否则helper推进自己的clock而factory继续读旧固定lambda，会丢掉record/取消/冷延时的原时间变化。
6. 阶段A原子源改动最少为result_consumer_fixtures.py、history/test_record_segment_history.py与reporting/test_result_error_generation.py。support/result_cases.py的CaseClock可以直接复用，不必改其行为。与root已改的history文件先对齐共享依赖，不覆盖另一树改动。

阶段A并不声称整个helper已经公开：_prepare_through_handler的仓储替换、stopper替换和complete_natural_wait的runtime字段读取仍应在阶段B明确承接。它们不阻塞先完成时钟归属。

阶段B：准备端口与公开事实

- _prepare_through_handler保留四个位置参数。由边界名选定唯一公开仓储方法，在repository_port作用域内真实调用并只在COMPLETED后加原handoff_error；runtime只作为capture_handler参数传递，不再赋runtime.capture或重置仓储。当前函数只驱动一个handler，方法限制足以保留原停止点；若并发使用同一方法，另由调用者从公开存储取得activity身份做匹配，不能把action_id错当activity_id。该函数有9个直接引用文件，全部列在audit。
- 默认record/winddown/cancel需要的StopPort在创建factory前登记。外部替身按正式STOP请求的目标返回stop_confirmed；后续只改测试替身脚本。不要给start=False的能力缺失场景一律补stop_supported。history custom factory自己闭包并传这个StopPort，helper不再改runtime.stopper。
- consumer_world的processing_id与activity_id继续从观察连接读取，CheckDecisionSave改为显式CaptureRepository().save_check_decision；取消仓储沿原正式方法保存。occurred_at取测试clock，不再读runtime.wall_us。数据库由capture_database(owned)测试资源拥有者取得，不读取runtime.database。
- complete_natural_wait目前另读runtime.wall_us/runtime.database。彻底去除这两处，需要其7个调用点传入owned/BusinessDatabase及明确occurred_at，不能保持原两参语义并偷偷保留私有fallback。涉及capture/test_direct_result_terminal_views.py、test_legacy_completion_metadata.py、test_natural_wait_source_transitions.py、test_natural_wait_time_eligibility.py和persistence/test_segment_file_proofs.py。该测试helper参数调整与consumer_world四元组/legacy factory签名是不同兼容边界，应单独原子同步，不拖住阶段A。

后续调用方归属：精确范围与未决

audit逐项列出调用方的原赋值和AttemptConfig表达式。以下是时钟、StopPort和预算需要同步改为装配输入的实际文件，不意味着现在一并实现：

- capture/test_action6_control_elapsed.py、test_action6_lifecycle_recovery.py、test_action6_native_cancel_scope.py、test_action6_segmented_normal.py、test_action6_segmented_recovery.py：外部时钟/停止端口在第一次factory前创建；后续推进其读数/返回脚本。75秒、80秒、6e9等原独立时刻分别保留。
- capture/test_timelapse_host_timer.py：普通world当前后置evidence/results/stopper/baseline_directory/mono；可依照文件内已合法的typed assemble模式提前提供driver registry、结果委派端口和时钟，不能只把赋值藏进world。
- capture/test_record_file_completion_wait.py:_wait_world：CHECK3/10/2在首次相关RESULTS前传入，不归一为3/1.25/2。
- capture/test_result_consumer_saves.py：冷读取重建时从测试持有的config/clock/driver提供原输入，不读旧runtime.check_config/wall_us再复制；结果以公开仓储及原行/事件核对。
- persistence/test_segment_transaction_batches.py中两处CHECK3/10/0可以在尚未创建对应RESULTS尝试前预配；START1/10/None另列下述未决。
- persistence/test_segment_result_conclusion_groups.py:_partial_result_world(retained=True)已有旧attempt后才换maximum。不可把新maximum提前改到旧attempt，更不能用cold factory清除责任。该文件是存储专项，优先让公开begin_result_attempt接收明确当前AttemptConfig，按原完整key/历史与已用次数继续；若仍需业务factory切配置，须保留原拥有者，不能把现有ResultCase.reopen(cold=True)直接当同会话等价替换。

明确未决：persistence/test_segment_transaction_batches.py:675的AttemptConfig(1,Decimal('10'))原retry_interval_s=None。AttemptConfig结构允许None；生产设备配置的_device_seconds直接Decimal(str(value))，None不能注入，缺项又采用3秒。该精确参数不能转换为0或3。需root判定它保护的是公开窄存储格式还是普通业务实际有义务生成的输入；本设计不增加测试专用生产API，也不自行退休或改参数。此项不阻塞默认ClockPort阶段。

其它runtime.media/recording_state/listing_cache等内部协作者、缓存或状态断言不由新ClockPort自动承接。新测试输入对象只持有外部时钟、配置、驱动与结果脚本，不持有私有pending或复制生产算法。对字段没有明确公开合同且没有业务可观察效果的子目标仍交root单独判断，不能以共享helper改完掩盖。

验证计划（本次未执行）

阶段A最小窄核先比较默认record/winddown的原初值及60秒变化、cancel生效前后时刻、timelapse实际worker关闭后UTC+700s且mono不被统一推进；再核legacy strict callback、None占位及大型history factory预算3/10/3。采用公开仓储记录原票据/key/occurred_at以及真实数据库的operation_runs/operation_attempts预算，不能只比较ClockPort内部数值。

随后完整受影响文件至少包括capture/test_result_consumer_saves.py、reporting/test_result_error_generation.py、capture/test_public_capture_entry.py、capture/test_recording_start_runtime.py以及root当前已改的history/test_record_segment_history.py与history/test_report_selection.py。大型跨页/磁盘增长分区保持原规模和128批量；之前partial35不转成新source收据。

阶段B还需9个_prepare_through_handler引用文件及全部ResultCase准备调用方，静态清单见audit。最终共享验收应由root按组件指南在统一源码上覆盖所有直接调用方、相应共享包装的正式消费者及真实失败恢复；按目录隔离进程，不把上述窄核当全helper验收。每轮保留唯一basetemp、src+tests的PYTHONPATH、Popen即时PID、全源码SHA、导入路径、日志/XML、原DB/WAL、预算/时刻/key与原worker收场。所有现有FAILED、UNKNOWN、COMMIT前后、原factory重送、冷worker及真实文件分区保持，不skip/xfail或放宽业务断言。

# 分段检查集成测试接口审计

基线为 `caaba927facbf47a3c0596486d5fde71081c7724`；被审计文件 SHA-256 为 `74feea9f14ff4c3ed1eadc62f4dfbec0ba3a209dd0f2b4be52b2ed629e767853`。本次只读取源码、规则和正式契约，没有运行 pytest，没有修改仓库或生产代码。文件有 15 个测试函数，首函数有 2 个参数分区，共 16 个语义节点；逐项目标、候选和阻塞见同目录 `audit.json`。参数节点的最终 pytest 名称未通过收集确认。

原准备先以 SQL 直接插入计划、动作、设备文件与历史，再以 `_fixed_member` 直接插入固定集合和成员；功能测试不能把这些伪造记录当作真实结果列举。多个用例向当前仅接受 `database` 的 `MediaFlow` 传入已移除的 `owned`，读取会话也传入旧的同步连接。检查目标未能否运行本次没有实测，不能把准备接口漂移记成 16 个业务缺陷。

有一个必须保留的参数差异：原伪造 `segment_sets.target_duration_ms=1000`，即来源集合 1 秒；检查请求 `CoverageTarget(DURATION_S, 60)` 是 60 秒，帧数分区 `CoverageTarget(FRAMES, 60)` 是 60 帧。目标替换反例是 61 秒或 61 帧。原检查预算通常为 3 次、10 秒、重试间隔 0 秒；真正耗尽专例为 1 次、10 秒、0 秒。基本完整副本测试使用默认 4 MiB 分段，`_inspection_runtime` 使用 4 字节；发生时刻 `_NOW + 10` 是加 10 微秒，finalizer 使用 `_NOW + 20` 微秒。现有真实来源支持采用 60 秒动作、75 秒停止、80 秒推进，不能悄悄把它称为与原 1 秒集合完全相同。

[分段契约](/opt/devcontainer/.codex/worktrees/de38/camctl/docs/camctl/database/segments.md:69) 明确公开 `inspect_segment(flow, request)` 和 `read_inspection_for_member`；它要求同源、固定集合中已归属且完整、在场的 original 文件。生产 Action6 经正式拍摄工厂、`capture_handler` 和 Action6 恢复编排调用检查。文档并未因此声明可以从工厂取出并交换不透明 `runtime.media`，也未明确 `finalize_pending_action6_inspections` 接受测试手造 runtime 是独立公开入口。`SegmentInspectionRepository` 的创建和保存是生产仓储与故障观察边界；本次没有找到文档授权它绕开真实来源准备业务成员。

[现有真实来源支持](/opt/devcontainer/.codex/worktrees/de38/camctl/apps/camctl/tests/integration/support/bootstrap_read_cases.py:397) 的 `segment_input_case` 经受理、START/STOP、真实 RESULTS、正式拍摄工厂和处理器建立分段成员，适合作为抽取正式准备入口的依据，但必须核对差异：它固定 60 秒来源，默认分段 4 字节、只提供时长探测，脚本拒绝 `-count_frames`；`partial=True` 把原 3 次读取预算改成 1 次，不能用于承接原三次分区。可显式选择无早期取回等待者。`InspectionCase` 仍调用 `_fixed_member` 并使用 `runtime.media`；`output_segments.py` 也从 runtime 交换 media；现有 Action6 原生帧数样例直接替换 runtime 协作者和内部推进入口，均不是已经合规的等价承接。

| 原节点或分区 | 原目标及拟议边界 |
| --- | --- |
| 完整副本：时长、帧数 2 项 | 分别取得 1.5 秒、45 帧，重复进入不再 probe；检查目标与预算变更均拒绝。真实时长成员可先做生产处理器见证，但它不能自动证明独立请求的替换拒绝；帧数须补真正支持 `-count_frames` 的原生入口。 |
| 两成员、部分副本、SHA 失败、实际耗尽 4 项 | 分别验证两个独立副本；4 字节后失败时不探测；完整 READ 后 SHA 失败的原错误和 slot 释放；仅原 1 次预算耗尽使用耗尽原因。可以从真实结果列表、READ 和 digest 端口逐项构造候选，但先按原预算、目标、分段和错误核对实际事实。 |
| 同 owner 原 ReadEnd 恢复 1 项 | 原用例替换 `_finish_internal_read` 并读取私有 pending。需要真实 READ 已结束、结果保存受阻的边界，之后证明不重复 READ/SHA；当前没有证明等价的正式装配。 |
| 两类冷边界 2 项 | 未确认边界必须维持 RUNNING 和 slot，不重新派发；本地确已收场且历史上界固定时沿原票在 EOF 接续，不重查 SHA。实际失去进程内原责任与真实本地结束不能用 `.clear()`、连接重开或完整长度代替。 |
| 结果 UNKNOWN 同键重送、slot 释放 UNKNOWN 同键重送 2 项 | 实际事务提交但响应丢失后，同拥有者核实原申请和原键；不得将新进程的持久事实读取当作同 owner 重送。须从真实存储边界注入并找到正式接手机会。 |
| READ 已失败而检查未完成的冷恢复 1 项 | 原用例替换私有 `settle_inspection_read_failure`，再清空四组 pending；新测试须在可靠 READ 失败和检查保存之间真实中断，验证原错误、一次尝试、slot 释放、无重读或重查。 |
| 终态检查的 slot 释放 1 项 | 原用例替换私有 slot 收场函数并手造 runtime；新测试应在真实 slot 保存边界中断，经正式消费者接续，同时保留原检查结果事件。 |
| 7 成员分页、两种 UNKNOWN 与另一责任隔离 1 项 | 保留每页 2、7 个合法成员及 1/3/7 已失败、5 原 READ 在途、2/4/6 待完成的分区；保持原键、事件、slot 和零重跑。原测试插入不存在的 999 pending 并直接 UPDATE 取消，须换成真实其他动作、正式取消和实际在途责任；尚未找到完整公开接线。 |
| 完整 READ 与取消收场 1 项 | 必须在真实 READ 结束/存储未交付边界正式受理取消，分别核对原 attempt、run、slot 和检查 UNCONFIRMED；不直接 UPDATE 动作或手造 runtime。 |
| 已保存 probe 结果的冷恢复 1 项 | 真正 COMMIT 后丢响应，关闭原业务进程或工厂，通过正式消费者读回同一持久检查及指标、无第二次 probe；只证明冷持久事实，不证明同 owner 原键重送。 |

建议实施顺序：先抽取真实 Action6 来源准备并对照来源目标、冻结规格、检查目标、实际 READ 参数和字节分段，分开生产消费者和 `inspect_segment` 独立请求能证明的范围；其次在真实设备 READ/digest 端口完成 4 字节中断、原 SHA 错误和原 1 次耗尽，保留原 3 次、10 秒、0 秒，不借用改变预算的 partial 选项；最后再处理原 ReadEnd、同 owner 键、冷恢复和分页/取消，缺失正式入口或物理中断边界时保留旧节点，不注入 pending，也不以冷运行冒充内存原申请重送。任何候选在实际保存参数和结果与原分区核对、独立评审之前，都不应删除旧测试或宣称已承接。

兼容边界：`_Stream` 被真实来源支持导入，`_ReadDriver` 被三个其他 capture 测试导入，`_fixed_member` 仍被旧 `InspectionCase` 导入。迁移本文件前须保留这些导出或协调相应调用方，不能仅删旧准备导致其他目录导入失败。

已有合法 1 ms 媒体并发冲突属于另一条已确认生产问题，必须保留原失败；本次没有运行其复现，也不能通过改慢轮询、预算或时钟避开窗口。实机检查中断恢复在正式计划中仍待验收，本审计不提供真实设备或断电证据。

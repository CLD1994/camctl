# 剩余集成测试边界路由审计

基线固定为 `caaba927facbf47a3c0596486d5fde71081c7724`（tree `69f727eeff72ad696a60463ecd3054e20bbc4da4`）。审计开始时 checkout HEAD 为 `fcfbfb0d3d1588174cb38b2cca0ad04130b91305`，内容变化不替代基线证据。
所有候选位置从 caaba 的 Git blob 读取；没有运行测试，也没有修改源码、测试或正式文档。

## 范围与计数

对 `apps/camctl/tests/integration` 的 595 个文件和 `tests/integration` 的 55 个文件执行 Python AST 扫描，共 650 个文件，解析失败 0 个。
JSON 中附带 650 个扫描文件各自的 SHA-256、字节数、行数和 AST 节点数。AST 与哈希范围限于这两个 integration roots。审计期间一次误用 git grep 在 docs 整体查接口名时触及 verification-data；该截断输出没有采纳为证据，发现后即停止，之后只按明确文档路径读取。未对 verification-data 做 AST、哈希或递归证据扫描。

本轮留下 5 组待 root 归类的候选。候选计数表示 AST 位置，不表示违规数。

已知未决分工按 parent 路由原样保留：history 两文件；bootstrap ready9/media8；outputs 四个 recovery 文件 13 项，加 terminal absence 与 cleanup query 各 1 项；P3 kernel 单独维护。它们没有合并进本轮新候选数，也没有在此复判。完整路径和 22 个先前分派路径见 JSON。

| 组 | 发现 | 当前判断 |
|---|---:|---|
| 工厂返回 Runtime 的字段改写 | 126 个字段候选，32 个文件；其中 45 处人工跟随到了真实 CaptureRuntime/ObtainRuntime | 按具体字段核对 assembly 参数、公开端口和对象生命周期 |
| ObtainRuntime 仓储端口替换 | 2 处，1 个文件 | 工厂不接收 operations 参数；公开注入边界未知 |
| MediaFlow pending 冷重建 | 7 次 pending 写入/清空，3 个 replace | inspect_segment 是正式文档入口；是否允许直接构造 MediaFlow 需 root 定界 |
| 延时启动私有推进 | 1 处 _control_call | 可从 camera_timelapse 处理器开始；列为独立迁移候选 |
| 事务命令直接调用 | 144 个剩余 commit_operation 调用，24 个直接 Command.plan 调用 | P3/P4 与已分派 history/actor 路径已分开；每个测试按目标判断 |

新 root 判断组共 5 组。另有 CancellationRuntime 的模块 context 文档边界待定；它不计为违规候选。

## 优先候选

### 1. 工厂返回 Runtime 后改写字段

AST 字段目录匹配到 126 处、分布于 32 个未分派文件；排除本轮已分配与已迁移 binding-failure 文件。逐项人工跟随确认了 4 个文件中的 45 处真实对象字段写入：

- `capture/test_record_media_result_settlement.py`（SHA-256 `d984461e3fe7f2909841fabe90e84d69f7cb918c04032b27add3a97e0e46fd72`）：_runtime_with_media 在 73 行写 evidence、75 行写 media；test_media_completion_ends_original_results_without_new_observation 在恢复后于 134、135、136 行分别写 evidence、media、wall_us。对象由 support.capture 的正式 session factory 创建，再交给 capture_handler。
- `capture/test_action6_lifecycle_recovery.py`（SHA-256 `d23b345f04e3b5fff20d7789f1600f9cbaf9417f040fba7bf4c43d9bdb218bfe`）：consumer_world / _overrun_recording 的返回值接着改 driver、clock、stopper、media 等字段（例如 69、113、159-162、311 行），随后调用 capture_handler。
- `capture/result_consumer_fixtures.py`（SHA-256 `4c76cd9f4604652e631e827164b0d836548587e567550593378078bb73f779b7`）：共享 fixture 在 159/168 行换 capture 仓储端口，在 247-276 行设置 clock/stopper。
- `outputs/test_read_diagnostics.py`（SHA-256 `822826a3bbf57d8680d40a6637b7e9f355c95ec3dc22005644162bf39a9c3d4f`）：生产 ObtainRuntime factory 返回后，在 120、191 行替换 operations。

support README 要求完整拍摄会话沿 session_capture_assembly/capture_flow 与实际会话推进，通过 build_runtime/execute_command/close_runtime；它也允许替换既有 driver、file、clock 端口。CaptureRuntime 源码注释称真实仓储端口与设备替身是注入点，session_capture_assembly 还明确接收若干时钟、设备与 pending 状态参数。因此不能只看属性赋值就判违规。需要逐项确认 factory 参数已覆盖哪些字段，尤其 media/capture/operations 是否有正式的公开替代。

### 2. ObtainRuntime.operations 替换

test_read_diagnostics 的两项目标分别验证真实读取异常在保存前保留、以及派发前取消不产生错误记录。read_test_runtime 通过 session_obtain_assembly 返回生产 ObtainRuntime，测试替换其 operations 后调用 run_recording_media 或 obtain_flow.advance_obtain。生产 assembly 没有 operations 注入参数；若该测试继续作为公开模块边界，需明确公开仓储替身入口或以真实仓储故障达成同样目标，保留原异常、key 和零额外调用断言。

### 3. MediaFlow pending 冷重建

test_segment_inspections.py 的 SHA-256 为 `74feea9f14ff4c3ed1eadc62f4dfbec0ba3a209dd0f2b4be52b2ed629e767853`。7 次直接 pending 操作为：452、491、650-653、922 行；两个 replace 候选在 212、1117 行。它们对应跨进程未确认、EOF 恢复、源读取失败重启、无关 pending key，以及保存探测结果未知后的重开。

docs/camctl/database/segments.md:69-71 明确公开 inspect_segment(flow, request) 的唯一检查、恢复和已保存结果语义；production Action6 consumer 在 action6_recovery.py:278 调用它。session_capture_assembly 接受 pending 集合参数，但本测试直接构造 MediaFlow 并清理或注入集合。迁移路线可从真实 DB 重启后建新会话/flow 再调用公开检查入口；若该测试本来就是 MediaFlow 模块接口测试，需明确该对象的模块契约。

### 4. 延时摄影启动调用私有 _control_call

`capture/test_timelapse.py`（SHA-256 `6db18644d1c5328c5f8ee0b2cecae6c5f119e7bebf3ef7bf2a32402bc9f86e1c`）在 46 行导入私有函数，62 行由 _environment.prepare 直接执行 START，之后多个延时等待/重启测试复用该准备。production handlers 公开 capture_handler("camera_timelapse")；现成 consumer_world(..., start=True) 也可沿处理器开始。runtime-configuration-closure 计划只把 _control_call 列入实现映射，不构成其公开契约。当前唯一确认的私有业务推进调用是这处。

### 5. 业务测试直接拼装事务 Command

新 AST 绑定到 144 次未覆盖 commit_operation 调用、49 个文件；另有 24 个直接 Command.plan 调用、9 个文件。原始全量 commit_operation 为 178 次。P3 的 29 次、P4 的 2 次、history/test_record_segment_history 的 2 次和已分派 test_device_photo_flow 的 1 次已单独排除。

- `operations/test_obtain_check_identity.py`（SHA-256 `d1cac3dae41ba3418ddb55384a96fbdb5c4f23a507fd03eaa3547e0bc429bec5`）：8 次 commit_operation（365、379、504、599、677、704、716、763 行）及 4 次 BeginAttemptCommand.plan（311、457、562、615 行）。同文件亦用 OperationRepository.begin_attempt / finish_attempt。正常开始/结束责任可经仓储；伪造所有者、错配历史、缺少 owner 的守卫反例是事务内核候选，需与业务路径区分。
- `persistence/test_segment_result_page_inputs.py`（SHA-256 `24d5139e7e76016b031342e11b3f8c2462ace64d044cf4e8aab5a826f6d4a9ff`）：7 次 commit_operation 与 6 次 SaveResultPageCommand.plan。公开 CaptureRepository.save_result_page 在 production result_pages.py:122 被真实 consumer 调用；valid 保存行为适合经仓储，tampered/bounded plan 用例属于另一种核验目标。

P3 plan 明确 commit_operation 是私有接口，并点名 test_transactions.py 为事务内核组合测试。P4 则独立点名 test_commit_recovery.py，不能因 P3 理由把所有业务目录直接拼 Command 的用例一并合法化，也不能仅按关键词把它们全判违规。完整 144 个调用位置及逐文件 SHA-256 在 JSON。

## Runtime 类型 context 分流

本次识别到剩余 CancellationRuntime 14 次、LogRuntime 10 次、MotorRuntime 1 次直接构造。构造调用本身不计违规：

- LogRuntime 被 L6 计划直接写入 close_logging(runtime: LogRuntime) 接口；测试调用 close_logging，按模块级边界归类。
- MotorRuntime 的消费者是 advance_motor(action_id, runtime)，M4 计划明确 runtime 形参；按模块级边界归类。
- CancellationRuntime 在 cancellation.service.__all__ 中，apply_cancel 公开函数实际接收该类型；N3 计划说明 apply_cancel，但未逐字列出 runtime 参数。保留模块 context 的文档边界问题，不判违规。

WorkFileRuntime 3 次构造位于已分派 ready/media 文件中，未重复裁决。

## 误报控制与限制

直接私有函数逐项复核只确认 test_timelapse.py 的 _control_call 是业务推进。_canonical_binding 是路径期望值辅助函数；_action_finish_guard/_output_guard 是守卫反例；test_startup_log_sweep.py 的旧候选在 caaba:1257 为本地 occupy_worker，实际入口在 1332 调 run_session。

pending 名称只作为 AST 筛选提示。异常链本地列表、任务队列、自建计数和 factory 函数属性都未计作生产 Runtime pending 改写。根 integration 55 个 Python 文件未发现 Runtime 构造或 commit_operation 调用；其中仅在 camera_demo_fixtures.py:316 构造一个设备传输层 DeviceCommand。

解析使用 Python 标准库 ast，并绑定导入别名、赋值接收者和局部上下文；这不是完整跨函数类型系统。测试、动态 import、反射或 monkeypatch 语义没有运行验证。root-confirmed LocalWorkPort.required_settlements contract 不在候选中。

## 产物

- JSON 完整候选位置与文件摘要：`.local/verification/resume-20261030/remaining-boundary-survey.json`
- 本审计未修改 src、tests 或正式文档，也未运行集成测试。


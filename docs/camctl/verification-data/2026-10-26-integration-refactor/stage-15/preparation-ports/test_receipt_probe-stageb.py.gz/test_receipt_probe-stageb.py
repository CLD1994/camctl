from types import SimpleNamespace
import pytest
from integration.capture import result_consumer_fixtures as module
from camctl.persistence.models import DbOutcome, DbOutcomeKind
from camctl.persistence.repositories.capture import CaptureRepository

@pytest.mark.asyncio
@pytest.mark.parametrize('has_prior_error',[False,True])
async def test_preserves_real_instance_and_existing_handoff(monkeypatch,has_prior_error):
    original_error=ValueError('original handoff')
    actual=CaptureRepository()
    actual.test_config=object()
    runtime=SimpleNamespace(capture=actual)
    receipt=DbOutcome(DbOutcomeKind.COMPLETED,value='original receipt',
                      handoff_error=original_error if has_prior_error else None)
    calls=[]
    def save(self,finish,observation,key,owned):
        calls.append(self)
        assert self.test_config is actual.test_config
        return receipt
    monkeypatch.setattr(CaptureRepository,'finish_start_result',save)
    async def handler(action,current):
        request=SimpleNamespace(ticket=SimpleNamespace(responsibility_key=f'start/{action}'))
        result=current.capture.finish_start_result(request,None,'key',None)
        if result.handoff_error is not None: raise result.handoff_error
    monkeypatch.setattr(module,'capture_handler',lambda name: handler)
    if has_prior_error:
        with pytest.raises(ValueError) as raised:
            await module._prepare_through_handler(runtime,42,'record','start')
        assert raised.value is original_error
    else:
        await module._prepare_through_handler(runtime,42,'record','start')
    assert calls == [actual] and runtime.capture is actual

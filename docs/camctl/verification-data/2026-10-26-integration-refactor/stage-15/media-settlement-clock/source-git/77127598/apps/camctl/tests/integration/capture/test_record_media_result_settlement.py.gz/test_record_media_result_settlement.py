"""完整文件已保存后，媒体完成沿原核实责任收场。"""

from dataclasses import replace
from decimal import Decimal
from pathlib import Path
import json

import pytest

from camctl.capture.handlers import capture_handler
from camctl.capture.media import RecordingFailure
from camctl.capture.processing import (
    CheckPhase, CheckResultSave, MediaObservation, ProcessingError,
)
from camctl.contracts.workflow_errors import registered_error
from camctl.contracts.values import ConsistencyError, new_operation_key
from camctl.host_files.media import MediaProbe
from camctl.host_files.tasks import FileTaskId, FileTaskResult
from camctl.persistence.repositories.outputs import register_outputs_guards
from camctl.persistence.repositories.capture import CaptureRepository
from camctl.persistence.models import DbOutcomeKind
from camctl.persistence.transaction import TransactionError
from camctl.persistence.runtime import DbConfig, DbOpenMode, open_existing

from .media_retry_fixtures import _EVIDENCE, media_pipeline, original_recording_entry  # noqa: F401
from camctl.capture.results import FileKind
from .test_capture_contract import ResultsDouble, _entry, _runtime
from .test_input_copy import _CONTENT, _NOW
from .test_media_flow import ReadDriverDouble, _flow
from ..bootstrap.test_binding_transactions import _CommitFailure

pytestmark = pytest.mark.asyncio
register_outputs_guards()


class _WaitingProbe:
    """第一次工具未执行，第二次返回实际时长观察。"""

    def __init__(self, duration_s):
        self.duration_s = duration_s
        self.calls = []

    async def probe(self, input):
        self.calls.append("probe")
        if len(self.calls) == 1:
            return FileTaskResult(task_id=FileTaskId("probe"), ran=False)
        return FileTaskResult(task_id=FileTaskId("probe"), ran=True,
            value=MediaProbe(duration_s=self.duration_s, error=None))

    async def repair(self, input, output, *, trim_s):
        self.calls.append("repair")
        return FileTaskResult(task_id=FileTaskId("repair"), ran=False)


def _attempts(owned):
    return owned.connection.execute(
        "SELECT * FROM operation_attempts ORDER BY id"
    ).fetchall()


def _result_run(owned):
    return owned.connection.execute(
        "SELECT id,status,attempts_used,retry_wait_required,max_attempts_used,"
        " timeout_s_json,retry_interval_s_json FROM operation_runs"
        " WHERE responsibility_key='results/1'"
    ).fetchone()


class _TestClock:
    """墙钟与单调钟分别由测试推进。"""

    def __init__(self):
        self.wall = _NOW
        self.mono = 5_000_000_000

    def wall_us(self):
        return self.wall

    def monotonic_ns(self):
        return self.mono


async def _runtime_with_media(pipeline, duration_s, clock):
    entry = original_recording_entry()
    results = ResultsDouble({1: (entry,)})
    runtime = (await _runtime(pipeline[0], results=results, listing_cache={},
                              evidence=_EVIDENCE, wall_us=clock.wall_us,
                              monotonic_ns=clock.monotonic_ns))
    reader, tools = ReadDriverDouble(_CONTENT), _WaitingProbe(duration_s)
    runtime.media = (await _flow(pipeline, reader, tools))
    return runtime, results, reader, tools


def _assert_joint_settlement(owned, run_id, action_status):
    transactions = {"run": set(), "action": set(), "output": set()}
    for transaction_id, body in owned.connection.execute(
            "SELECT transaction_id,body_json FROM history_events ORDER BY id"):
        for row in json.loads(body)["rows"]:
            values = row["after"]["values"]
            if row["table"] == "operation_runs" and row["id"] == run_id and values.get("status") == 3:
                transactions["run"].add(transaction_id)
            if row["table"] == "actions" and row["id"] == 1 and values.get("status") == action_status:
                transactions["action"].add(transaction_id)
            if row["table"] == "outputs" and values.get("source_action_id") == 1:
                transactions["output"].add(transaction_id)
    assert len(transactions["run"]) == 1
    assert transactions["run"] == transactions["action"] == transactions["output"]
    original = owned.connection.execute(
        "SELECT e.transaction_id FROM history_events e JOIN operation_attempts a"
        " ON a.result_event_id=e.id WHERE a.run_id=?", (run_id,)
    ).fetchone()[0]
    assert original not in transactions["run"]


@pytest.mark.parametrize("duration_s,action_status", [
    (Decimal("61"), 3), (Decimal("5"), 4),
], ids=["media-succeeded", "media-failed"])
@pytest.mark.parametrize("reopen", [False, True], ids=["same-runtime", "saved-history"])
async def test_media_completion_ends_original_results_without_new_observation(
        media_pipeline, duration_s, action_status, reopen):
    owned, roots, source_id = media_pipeline
    clock = _TestClock()
    runtime, results, reader, tools = (await _runtime_with_media(media_pipeline, duration_s, clock))

    await capture_handler("camera_record")(1, runtime)

    original_run = _result_run(owned)
    assert original_run[1:4] == (2, 1, 1)
    original_attempts = _attempts(owned)
    assert len(original_attempts) == 4  # START、STOP、RESULTS 和真实 READ。
    history = owned.connection.execute(
        "SELECT * FROM history_events ORDER BY id"
    ).fetchall()
    assert results.calls == [1]
    assert tools.calls == ["probe"]
    assert not runtime.pending_start_results
    assert owned.connection.execute("SELECT status FROM actions WHERE id=1").fetchone() == (2,)
    assert owned.connection.execute("SELECT COUNT(*) FROM outputs").fetchone() == (0,)

    recovered = None
    try:
        if reopen:
            database_path = Path(owned.connection.execute("PRAGMA database_list").fetchone()[2])
            metadata = owned.metadata
            owned.connection.close()
            recovered = open_existing(database_path, DbOpenMode.EXISTING_RW, DbConfig())
            assert recovered.metadata == metadata
            owned = recovered
            runtime = (await _runtime(owned, results=results, listing_cache={},
                                      evidence=_EVIDENCE, wall_us=clock.wall_us,
                                      monotonic_ns=clock.monotonic_ns))
            runtime.media = (await _flow((owned, roots, source_id), reader, tools))
        clock.wall = _NOW + 200_000_000
        await capture_handler("camera_record")(1, runtime)

        assert owned.connection.execute("SELECT status FROM actions WHERE id=1").fetchone() == (action_status,)
        assert owned.connection.execute("SELECT device_file_id FROM outputs").fetchall() == [(source_id,)]
        assert results.calls == [1]
        assert len(reader.opens) == 1
        assert tools.calls == ["probe", "probe"]
        assert _attempts(owned) == original_attempts
        assert owned.connection.execute(
            "SELECT * FROM history_events WHERE id<=? ORDER BY id", (history[-1][0],)
        ).fetchall() == history
        current_run = _result_run(owned)
        assert current_run[0] == original_run[0]
        assert current_run[2] == original_run[2]
        assert current_run[4:] == original_run[4:]
        assert current_run[1:4] == (3, 1, 0)
        _assert_joint_settlement(owned, original_run[0], action_status)
    finally:
        if recovered is not None:
            recovered.connection.close()


class _TrackedCommitFailure(_CommitFailure):
    """只在复合仓储的真实 COMMIT 前后出错，并记录故障确实命中。"""

    def __init__(self, connection, after):
        super().__init__(connection, after)
        self.commit_calls = 0

    def execute(self, sql, parameters=()):
        if sql == "COMMIT":
            self.commit_calls += 1
        return super().execute(sql, parameters)


class _AtSettlementBoundary(Exception):
    """隔离仓储保存后的消费者步骤，让测试直接检查原子结果。"""


@pytest.mark.parametrize("duration_s", [Decimal("5"), Decimal("61")],
                         ids=["short-file-as-success", "long-file-as-failure"])
async def test_new_settlement_rejects_business_result_opposite_to_saved_media(
        media_pipeline, monkeypatch, duration_s):
    owned = media_pipeline[0]
    clock = _TestClock()
    runtime, _results, _reader, _tools = (await _runtime_with_media(media_pipeline, duration_s, clock))
    await capture_handler("camera_record")(1, runtime)
    original_save = CaptureRepository.finish_recording_results
    recorded = []

    def save(repository, request, key, save_owned):
        before = tuple(save_owned.connection.iterdump())
        contrary = (None if duration_s == Decimal("5") else
            RecordingFailure("recording_too_short", {"processing_id": "1"}))
        changed = replace(request, capture=replace(request.capture, failure=contrary))
        result = original_save(repository, changed, key, save_owned)
        recorded.append((before, result))
        return replace(result, handoff_error=_AtSettlementBoundary())

    monkeypatch.setattr(CaptureRepository, "finish_recording_results", save)
    clock.wall = _NOW + 200_000_000
    with pytest.raises(_AtSettlementBoundary):
        await capture_handler("camera_record")(1, runtime)
    assert len(recorded) == 1
    before, result = recorded[0]
    assert result.kind is DbOutcomeKind.ROLLED_BACK
    assert isinstance(result.error, (TransactionError, ConsistencyError))
    assert tuple(owned.connection.iterdump()) == before


@pytest.mark.parametrize("member", [
    "run_id", "action_id", "occurred_at", "ownership", "file_complete", "sha256",
])
async def test_original_settlement_key_rejects_changed_request_member(media_pipeline, monkeypatch, member):
    owned = media_pipeline[0]
    clock = _TestClock()
    runtime, results, reader, tools = (await _runtime_with_media(media_pipeline, Decimal("61"), clock))
    await capture_handler("camera_record")(1, runtime)
    original_save = CaptureRepository.finish_recording_results
    inputs = []

    def save(repository, request, key, save_owned):
        inputs.append((request, key))
        return original_save(repository, request, key, save_owned)

    monkeypatch.setattr(CaptureRepository, "finish_recording_results", save)
    clock.wall = _NOW + 200_000_000
    await capture_handler("camera_record")(1, runtime)
    assert len(inputs) == 1
    request, key = inputs[0]
    if member == "run_id":
        changed = replace(request, run_id=1)  # 实际 START，不能代替原 RESULTS。
    elif member == "action_id":
        changed = replace(request, capture=replace(request.capture, action_id=99))
    elif member == "occurred_at":
        changed = replace(request, capture=replace(request.capture, occurred_at=_NOW + 200_000_001))
    elif member == "ownership":
        changed = replace(request, capture=replace(request.capture,
            catalog_facts=replace(request.capture.catalog_facts, ownership_confirmed=False)))
    else:
        draft, = request.capture.drafts
        changed_draft = replace(draft, **({"file_complete": False} if member == "file_complete"
                                        else {"sha256": "a" * 64}))
        changed = replace(request, capture=replace(request.capture, drafts=(changed_draft,)))
    before = tuple(owned.connection.iterdump())
    result = original_save(CaptureRepository(), changed, key, owned)
    assert result.kind is DbOutcomeKind.ROLLED_BACK
    assert isinstance(result.error, (TransactionError, ConsistencyError))
    assert tuple(owned.connection.iterdump()) == before
    repeated = original_save(CaptureRepository(), request, key, owned)
    assert repeated.kind is DbOutcomeKind.COMPLETED, repeated.error
    assert tuple(owned.connection.iterdump()) == before
    assert results.calls == [1] and len(reader.opens) == 1 and tools.calls == ["probe", "probe"]


@pytest.mark.parametrize("duration_s,action_status", [
    (Decimal("61"), 3), (Decimal("5"), 4),
], ids=["media-succeeded", "media-failed"])
@pytest.mark.parametrize("after", [False, True], ids=["commit-before", "commit-after"])
async def test_unknown_settlement_reuses_whole_request_and_original_decision_time(
        media_pipeline, monkeypatch, duration_s, action_status, after):
    owned, roots, source_id = media_pipeline
    clock = _TestClock()
    runtime, results, reader, tools = (await _runtime_with_media(media_pipeline, duration_s, clock))
    await capture_handler("camera_record")(1, runtime)
    original_attempts = _attempts(owned)
    run_id = _result_run(owned)[0]
    original_save = CaptureRepository.finish_recording_results
    inputs, outcomes, proxies, connections = [], [], [], []

    def save(repository, request, key, save_owned):
        inputs.append((request, key))
        connections.append(save_owned.connection)
        if len(inputs) == 1:
            proxy = _TrackedCommitFailure(save_owned.connection, after)
            proxies.append(proxy)
            save_owned = replace(save_owned, connection=proxy)
        outcome = original_save(repository, request, key, save_owned)
        outcomes.append(outcome)
        return outcome

    monkeypatch.setattr(CaptureRepository, "finish_recording_results", save)
    clock.wall = _NOW + 200_000_000
    with pytest.raises((ConsistencyError, AssertionError)) as first_error:
        await capture_handler("camera_record")(1, runtime)
    assert len(inputs) == 1 and proxies[0].commit_calls == 1
    assert outcomes[0].kind is DbOutcomeKind.UNKNOWN
    original_request, original_key = inputs[0]
    assert original_request.run_id == run_id
    assert original_request.capture.occurred_at == _NOW + 200_000_000
    database_path = Path(owned.connection.execute("PRAGMA database_list").fetchone()[2])
    metadata = owned.metadata
    owned.connection.close()
    reopened = open_existing(database_path, DbOpenMode.EXISTING_RW, DbConfig())
    try:
        assert reopened.metadata == metadata
        transaction = reopened.connection.execute(
            "SELECT id FROM history_transactions WHERE operation_key=?", (str(original_key),)
        ).fetchone()
        assert (transaction is not None) is after
        assert reopened.connection.execute("SELECT status FROM actions WHERE id=1").fetchone() == (
            action_status if after else 2,)
        assert _result_run(reopened)[1:4] == ((3, 1, 0) if after else (2, 1, 1))
        assert _attempts(reopened) == original_attempts
        # UNKNOWN 回执使真实执行器关闭故障连接；原会话继续持有完整申请，
        # 下一次公开处理器调用由执行器新开连接后重送原保存。
        resumed = runtime
        clock.wall = _NOW + 300_000_000
        await capture_handler("camera_record")(1, resumed)

        assert inputs == [(original_request, original_key), (original_request, original_key)]
        assert connections[0] is not connections[1], "UNKNOWN 必须实际更换数据库连接"
        assert outcomes[-1].kind is DbOutcomeKind.COMPLETED, outcomes[-1].error
        assert _result_run(reopened)[1:4] == (3, 1, 0)
        assert reopened.connection.execute("SELECT status FROM actions WHERE id=1").fetchone() == (action_status,)
        assert reopened.connection.execute("SELECT device_file_id FROM outputs").fetchall() == [(source_id,)]
        _assert_joint_settlement(reopened, run_id, action_status)
        assert _attempts(reopened) == original_attempts
        assert results.calls == [1] and len(reader.opens) == 1
        assert tools.calls == ["probe", "probe"]
        saved_transaction = reopened.connection.execute(
            "SELECT id FROM history_transactions WHERE operation_key=?", (str(original_key),)
        ).fetchone()[0]
        assert reopened.connection.execute(
            "SELECT DISTINCT occurred_at FROM history_events WHERE transaction_id=?", (saved_transaction,)
        ).fetchall() == [(_NOW + 200_000_000,)]
        history = reopened.connection.execute("SELECT * FROM history_events ORDER BY id").fetchall()
        await capture_handler("camera_record")(1, resumed)
        assert reopened.connection.execute("SELECT * FROM history_events ORDER BY id").fetchall() == history
        assert len(inputs) == 2 and tools.calls == ["probe", "probe"]
        assert isinstance(first_error.value, ConsistencyError)
    finally:
        reopened.connection.close()


@pytest.mark.parametrize("reopen", [False, True], ids=["same-runtime", "saved-history"])
async def test_explicit_media_issue_settles_from_saved_check_without_new_queries(
        media_pipeline, reopen):
    """明确媒体问题的检查结果经公开仓储保存后，原输入足以本地收场。

    时长充足但检查发现明确媒体问题：probe 通路不产生该分区（检查
    观察只携带时长或错误），本测试经公开处理仓储保存带 issues 的
    完成观察，随后在无内存缓存与同运行时两种入口下核验收场——
    零新设备查询、零新尝试，错误事实与原 T0、完整可靠文件保持。
    """
    owned, roots, source_id = media_pipeline
    clock = _TestClock()
    runtime, results, reader, tools = (await _runtime_with_media(media_pipeline, Decimal("65"), clock))

    await capture_handler("camera_record")(1, runtime)

    original_run = _result_run(owned)
    assert original_run[1:4] == (2, 1, 1)
    original_attempts = _attempts(owned)
    history = owned.connection.execute(
        "SELECT * FROM history_events ORDER BY id").fetchall()
    assert tools.calls == ["probe"]

    # 公开处理仓储保存明确媒体问题的完成观察：时长充足但 issues
    # 非空，时长判定不覆盖已知媒体问题。
    saved = CaptureRepository().save_check_result(CheckResultSave(
        1, MediaObservation(
            CheckPhase.COMPLETED, duration_s=Decimal("65"),
            issues=(ProcessingError(
                code="container_invalid", stage="check",
                details={"message": "moov atom missing"}),),
        ), _NOW + 100_000), new_operation_key(), owned)
    assert saved.kind is DbOutcomeKind.COMPLETED, saved.error

    recovered = None
    try:
        if reopen:
            database_path = Path(owned.connection.execute("PRAGMA database_list").fetchone()[2])
            metadata = owned.metadata
            owned.connection.close()
            recovered = open_existing(database_path, DbOpenMode.EXISTING_RW, DbConfig())
            assert recovered.metadata == metadata
            owned = recovered
            runtime = (await _runtime(owned, results=results, listing_cache={},
                                      evidence=_EVIDENCE, wall_us=clock.wall_us,
                                      monotonic_ns=clock.monotonic_ns))
            runtime.media = (await _flow((owned, roots, source_id), reader, tools))
        clock.wall = _NOW + 200_000_000
        await capture_handler("camera_record")(1, runtime)

        # 动作按明确媒体问题失败，公共错误如实表达 invalid_media。
        assert owned.connection.execute("SELECT status FROM actions WHERE id=1").fetchone() == (4,)
        code, reason, details = owned.connection.execute(
            "SELECT error_code, json_extract(error_details_json,'$.reason'),"
            " error_details_json FROM actions WHERE id=1").fetchone()
        registered = registered_error("recording_processing_failed")
        assert code == registered["action_error_id"]
        assert json.loads(details)["processing_id"] == "1"
        assert reason == "invalid_media"
        # 零新设备活动：无新 RESULTS 查询、无新 probe、无新 READ、无新尝试。
        assert results.calls == [1]
        assert tools.calls == ["probe"]
        assert len(reader.opens) == 1
        assert _attempts(owned) == original_attempts
        # 原历史与 T0 保持；收场事务在原 run 上结束并清除等待。
        assert owned.connection.execute(
            "SELECT * FROM history_events WHERE id<=? ORDER BY id", (history[-1][0],)
        ).fetchall()[:len(history)] == history
        current_run = _result_run(owned)
        assert current_run[0] == original_run[0]
        assert current_run[2] == original_run[2]
        assert current_run[4:] == original_run[4:]
        assert current_run[1:4] == (3, 1, 0)
        # 已有完整可靠源文件保持，不被媒体失败撤下；核实收场、动作
        # 失败与源文件事实在同一事务保存。
        assert owned.connection.execute(
            "SELECT presence_state, completion_state FROM device_files WHERE id=?",
            (source_id,)).fetchone() == (2, 3)
        _assert_joint_settlement(owned, original_run[0], 4)
    finally:
        if recovered is not None:
            recovered.connection.close()


async def test_incomplete_other_file_control_partition_keeps_media_pipeline(
        media_pipeline):
    """完整 VIDEO 加未完成 OTHER 的控制分区：媒体链照常，收场等集合。

    未完成 OTHER 被如实观察为完成未知，不进入读取或产物；完整
    VIDEO 的读取与检查不受影响。集合因未完成文件暂不齐备时保持
    重试等待，不把未完成解释为完成；OTHER 写完后集合齐备，收场
    只登记完整源文件为产物。
    """
    owned, roots, source_id = media_pipeline
    entry = replace(_entry("original-recording", size=len(_CONTENT)),
                    locator={"path": "/DCIM/original.mp4"}, original_name="original.mp4")
    incomplete = _entry("sidecar-log", kind=FileKind.OTHER, complete=False)
    results = ResultsDouble({1: (entry, incomplete)})
    clock = _TestClock()
    runtime = (await _runtime(owned, results=results, listing_cache={},
                              evidence=_EVIDENCE, wall_us=clock.wall_us,
                              monotonic_ns=clock.monotonic_ns))
    reader, tools = ReadDriverDouble(_CONTENT), _WaitingProbe(Decimal("61"))
    runtime.media = (await _flow(media_pipeline, reader, tools))

    await capture_handler("camera_record")(1, runtime)
    assert _result_run(owned)[1:4] == (2, 1, 1)

    clock.wall = _NOW + 200_000_000
    await capture_handler("camera_record")(1, runtime)

    # 未完成 OTHER 被如实观察为完成未知，不进入读取或产物。
    other_id, = owned.connection.execute(
        "SELECT id FROM device_files WHERE observer_action_id=1 AND id<>?",
        (source_id,)).fetchone()
    assert owned.connection.execute(
        "SELECT completion_state FROM device_files WHERE id=?",
        (other_id,)).fetchone() == (1,)
    assert owned.connection.execute(
        "SELECT COUNT(*) FROM outputs WHERE device_file_id=?",
        (other_id,)).fetchone() == (0,)
    # 媒体链不受未完成 OTHER 影响：只读源文件，检查完成且无需修复。
    assert len(reader.opens) == 1
    assert tools.calls == ["probe", "probe"]
    assert owned.connection.execute(
        "SELECT check_state, repair_state FROM recording_processing"
        " WHERE id=1").fetchone() == (3, 2)
    # 集合因未完成 OTHER 暂不齐备：不收场、不登记产物、保持重试等待。
    assert _result_run(owned)[1:4] == (2, 1, 1)
    assert owned.connection.execute("SELECT status FROM actions WHERE id=1").fetchone() == (2,)
    assert owned.connection.execute("SELECT COUNT(*) FROM outputs").fetchone() == (0,)

    # 集合中未完成文件不参与收场判定：保持等待、不解释为完成，
    # 也不因未完成文件丢弃已观察的完整源文件事实。
    assert owned.connection.execute(
        "SELECT presence_state, completion_state FROM device_files WHERE id=?",
        (source_id,)).fetchone() == (2, 3)


async def test_incomplete_other_turning_complete_settles_from_saved_facts(
        media_pipeline):
    """未完成 OTHER 转完整后的本地装载次序：新轮次只补观察，收场沿已保存事实。

    第一轮集合因未完成 OTHER 保持重试等待（VIDEO 已读取、检查完成、
    无需修复）；后续轮次 OTHER 转完整后，新观察只登记该文件的完成事
    实，不重新读取已可靠结束的源文件、不重新检查，集合齐备即收场，
    每份完整原片各自登记为正式产物。
    """
    owned, roots, source_id = media_pipeline
    entry = replace(_entry("original-recording", size=len(_CONTENT)),
                    locator={"path": "/DCIM/original.mp4"}, original_name="original.mp4")
    incomplete = _entry("sidecar-log", kind=FileKind.OTHER, complete=False)
    results = ResultsDouble({1: (entry, incomplete)})
    clock = _TestClock()
    runtime = (await _runtime(owned, results=results, listing_cache={},
                              evidence=_EVIDENCE, wall_us=clock.wall_us,
                              monotonic_ns=clock.monotonic_ns))
    reader, tools = ReadDriverDouble(_CONTENT), _WaitingProbe(Decimal("61"))
    runtime.media = (await _flow(media_pipeline, reader, tools))

    await capture_handler("camera_record")(1, runtime)
    clock.wall = _NOW + 200_000_000
    await capture_handler("camera_record")(1, runtime)
    assert _result_run(owned)[1:4] == (2, 1, 1)
    assert len(reader.opens) == 1
    assert tools.calls == ["probe", "probe"]
    other_id, = owned.connection.execute(
        "SELECT id FROM device_files WHERE observer_action_id=1 AND id<>?",
        (source_id,)).fetchone()

    # 后续轮次：同一集合中的 OTHER 转完整且集合确定。重试间隔按会
    # 话单调钟计时，墙钟与单调钟一起越过间隔。
    results.files_by_action[1] = (entry, _entry("sidecar-log", kind=FileKind.OTHER))
    clock.wall = _NOW + 400_000_000
    clock.mono = 15_000_000_000
    await capture_handler("camera_record")(1, runtime)

    # 本地装载次序：新轮次重新列举并只补观察 OTHER 的完成事实；已可
    # 靠结束的读取与已完成的检查不重做——零新读取、零新 probe。
    assert results.calls == [1, 1]
    assert len(reader.opens) == 1
    assert tools.calls == ["probe", "probe"]
    assert owned.connection.execute(
        "SELECT completion_state FROM device_files WHERE id=?",
        (other_id,)).fetchone() == (3,)
    # 集合齐备即收场：第二次列举消耗第二次名额，动作成功；完整 VIDEO
    # 与转完整的 OTHER 各自登记为原片产物，收场同事务。
    assert _result_run(owned)[1:4] == (3, 2, 0)
    assert owned.connection.execute(
        "SELECT status FROM actions WHERE id=1").fetchone() == (3,)
    assert owned.connection.execute(
        "SELECT COUNT(*) FROM outputs").fetchone() == (2,)
    assert owned.connection.execute(
        "SELECT COUNT(*) FROM outputs WHERE device_file_id=?",
        (source_id,)).fetchone() == (1,)
    assert owned.connection.execute(
        "SELECT COUNT(*) FROM outputs WHERE device_file_id=?",
        (other_id,)).fetchone() == (1,)
    # 收场事务边界：新轮次直接齐备时，本轮列举处置（尝试结果与 run
    # 终结）沿轮次保存事务提交；正式产物登记与动作成功终态按设备事
    # 实与动作结果规则在同一历史事务保存。
    transactions = {"action": set(), "output": set()}
    for transaction_id, body in owned.connection.execute(
            "SELECT transaction_id,body_json FROM history_events ORDER BY id"):
        for row in json.loads(body)["rows"]:
            values = row["after"]["values"]
            if row["table"] == "actions" and row["id"] == 1 and values.get("status") == 3:
                transactions["action"].add(transaction_id)
            if row["table"] == "outputs" and values.get("source_action_id") == 1:
                transactions["output"].add(transaction_id)
    assert len(transactions["action"]) == 1
    assert transactions["action"] == transactions["output"]

import json,sqlite3,pathlib
root=pathlib.Path('/tmp/camctl-resume-20261030/evidence')
def get(prefix):
 result={}
 for db in (root/prefix/'tmp').glob('*/state.db'):
  if db.parent.is_symlink():continue
  try:
   with sqlite3.connect(db) as c:
    facts=list(c.execute('SELECT d.action_id,d.sent_at,d.expected_check_at,d.wait_completed_event_id,e.occurred_at FROM device_activities d LEFT JOIN history_events e ON e.id=d.wait_completed_event_id ORDER BY d.action_id'))
    attempts=list(c.execute('SELECT r.responsibility_key,a.attempt_no,a.max_attempts_used,a.timeout_s_json,a.retry_interval_s_json FROM operation_runs r JOIN operation_attempts a ON a.run_id=r.id ORDER BY r.id,a.attempt_no'))
    result[db.parent.name]={'wait':facts,'attempts':attempts}
  except sqlite3.Error as e:result[db.parent.name]={'error':str(e)}
 return result
for group in ('capture','persistence'):
 before,after=get('natural-wait-baseline-'+group),get('natural-wait-after-'+group)
 differences={name:{'before':before.get(name),'after':after.get(name)} for name in sorted(before.keys()|after.keys()) if before.get(name)!=after.get(name)}
 result={'before':before,'after':after,'equal':not differences,'differences':differences}
 (root/('natural-wait-compare-'+group+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print(group, 'matched',len(before),'vs',len(after),'different',len(differences))

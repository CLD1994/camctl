import os, sys, subprocess, pathlib, time, json, hashlib
root='/tmp/camctl-resume-20261030/natural-wait-ports'
evidence=pathlib.Path(sys.argv[1]); evidence.mkdir(parents=True,exist_ok=True)
targets=sys.argv[2:]; py='/workspaces/camctl/apps/camctl/.venv311/bin/python'
env=os.environ.copy(); env['PYTHONPATH']=root+'/apps/camctl/src:'+root+'/apps/camctl/tests'
files=['apps/camctl/tests/integration/capture/result_consumer_fixtures.py','apps/camctl/tests/integration/capture/test_direct_result_terminal_views.py','apps/camctl/tests/integration/capture/test_natural_wait_source_transitions.py','apps/camctl/tests/integration/capture/test_natural_wait_time_eligibility.py','apps/camctl/tests/integration/capture/test_legacy_completion_metadata.py','apps/camctl/tests/integration/persistence/test_segment_file_proofs.py']
def manifest():
 return {p:hashlib.sha256((pathlib.Path(root)/p).read_bytes()).hexdigest() for p in files}
(evidence/'source-before.json').write_text(json.dumps(manifest(),indent=2))
(evidence/'change.patch').write_bytes(subprocess.check_output(['git','diff','--',*files],cwd=root))
(evidence/'git-status.txt').write_bytes(subprocess.check_output(['git','status','--short'],cwd=root))
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD:apps/camctl/src'],cwd=root,text=True).strip()
module=subprocess.check_output([py,'-c','import camctl; print(camctl.__file__)'],cwd=root,env=env,text=True).strip()
cmd=[py,'-m','pytest',*targets,'-q','--basetemp',str(evidence/'tmp'),'--junitxml',str(evidence/'results.xml')]
start=time.monotonic()
with (evidence/'pytest.log').open('w') as out:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 (evidence/'execution.json').write_text(json.dumps(dict(pid=p.pid,cwd=root,argv=cmd,head=sha,production_tree=tree,pythonpath=env['PYTHONPATH'],independent_import_precheck=module),indent=2))
 code=p.wait()
(evidence/'source-after.json').write_text(json.dumps(manifest(),indent=2))
(evidence/'result.json').write_text(json.dumps(dict(exit_code=code,wall_seconds=time.monotonic()-start,sources_unchanged=manifest()==json.loads((evidence/'source-before.json').read_text())),indent=2))
print(code, time.monotonic()-start)

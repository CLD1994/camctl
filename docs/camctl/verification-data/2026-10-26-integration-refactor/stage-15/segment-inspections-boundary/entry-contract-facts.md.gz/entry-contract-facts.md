# 分段检查公开入口与目标来源补充核查

本次只读核查从主树 `47682d1c3344f5b7720c7c0ac7f32278960f4761` 开始；执行期间主树由协作者推进至 `f81405806863be6920c5f4944e23348623147148`。两者 `apps/camctl/src` 的 Git 树均为 `9c2b982aa4050c25646e40b6500ebad3a84a8661`，`docs/camctl/database/segments.md` 的 Git 对象均为 `8673ef40968e729cdb2b1bed252d4c3a0f252d33`。原测试审计基线 `caaba927` 与原证据不变；本次未运行测试、未改仓库或生产文件。未发现 `docs/camctl/segments.md`；实际分段存储契约为 `docs/camctl/database/segments.md`。

## 已明确的接口和实际装配

- `docs/camctl/database/segments.md:69` 明确约定 `inspect_segment(flow, SegmentInspectionRequest(action_id, member_id, target, budget, occurred_at))`。请求指向同动作、固定集合内已归属、完整且在场的 original 成员；它保存或恢复唯一检查，完整拷贝和校验后才 probe，返回 WAITING／COMPLETED／FAILED／UNCONFIRMED。帧数请求显式计数；已保存终态读取其指标和 probe，不重做工具。相邻段落明确 `read_inspection_for_member(action_id, member_id, owned)` 返回检查及副本事实。两者是文件契约明确的入口；`SegmentInspectionRepository.create/save_result` 是实际生产保存和合适的存储故障注入边界，但此文没有把任意模拟来源 SQL 作为一般功能准备入口。
- `docs/superpowers/plans/2026-10-23-video-result-modes-and-action6-segmentation.md:115,232-240` 也明确逐段检查端口、请求和返回，并要求不同成员的检查/副本独立、重入保持身份与原预算。这里的 `runtime` 是参数名称；当前函数要求 `MediaFlow`。计划没有定义从正式工厂取得一个可独立调用的 `MediaFlow` 对象的方法，也没有给出 `MediaFlow` 构造参数的正式接口合同。
- `docs/camctl/module-contracts.md` 的“共享类型与接口归属建议”和“依赖与装配”规定：未由接口契约固定的内部类型和签名只是实施建议，装配创建实际资源；不能仅凭可以 import 或 `__all__` 推断公开。`capture/media_flow.py` 的 `MediaFlow` 位于 `__all__`，类注释列了部分字段；`docs/superpowers/plans/2026-09-30-camctl-capture.md:351-363` 记录 `DriverReadSessions`、拷贝与媒体保存的生产职责。这些材料不足以定义各字段、共同责任、所有权与关闭的独立构造契约，尤其不足以授权测试自己组装或交换内部 pending。
- 当前生产 `session_capture_assembly` 通过 `_media_flow_with` 构造 `MediaFlow`，将真实 BusinessDatabase、已登记驱动的 READ/SHA 端口、HostMediaTools、FileTaskExecutor、设备读取配置和时钟组装起来；随后将同会话的 READ、检查、媒体保存责任和恢复边界绑定，并把它交给 `CaptureRuntime.media`。`action6_recovery.py:262-280` 从来源动作冻结定义计算目标，采用原已保存预算或本次配置，并调用 `inspect_segment`。`bootstrap.lifecycle` 的默认会话进一步负责跨流程共用实际文件执行器和责任收场。
- 因此，当前已确认的公开准备路线是：经正式受理和调度，使用 `session_capture_assembly` 及 `capture_handler` 或完整默认会话，由生产消费者创建、持有并推进检查；读取结果用明确的 `read_inspection_for_member` 或持久事实。针对正式消费者路径，测试只提供已声明的设备/工具端口和文件、时钟、存储边界，不取 `runtime.media` 或更改其中集合。`support/bootstrap_read_cases.py:492` 的 `segment_input_case` 可提供真实受理、START/STOP、RESULTS 和工厂的现有基础，但必须按具体测试核对来源/目标、3次与1次、4 MiB与4字节、受控时刻及只支持时长的工具；其 `partial=True` 改成1次，不能替换原3次。

## 1 秒来源与独立 60 的精确含义

| 对象和合同 | 可确认事实 |
| --- | --- |
| 旧测试固定集合 | `_fixed_member` 直接 SQL 插入 `target_duration_ms=1000`，即 1 秒。旧 `_seed_action` 把 `actions.type=2`（登记为 `CAMERA_RECORD`）及 `effective_params_json={"target_duration_s":60}` 直接写入，随后又把执行定义覆盖成只有 `result_policy=action6_video_segments_v1`，缺失正式 Action6 录像目标字段。计划、历史、文件与成员也由 SQL 伪造。它不是可核验的实际 Action6 来源。 |
| 独立检查请求 | `CoverageTarget(DURATION_S, 60)` 是 60 秒；`CoverageTarget(FRAMES, 60)` 是 60 帧。`CoverageTarget` 接受有效正值，`inspect_segment` 的正式函数说明没有要求调用者目标等于集合 `target_duration_ms`，存储创建路径也仅核成员归属及申请格式、固定同一检查的目标与预算。**这只表明函数层未声明也未在该处比较两者，不能推断 1 秒动作、60 秒检查是 Action6 实际业务许可，也不能声称已有可靠真实消费者如此使用。** |
| Action6 普通录像 | 公共规格要求目标提供者从保存的任务参数/采样合同提供目标；Action6 规格明确录像目标为冻结的精确录像时长。生产 `SegmentProfile.coverage_target` 对 `camera_record` 以 `execution_spec.target_duration_ms / 1000` 产生 duration_s，Action6 恢复消费者直接采用此值。因此真实 1 秒普通录像的 Action6 覆盖目标为 1 秒，不是 60 秒，录像也不会由该消费者生成 frames 目标。检查内容可以长于源任务目标；这里对比的是**任务目标与检查请求目标**，不是实测文件长度。 |
| Action6 原生延时 | 帧数目标是冻结采集时长 `D` 和采样间隔 `I` 按 `floor(D/I)+1` 推导，不是将集合毫秒直接换算为帧数。一般数学合同下，1 秒与 60 帧并非量纲矛盾：例如 `D=1`、`I=0.0168` 得 60，但这不是 Action6 当前支持的设备参数。Action6 的正式参数表 `timelapse_parameters.py` 限定时长为 300、600、1200、1800、3600、7200、10800、18000 秒，间隔为列出的整数秒（Action6 最小 1 秒），且间隔短于时长；逐对计算该登记值没有产生 60 帧。不能用旧伪造的普通录像动作声称该分区是 Action6 原生延时业务。其他设备或未来合同是否支持同样目标，不由本次核查推断。 |

原测试的两个请求量纲、60→61 的不变量、完整副本后探测、重复复用、实际错误/取消/未知提交和历史所有权等均有独立有效测试目标；不能因为旧来源是 SQL 或与 Action6 消费目标不一致而删除这些目标。不同分区的 3 次／1 次、10 秒、零重试、4 MiB／4 字节、`_NOW + 10`／`_NOW + 20` 微秒必须分别保持；1 秒来源是伪造准备的一部分，是否必须作为独立公开模块合同的输入继续固定，仍需决策，不能悄悄改成 60 秒来源后声称完整等价。

## 可以执行的路径与决策缺口

1. **生产消费者见证。** 使用真实 Action6 来源，并由会话工厂与 `capture_handler` 执行；普通录像在受理时明确冻结 60 秒，使用有约束的 RESULT/READ/SHA 和受管工具替身，保留原请求预算、目标量纲、分段尺寸和事件时刻。它可以证明真实 60 秒消费者到副本、probe、结果/恢复的组合，但来源从旧伪造 1 秒变成真实 60 秒，因此只能作为这一业务链的新增见证；未获明确归层/覆盖决策前，不应替换要求 1 秒来源的原模块案例。
2. **真实 1 秒 Action6 录像。** 普通录像参数 Schema 允许正整数秒，能够经受理和生产者建立 1 秒真实来源，但正式 Action6 生产消费者会请求 1 秒时长检查。它能验证 1 秒任务的业务检查，不能证明独立请求 60 秒或帧数的参数固定契约，也不能把 1 改成 60 后声称原来源不变。
3. **独立检查模块合同。** V6 已要求同成员重用、目标/预算变更拒绝等直接 `inspect_segment` 测试。当前正文没有定义如何在不交换内部 `CaptureRuntime.media` 的条件下合法取得/构造其 `flow`，因此缺的是对该独立入口的协作者构造、会话持有和关闭合同，而不是增加测试 API 的授权。若维护者决定 `MediaFlow` 是该模块的正式对外上下文，须先由规格明确其必要数据库、目录、受契约约束的设备和工具端口、时钟、执行器与共享责任的所有权，以及冷/同会话边界，再按正式合同建立真实来源与上下文；仅复制当前构造器、把 `runtime.media` 藏入 helper、读/清空/注入 pending 都不满足当前规则。若决定它只供生产消费者使用，则需要明确这组独立请求/拒绝语义由何种公开层承接，不能把普通 Action6 业务链默认为等价。
4. **范围裁决。** 需要项目负责人决定：旧 1 秒集合只是非业务的测试准备，应否在维持明确的 60 秒／60 帧接口输入与其他参数的前提下以真实可构造来源替换；以及给独立检查模块定义现有 `MediaFlow` 上下文的正式合同，还是另选已公开的测试层来承接原目标/预算变更与同 owner 原键恢复。涉及的时长或参数变化若不能获得明确授权，应保留旧节点与差异，不自行确定。

所有同 owner 原结果重送、实际 READ 结束、未确认和 HOST_LOCAL_SETTLED 两种冷边界、取消、7 成员每页2条、零重读和真实 slot 责任仍按原审计保留。另有合法 1 ms 默认会话媒体同文件冲突的既有生产失败；本次不回避、不改变轮询时间，也不以普通成功案例宣称修复。

import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path('/tmp/camctl-resume-20261030/action6-clock-combined'); out=pathlib.Path('/tmp/camctl-resume-20261030/evidence/action6-clock-combined'); os.chdir(root)
def manifest():
 result={}
 for base in ('apps/camctl/src','apps/camctl/tests'):
  for p in sorted(pathlib.Path(base).rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo'):
    result[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 return result
before=manifest(); (out/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
files=['test_action6_lifecycle_recovery.py','test_action6_native_cancel_scope.py','test_action6_segmented_recovery.py','test_action6_control_elapsed.py']
argv=['/workspaces/camctl/apps/camctl/.venv311/bin/python','-m','pytest']+['apps/camctl/tests/integration/capture/'+x for x in files]+['-q','--basetemp',str(out/'temp'),'--junitxml',str(out/'result.xml')]
env=os.environ.copy(); env['PYTHONPATH']=str(root/'apps/camctl/src')+':'+str(root/'apps/camctl/tests'); t=time.monotonic()
with (out/'log').open('w') as log:
 p=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt={'pid':p.pid,'argv':argv,'cwd':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'python':sys.version,'pythonpath':env['PYTHONPATH'],'preflight':'import-preflight.log','source_before':'source-before.json'}
 (out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n'); print('pytest PID',p.pid,flush=True)
 code=p.wait()
after=manifest(); (out/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n'); receipt.update(exit=code,wall_s=time.monotonic()-t,source_unchanged=before==after,source_after='source-after.json',git_status=subprocess.check_output(['git','status','--short'],text=True)); (out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n'); print('exit',code,'wall',receipt['wall_s'],'unchanged',receipt['source_unchanged'],flush=True)

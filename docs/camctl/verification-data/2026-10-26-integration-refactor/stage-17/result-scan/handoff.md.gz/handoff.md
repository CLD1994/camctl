# 结果扫描仓储替身迁移

基线 f269eb2fffa7409ee53bc498cad8781719c32d57；生产源码树对象 9c2b982aa4050c25646e40b6500ebad3a84a8661。本批只修改四个指定 capture 测试文件，移除对 `runtime.capture`、`runtime.operations` 和重开运行时仓储字段的替换。观察器通过 `repository_port` 只拦截列明的公开同步仓储方法，匹配原结果责任键、原票据、动作或文件身份；`super()` 委派给实际仓储实例，保留其配置和状态。故障作用域在原处理阶段结束，重开后的恢复使用真实仓储，文件发现故障则按原设计在两次消费阶段使用同一观察器。

覆盖对应关系：

- `test_result_scan_runtime.py`：结论观察仍记录事务前尝试状态；首原页提交后回执未知仍检查原请求和 key、旧页时刻及冷连接恢复；结果交接或文件登记完成未知分别限定两个公开保存方法，并新增各自故障命中断言。
- `test_result_scan_recovery.py`：末页可靠保存后的未知回执在 `_interrupted` 的原阶段注入，并核命中；恢复结束的操作结果和带设备结束证据的结论分别按原完整票据拦截，仍检查两次原输入与 key、是否已提交、重开恢复和原时间；文件归属保存前中断按动作限定并核命中。原消费者、终页、重试额度和时钟分区保持。
- `test_result_device_completion.py`：设备结论保存未知的已提交/未提交分区只拦截原结果责任，原请求、回执、验证不同输入拒绝和重开后状态保留。
- `test_result_file_recovery.py`：photo/record × projection/commit_before/commit_after 六分区保留原数据库故障、原 key、旧连接关闭和新连接恢复；真实文件身份限定观察，故障对象继续在两个处理阶段记录同一原申请，原有故障已解除和单次列举断言保留。

公开仓储的直接读取调用仍保留；其他非本批范围的 `runtime.results`、`runtime.evidence` 等未迁，也不称这四个文件所有边界已迁移。原测试的等待、超时、重试及时间不变，未修改生产或共享 helper。

基线完整四文件 85 passed，pytest 27.58 秒、墙 28.01 秒，PID 2584。迁移后的首轮 85 passed，pytest 25.81 秒、墙 26.25 秒，PID 3402；随后仅增加故障命中断言，最终源码再次完整运行 85 passed，pytest 26.60 秒、墙 26.96 秒，PID 4068。最终与基线 XML 逐节点身份和结果一致；每侧各 85 个数据库的历史事务/事件、设备文件、结果页关系、操作尝试/运行、产物、动作、活动行数、事件类型及尝试状态计数逐库一致。随机身份及完整数据库字段未做跨轮相等比较；原 key、请求、故障命中、回滚和恢复顺序由各自测试原断言及新增命中断言验证，不把终态计数当作中间步骤证明。

三轮 PID、命令、源码 dirty SHA、退出与前后稳定性、日志和 XML 均在本目录；数据库保留于 `/tmp/camctl-resume-20261030/result-scan-baseline-temp`、`/tmp/camctl-resume-20261030/result-scan-after-temp`、`/tmp/camctl-resume-20261030/result-scan-final-temp`。`import-preflight.txt` 是独立解释器实际导入检查，不冒称 pytest 内观测。`comparison.json` 保存两轮数据库和节点比较。尚需独立评审及其他范围的联合验证。



async def test_slot_release_unknown_replays_original_request_and_key(inspection_world, monkeypatch):
    from camctl.persistence.models import DbOutcome, DbOutcomeKind
    from camctl.persistence.repositories.outputs import OutputsRepository
    owned, _, _, build = inspection_world
    digest = _FailedDigest()
    flow, request, driver, _, tools = build(digest=digest, segment_size=4)
    original = request()
    release = OutputsRepository.release_read_slot
    calls = []

    def commit_then_unknown(repository, command, key, connection):
        calls.append((command, key))
        result = release(repository, command, key, connection)
        if len(calls) == 1:
            assert result.kind is DbOutcomeKind.COMPLETED
            return DbOutcome(kind=DbOutcomeKind.UNKNOWN, error=OSError('commit reply lost'))
        return result

    monkeypatch.setattr(OutputsRepository, 'release_read_slot', commit_then_unknown)
    with pytest.raises(ConsistencyError, match='原读取业务结果未可靠保存'):
        await inspect_segment(flow, original)
    facts = read_inspection_for_member(original.action_id, original.member_id, owned)
    assert owned.connection.execute('SELECT slot_device_id FROM file_copies WHERE id=?', (facts.copy.copy_id,)).fetchone()[0] is None
    resumed = await inspect_segment(flow, original)
    assert resumed.phase is SegmentInspectionPhase.FAILED
    assert len(calls) == 2 and calls[0] == calls[1]
    assert calls[0][0].occurred_at == original.occurred_at
    assert owned.connection.execute('SELECT COUNT(*) FROM history_transactions WHERE operation_key=?', (str(calls[0][1]),)).fetchone() == (1,)
    assert driver.offsets == [0] and digest.calls == 1 and tools.requests == []

# 原逐段检查目标与新用例

原 `test_segment_inspections.py` 有 15 个函数、16 个参数组合；以下名称均为迁移文件中的测试函数。单独的 UNKNOWN 重送失败按正常断言保留，不能视为通过。全文件实际结果以同一源码的最终 XML 和日志为准。

| 原测试 | 承接与差异 |
| --- | --- |
| `test_inspection_copies_full_member_then_reuses_saved_metric`（时长、帧数两组合） | `test_complete_copy_and_saved_metric_reused` 两组合：60 秒/60 帧、完整字节和摘要、显式帧数请求、重复复用、60→61 与预算变化拒绝。 |
| `test_two_actual_members_keep_independent_inspection_and_copy_owners` | `test_two_members_have_independent_copies`：两个正式固定成员的来源、检查、副本、字节和调用独立。 |
| `test_partial_copy_is_not_probed_until_complete` | `test_partial_copy_is_not_probed`：4 字节段读取实际中断，可靠部分进度不得探测；原三次预算、10 秒、0 间隔不变。 |
| `test_source_digest_failure_finishes_owned_inspection_after_clean_read` | `test_source_digest_failure_preserves_original_error`：完整字节与原摘要错误、尝试/流程和机会收场；原三次预算不误记耗尽。 |
| `test_held_clean_end_recovers_inspection_locally_without_read_or_sha_retry` | `test_same_session_replays_original_read_end_after_save_failure` 在正式 `finish_attempt` 保存边界形成未提交 UNKNOWN，保持原完整申请、键和时刻；二次调用目前重抛原异常，预期未满足，生产问题保留。`test_saved_read_end_recovers_after_process_exit_without_new_attempt` 另证明已保存结束依据的新进程接续不重读、不重复摘要。 |
| `test_unconfirmed_cross_process_boundary_keeps_running_read_and_slot` | `test_process_interruption_keeps_unconfirmed_read_and_slot`：真实独立进程在驱动读取中被终止，新会话保留原运行尝试及机会，不重读。 |
| `test_host_local_settled_resumes_original_ticket_at_eof_without_sha_retry` | `test_host_local_recovers_original_ticket_at_eof_after_uncommitted_read_end` 在正式 `save_read_end` 边界形成未提交结束依据、真实进程结束后，原票据从 EOF 打开且不重复读取字节；此场景首次摘要尚未发生，恢复时需读取一次。原摘要失败后不重复摘要由 `test_saved_read_end_recovers_after_process_exit_without_new_attempt` 承接，两个顺序不同的可靠事实不伪造成一个交叉。 |
| `test_failed_inspection_result_unknown_replays_original_key_once` | `test_failed_result_unknown_replays_original_request_and_key`：正式仓储已提交/回执未知，核原完整申请、时间、键、唯一事务及机会释放。 |
| `test_read_slot_release_unknown_replays_same_key` | `test_slot_release_unknown_replays_original_request_and_key`：正式仓储已提交/回执未知，同一入口应按原申请、时间和键重送；当前第二次调用重抛原错误，预期未满足，生产问题保留。 |
| `test_failed_read_without_process_local_finish_resumes_source_failure_after_reopen` | `test_failed_read_is_saved_after_database_worker_reopen`：检查结果保存未提交时，先排空真实文件责任、关闭数据库 worker，再从已保存的 READ 失败和摘要错误恢复；新对象不重读或重算摘要。 |
| `test_action6_finalizer_releases_slot_for_existing_terminal_inspection` | `test_canceled_capture_releases_existing_terminal_inspection`：正式释放仓储回执未知且未提交，重开 worker 后正式拍摄处理器保持原终态/事件并释放机会。 |
| `test_action6_inspection_recovery_pages_and_retries_exact_pending_keys` | `test_canceled_capture_processes_seven_inspections_in_batches`：正式拍摄工厂设批次 2，实际观察 2/2/2/1、处理七项并保持同库另一设备真实来源检查不变；原混合 UNKNOWN 重送分别由两项独立原键见证承接，避免内存集合注入。 |
| `test_cancelled_complete_read_uses_existing_action6_inspection_finalizer` | `test_cancel_after_read_end_before_result_is_taken_over`：正式保存边界等待期间提交取消，真实完整 READ 的原尝试成功、流程取消、检查无法确认并释放机会。`test_cancel_capture_takes_over_the_actual_completed_read` 补充另一时序：完整失败申请已经确定后取消，原结果优先保存。 |
| `test_only_actual_exhausted_read_uses_budget_exhausted_reason` | `test_one_attempt_really_exhausted`：1 次、10 秒、0 间隔的实际读取失败与耗尽、原尝试及释放机会。 |
| `test_saved_probe_result_unknown_is_recovered_after_database_reopen` | `test_saved_probe_result_is_reused_after_database_worker_reopen`：结果已提交但回执未知，先结束文件责任及旧 worker，重新装配读取原事件和指标，不再次读源/摘要/探测。 |

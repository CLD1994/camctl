cwd=/tmp/camctl-segment-inspections-public-20261108
PYTHONPATH=apps/camctl/src PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 /workspaces/camctl/apps/camctl/.venv311/bin/python -m pytest -p pytest_asyncio.plugin -p pytest_mock apps/camctl/tests/integration/capture/test_segment_inspections.py -q -k process_interruption --junitxml=/tmp/camctl-segment-inspections-evidence-20261108/portable-before.xml

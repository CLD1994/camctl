# S13 单元迁移与首次导入资源边界

调查固定在 `27713c14..d56be550`：分支 `fix/integration-failures-20261025`，观察时 HEAD 为 `d56be550c597ed96c8aedd6b986eeb1ad97c05e5`，工作区在写入本证据前干净。差分新增 13 个 unit 文件；新增本身不证明属于 S13。

## 旧报告明确支持的 S13 迁移

| 范围 | 报告明确映射 | 首次导入观察 |
| --- | --- | --- |
| devices | `test_driver_contract.py` 13 项，`test_managed_query_ticket.py` 1 项，共 14 项 | 两模块均未观察到包资源文件打开或资源目录扫描 |
| reporting | `test_worker_diagnostics.py` 的 12 项目标行中，3 个函数迁到 unit，另外 9 个函数仍在 integration；这 3 个函数收集为 12 个参数节点 | 未观察到包资源文件打开或目录扫描 |
| scheduling | `test_candidate_cache.py` 1 项 | 未观察到包资源文件打开或目录扫描 |
| bootstrap 注册 | `test_driver_runtime_registry.py` 1 项 | 未观察到包资源文件打开或目录扫描 |

来源是各组 `.local/refactor-report.json` 的逐项映射；重构记录表第 30、32、38、41 行提供启动配置、候选缓存、报告和设备的汇总结果。启动配置行只记载 9 项通过，没有模块名；当前 `test_read_discovery_configuration.py` 是候选文件，旧报告没有把它映射为 S13 迁移，故归属未确认。

## 新增文件与迁移归属

除上述五个已明确映射的文件外，当前差分还新增配置文件、四个 capture owner 文件、`test_executor_identity.py`、`test_completion_round_handoff.py` 和来源容量消息单测。旧报告未给前六类一个可核对的当前 S13 迁移映射。来源容量单测有独立的固定批量证据：保存的单测退出码为 0，严格首次导入记录称资源打开、路径解析、数据库、网络、线程和子进程受拦截；保存 SHA 与当前文件 SHA 一致。它不据此归入 S13，本次也没有重跑。

capture 组报告把 baseline unknown-save 和 STOP 交错目标记为曾迁到内部单测，随后又记入 `removed`，因为公开集成覆盖已承接；STOP 单测文件在当前 HEAD 不存在。当前已有的 `test_baseline_saves.py` 不在本次新增文件差分中，其首次导入会读枚举登记 JSON。

## 首次导入观察到的资源读取

共在 13 个互相隔离的新 Python 进程导入固定清单：12 个本次新增文件（来源容量模块使用其既有严格证据）以及一个现存的 `test_baseline_saves.py` 参考模块。解释器为 CPython 3.11.17，禁止生成字节码；每个进程在导入前没有预载入目标 camctl 模块。仅导入模块，没有运行测试函数。

七个导入会遍历 `camctl/_resources` 子目录：`test_baseline_save_owner`、`test_capture_save_coordination`、`test_internal_read_save_owner`、`test_preparation_save_owner`、参考模块 `test_baseline_saves`、`test_executor_identity` 和 `test_completion_round_handoff`。遍历的目录为资源根、`examples`、`examples/camera-demo`、`protocol`、`registry`、`runtime`、`sql`；没有观察到 SQL 文件内容打开。

实际打开的三个 JSON 资源和导入链如下：

| 资源 | 导入模块 | 触发链 |
| --- | --- | --- |
| `_resources/registry/enum-registry.json` | `test_baseline_save_owner` | 测试导入 → `capture/baseline.py:6` → `baseline_models.py:15` → `contracts/enums.py:57/37` → `resources.py:58` |
| 同上 | `test_capture_save_coordination`、`test_internal_read_save_owner` | 测试导入 → `capture/media_flow.py:24` → `capture/files.py:19` → `persistence/transaction.py:53` → `history/validators.py:21` → `host_photo_request.py:12` → `host_files/models.py:23` → `contracts/enums.py:57/37` → `resources.py:58` |
| 同上 | `test_preparation_save_owner` | 测试导入 → `capture/preparation.py:10` → `capture/baseline.py:6` → `baseline_models.py:15` → `contracts/enums.py:57/37` → `resources.py:58` |
| 同上 | `test_baseline_saves`（现存参考）、`test_executor_identity`、`test_completion_round_handoff` | 分别经 `tests/support/capture_database.py:5`、`persistence/executor.py:18 → models.py:16`、`persistence/models.py:16` 进入 `persistence/runtime.py:34` → `contracts/enums.py:57/37` → `resources.py:58` |
| `_resources/registry/event-transitions.json` | 三个 capture owner 模块 | coordination/internal-read 经 `capture/media_flow.py:90` → `persistence/repositories/outputs.py:170` → `history/events.py:113/86` → `resources.py:58`；preparation 经 `capture/handlers.py:36` → `finite_cancel.py:20` → `history/events.py:86` → `resources.py:58` |
| `_resources/protocol/workflow-codes.json` | 三个 capture owner 模块 | coordination/internal-read 经 `capture/media_flow.py:90` → `outputs.py:44` → `outputs/cleanup_flow.py:45` → `outputs/sources.py:54` → `contracts/workflow_errors.py:177/44/24` → `resources.py:58`；preparation 先经 `capture/handlers.py:63` 再接同一输出与错误登记链 |

首次导入未观察到 SQLite 连接、socket 连接、线程启动、`subprocess.Popen` 或 `os.fork`。资源树写入被拦截且未触发。解释器读取 Python 源码、字节码及扩展模块不计为包资源读取。

这些结果只覆盖上述固定模块的首次导入；它们不说明后续测试函数没有 I/O，也不代表所有 unit 测试都满足纯单元边界。测试规则要求业务模块首次导入会读取真实包资源时，该组合仍按集成边界处理；此观察是测试归类证据，不是生产缺陷结论。

## 证据指针

- 重构汇总：`docs/camctl/integration-test-refactor-2026-10-26.md:30-41`；SHA-256 `d028a8208c50eaffc85e90a9e42277ef7323433b6cf662c26241258df6477151`。
- 清理报告中的默认配置承接与保留的真实文件读取：`docs/camctl/integration-test-pruning-2026-10-26.md`；SHA-256 `7a4e2f0a7d648f68b3bcf44f13ff0d117394a75114cb8cafd8302faa821cb371`。
- 逐项报告：storage-adapters `/files/6/mapping`、`/files/8/mapping/2`；reporting `/files/24/targets`；control `/files/42/node_mapping/5/current`；bootstrap `/files/71/mapping/0/new`；capture `/unit_import_isolation_pending/node_mapping/*/removed`。各原始报告的大小和 SHA-256 见本 JSON 的 `source_evidence`。
- 当前 13 个新增单测源码的 SHA-256 见本 JSON 的 `current_unit_source_sha256`；首次导入链的所有记录及范围限制见 `first_import_audit`。

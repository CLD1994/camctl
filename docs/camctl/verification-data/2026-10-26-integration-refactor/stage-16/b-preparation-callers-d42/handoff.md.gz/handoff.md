# d42b4952 阶段 B shared preparation 调用路由交接

## 范围与路由

冻结基线 `d42b4952012d99ad36463cdd74eca8d4acd3325b`。AST 和文件 SHA256 均由该 Git 对象读取。保留此前 104 个测试路径，并为只导入 `result_case`、实际使用另一个 `wait_case.world()` 的文件保守增加 1 个候选；`targets.txt` 共 105 个路径。该列表用于组合验证，不是违规判定。

按导入绑定和支持函数调用核对，43 个文件有直接 `consumer_world`/`_prepare_through_handler` 调用，61 个文件有已确认的支持函数或 fixture 路由，1 个文件仅作为过选候选。单纯导入不计调用。三个 residual 文件的实际链路为 `residual_case → record_world → consumer_world`。每个位置、调用关系与 d42 文件摘要见 `facts.json`。

## 运行记录

旧五组命令包含 43 个文件路径。xunit XML 没有 file 字段，本报告按 `classname=tests.integration.<module>` 映射为仓库测试文件；映射后的每组文件集合都与命令 argv 一致。五组合计 1146 个 testcase，30 个 failure、0 个 error、0 个 skipped。旧运行 HEAD 是 `47682d1c`，映射只说明旧运行记录覆盖了对应路径。

另有自然等待 capture 运行（4 个文件、299 个 XML testcase）和 persistence 运行（1 个文件、13 个 testcase）；四个 capture 文件及 persistence 文件的运行前后 SHA 均与 d42 Git blob 一致。媒体收场时钟的 migrated run 有 20 个 testcase、exit 0，测试文件 SHA 也与 d42 一致；baseline run 另有 20 个 testcase，但其源 SHA 不等于 d42。运行记录、命令及生产树标识在 `facts.json`。

d42 与旧五组运行 HEAD 相比还修改了 `history/test_record_segment_history.py`，该路径已在 104 并集中。旧运行不能证明它的 d42 内容已执行。

## 文件

- `targets.txt`：105 个候选路径，一行一个。
- `facts.json`：快照 SHA、逐文件分类与摘要、AST 路由、测试/XML路径映射和运行源摘要。
- `handoff.md`：本摘要。

本次只做静态 AST 与现存运行记录核对，没有运行 pytest/构建，没有改测试、生产代码或正式文档，也没有重做全 650 文件审计。

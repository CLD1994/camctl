"""C5 延时摄影等待安排的组件集成测试。

真实 SQLite 与 P3 事务内核组合：发送成功事实与等待安排按
CAPTURE_WAIT_CHANGED 事件保存；重启后采用本次额外等待重算预计
检查；已保存的等待完成事实不被新配置重写。
"""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import pytest

from camctl.capture.timelapse import (
    CaptureWaitConfig,
    ClockReading,
    EndControl,
    StartReturn,
    TimelapseState,
    WaitKind,
    WaitPlan,
    plan_capture_wait,
)
from camctl.contracts.json_values import json_equal, parse_exact_json
from camctl.contracts.values import new_operation_key
from camctl.persistence.models import DbOutcomeKind
from camctl.persistence.repositories.timelapse import (
    ScheduleWait,
    TimelapseRepository,
    register_timelapse_guards,
)
from camctl.persistence.runtime import DbConfig, DbOpenMode, open_existing


register_timelapse_guards()

_NOW = 1_750_000_000_000_000


def _environment(tmp_path: Path, *, duration_ms=600000, driver_margin_ms=0):
    """沿真实受理和 START 建立合法有限自然任务，不补造发送投影。"""
    import asyncio
    from decimal import Decimal
    from .result_consumer_fixtures import ResultCatalog, consumer_world
    from camctl.capture.handlers import capture_handler
    from camctl.persistence.executor import DbExecutorError
    from camctl.persistence.repositories.capture import CaptureRepository
    from support.repository_ports import repository_port
    from ..support.capture import capture_test_session

    class WaitCatalog(ResultCatalog):
        def parameter_definition(self, device_id, action_type, parameter_type):
            definition = super().parameter_definition(device_id, action_type, parameter_type)
            if definition is not None and action_type == "camera_timelapse":
                factory = definition.task_factory
                return replace(definition, task_factory=lambda params: replace(factory(params),
                    target_duration_s=Decimal(duration_ms)/1000,
                    result_wait_margin_s=Decimal(driver_margin_ms)/1000))
            return definition

    class StartSaved(Exception):
        """实际 START 结果已提交，测试尚未安排等待。"""

    class ObserveStart(CaptureRepository):
        def __init__(self):
            self.saved = []

        def finish_start_result(self, finish, observation, key, owned, **kwargs):
            result = super().finish_start_result(finish, observation, key, owned, **kwargs)
            if result.kind is DbOutcomeKind.COMPLETED:
                self.saved.append((finish, observation, key))
                return replace(result, handoff_error=StartSaved())
            return result

    async def prepare():
        owned = None
        try:
            async with capture_test_session() as resources:
                owned, runtime, action_id, handler = await consumer_world(
                    tmp_path, "timelapse", catalog=WaitCatalog(), start=False)
                assert action_id == 1 and handler == "camera_timelapse"
                database = await resources.database(owned)
                observer = ObserveStart()
                with repository_port(CaptureRepository, observer, ("finish_start_result",),
                        matches=lambda _name, args, _kwargs: args[1] is not None
                        and args[1].action_id == action_id):
                    with pytest.raises(StartSaved):
                        await capture_handler(handler)(action_id, runtime)
                assert len(observer.saved) == 1
                finish, observation, _key = observer.saved[0]
                assert finish.occurred_at == _NOW and observation.sent_at == _NOW
                assert owned.connection.execute(
                    "SELECT sent_at,started_at,expected_check_at,wait_completed_event_id"
                    " FROM device_activities WHERE action_id=?", (action_id,)).fetchone() == (
                        _NOW, None, None, None)
                spec = parse_exact_json(owned.connection.execute(
                    "SELECT execution_spec_json FROM actions WHERE id=?", (action_id,)).fetchone()[0])
                assert spec["target_duration_ms"] == duration_ms
                assert spec.get("result_wait_margin_ms", 0) == driver_margin_ms
            with pytest.raises(DbExecutorError):
                await database.read(lambda worker: worker.connection.execute("SELECT 1").fetchone())
            await resources.close()
            return owned, asyncio.get_running_loop()
        except BaseException:
            if owned is not None:
                owned.connection.close()
            raise

    owned, loop = asyncio.run(prepare())
    assert loop.is_closed()
    return owned


def _value(owned, sql: str, *params):
    row = owned.connection.execute(sql, params).fetchone()
    assert row is not None, f"查询无结果: {sql}"
    return row


def test_unchanged_wait_configuration_returns_saved_result_without_new_history(tmp_path):
    owned = _environment(tmp_path)
    repository = TimelapseRepository()
    try:
        config = CaptureWaitConfig(target_duration_ms=600_000, driver_margin_ms=0)
        plan = plan_capture_wait(
            TimelapseState(clock_trusted=True, start_return=StartReturn.SENT,
                           end_control=EndControl.DEVICE, sent_at_utc=_NOW,
                           anchor_monotonic_ns=5_000_000_000), config,
            ClockReading(utc_us=_NOW, monotonic_ns=5_000_000_000))
        command = ScheduleWait(action_id=1, plan=plan, driver_margin_ms=0,
                               extra_wait_ms=0, occurred_at=_NOW)
        first = repository.schedule_wait(command, new_operation_key(), owned)
        assert first.kind is DbOutcomeKind.COMPLETED, first.error
        before = owned.connection.execute("SELECT id, body_json FROM history_events ORDER BY id").fetchall()
        # 真实命令保存并读取的正文只含真实变化：更新行两侧列集合一致
        # 且逐列精确不等；同值重送不再产生任何历史。
        for _, body_text in before:
            body = parse_exact_json(body_text)
            for item in body["rows"]:
                if not item["before"].get("exists"):
                    continue
                assert set(item["before"]["values"]) == set(item["after"]["values"])
                for column, value in item["before"]["values"].items():
                    assert not json_equal(value, item["after"]["values"][column])
        second = repository.reconfigure_wait(command, new_operation_key(), owned)
        assert second.kind is DbOutcomeKind.COMPLETED, second.error
        assert second.value.expected_check_at == plan.check_at_utc
        assert owned.connection.execute("SELECT id, body_json FROM history_events ORDER BY id").fetchall() == before
    finally:
        owned.connection.close()


@pytest.mark.parametrize("field,value", [("extra_wait_ms", 0.0), ("extra_wait_ms", False),
                                         ("check_at_utc", float(_NOW + 600_000_000))])
def test_same_wait_values_do_not_hide_invalid_input_types(tmp_path, field, value):
    owned = _environment(tmp_path)
    repository = TimelapseRepository()
    try:
        command = ScheduleWait(1, WaitPlan(WaitKind.WAIT_THEN_CHECK, _NOW + 600_000_000), 0, 0, _NOW)
        first = repository.schedule_wait(command, new_operation_key(), owned)
        assert first.kind is DbOutcomeKind.COMPLETED, first.error
        if field == "check_at_utc":
            command = replace(command, plan=replace(command.plan, check_at_utc=value))
        else:
            command = replace(command, **{field: value})
        before = owned.connection.execute("SELECT id, body_json FROM history_events ORDER BY id").fetchall()
        outcome = repository.reconfigure_wait(command, new_operation_key(), owned)
        assert outcome.kind is DbOutcomeKind.ROLLED_BACK
        assert owned.connection.execute("SELECT id, body_json FROM history_events ORDER BY id").fetchall() == before
    finally:
        owned.connection.close()


def test_schedule_saves_wait_plan_from_send_anchor(tmp_path: Path) -> None:
    """等待安排保存发送锚点推导的预计检查；DB 延迟不参与计算。"""
    owned = _environment(tmp_path, duration_ms=1200000, driver_margin_ms=60000)
    repository = TimelapseRepository()
    try:
        config = CaptureWaitConfig(
            target_duration_ms=20 * 60 * 1000, driver_margin_ms=60_000
        )
        plan = plan_capture_wait(
            TimelapseState(
                clock_trusted=True,
                start_return=StartReturn.SENT,
                end_control=EndControl.DEVICE,
                sent_at_utc=_NOW,
                anchor_monotonic_ns=5_000_000_000,
            ),
            config,
            ClockReading(utc_us=_NOW + 3600 * 1_000_000, monotonic_ns=9_000_000_000),
        )
        assert plan.kind is WaitKind.WAIT_THEN_CHECK
        outcome = repository.schedule_wait(
            ScheduleWait(
                action_id=1, plan=plan, driver_margin_ms=config.driver_margin_ms,
                extra_wait_ms=config.extra_wait_ms, occurred_at=_NOW,
            ),
            new_operation_key(),
            owned,
        )
        assert outcome.kind is DbOutcomeKind.COMPLETED
        row = _value(
            owned,
            "SELECT result_wait_margin_ms, extra_wait_ms_used, expected_check_at"
            " FROM device_activities WHERE id = 1",
        )
        assert row[0] == 60_000
        assert row[1] == 0
        assert row[2] == plan.check_at_utc
    finally:
        owned.connection.close()


def test_restart_reconfigure_uses_current_extra_wait(tmp_path: Path) -> None:
    """重启后本次额外等待变化：重算预计检查，等待完成事实不变。"""
    owned = _environment(tmp_path)
    repository = TimelapseRepository()
    try:
        first = plan_capture_wait(
            TimelapseState(
                clock_trusted=True, start_return=StartReturn.SENT,
                end_control=EndControl.DEVICE, sent_at_utc=_NOW,
                anchor_monotonic_ns=5_000_000_000,
            ),
            CaptureWaitConfig(target_duration_ms=600_000, driver_margin_ms=0),
            ClockReading(utc_us=_NOW, monotonic_ns=5_000_000_000),
        )
        repository.schedule_wait(
            ScheduleWait(
                action_id=1, plan=first, driver_margin_ms=0,
                extra_wait_ms=0, occurred_at=_NOW
            ),
            new_operation_key(),
            owned,
        )
        original_check = first.check_at_utc

        resume_at = _NOW + 60 * 1_000_000
        resumed = plan_capture_wait(
            TimelapseState(
                clock_trusted=True, start_return=StartReturn.SENT,
                end_control=EndControl.DEVICE, sent_at_utc=_NOW,
                anchor_monotonic_ns=None, restart=True,
            ),
            CaptureWaitConfig(
                target_duration_ms=600_000, driver_margin_ms=0, extra_wait_ms=30_000
            ),
            ClockReading(utc_us=resume_at, monotonic_ns=42_000_000_000),
        )
        assert resumed.kind is WaitKind.RESUME_WAIT
        outcome = repository.reconfigure_wait(
            ScheduleWait(
                action_id=1, plan=resumed, driver_margin_ms=0,
                extra_wait_ms=30_000, occurred_at=resume_at,
            ),
            new_operation_key(),
            owned,
        )
        assert outcome.kind is DbOutcomeKind.COMPLETED
        row = _value(
            owned,
            "SELECT extra_wait_ms_used, expected_check_at, wait_completed_event_id"
            " FROM device_activities WHERE id = 1",
        )
        assert row[0] == 30_000
        assert row[1] == original_check + 30_000 * 1000
        assert row[2] is None  # 等待完成事实仍未建立
    finally:
        owned.connection.close()


@pytest.mark.parametrize('change', ['none', 'time', 'extra', 'margin', 'due', 'action', 'branch'])
def test_schedule_same_key_reuses_only_original_complete_persistent_input(tmp_path, change):
    owned = _environment(tmp_path)
    repository = TimelapseRepository()
    try:
        command = ScheduleWait(1, WaitPlan(WaitKind.WAIT_THEN_CHECK, _NOW+600000000), 0, 0, _NOW)
        key = new_operation_key()
        first = repository.schedule_wait(command, key, owned)
        assert first.kind is DbOutcomeKind.COMPLETED, first.error
        if change == 'time': command = replace(command, occurred_at=_NOW+1)
        elif change == 'extra': command = replace(command, extra_wait_ms=1)
        elif change == 'margin': command = replace(command, driver_margin_ms=1)
        elif change == 'due': command = replace(command, plan=replace(command.plan, check_at_utc=_NOW+600001000))
        elif change == 'action': command = replace(command, action_id=2)
        save = repository.reconfigure_wait if change == 'branch' else repository.schedule_wait
        replay = save(command, key, owned)
        assert replay.kind is (DbOutcomeKind.COMPLETED if change == 'none' else DbOutcomeKind.ROLLED_BACK)
        if change == 'none': assert replay.value == first.value
    finally:
        owned.connection.close()


def test_wait_verification_reads_original_key_without_publishing_missing_candidate(tmp_path):
    owned = _environment(tmp_path)
    repository = TimelapseRepository()
    try:
        command = ScheduleWait(1, WaitPlan(WaitKind.WAIT_THEN_CHECK, _NOW+600000000), 0, 0, _NOW)
        key = new_operation_key()
        before = owned.connection.execute('SELECT COUNT(*) FROM history_events').fetchone()
        verified = repository.verify_wait(command, key, owned)
        assert verified.kind is DbOutcomeKind.COMPLETED and verified.value is None
        assert owned.connection.execute('SELECT COUNT(*) FROM history_events').fetchone() == before
        saved = repository.schedule_wait(command, key, owned)
        verified = repository.verify_wait(command, key, owned)
        assert verified.kind is DbOutcomeKind.COMPLETED and verified.value == saved.value
    finally:
        owned.connection.close()

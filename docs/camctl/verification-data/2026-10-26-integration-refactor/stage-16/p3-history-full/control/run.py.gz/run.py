import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/opt/devcontainer/.codex/worktrees/de38/camctl')
control = Path(__file__).resolve().parent
output = Path('/tmp/camctl-resume-20261030/p3-history-full')
python = '/workspaces/camctl/apps/camctl/.venv311/bin/python'
command = [python, 'scripts/run-memory-budget.py', '--camctl-memory-limit', '2GiB',
    '--evidence-dir', str(control / 'delegation'), '--', python, 'scripts/run-integration.py',
    '--scope', 'camctl', '--python', python, '--jobs', '2', '--output', str(output),
    '--target', 'apps/camctl/tests/integration/persistence',
    '--target', 'apps/camctl/tests/integration/history']
started = time.monotonic()
with (control / 'launcher.log').open('x') as log:
    process = subprocess.Popen(command, cwd=root, env=os.environ.copy(), stdout=log, stderr=subprocess.STDOUT)
    receipt = {'pid': process.pid, 'command': command, 'cwd': str(root),
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
        'dirty': subprocess.check_output(['git', 'status', '--short'], cwd=root, text=True),
        'output': str(output), 'jobs': 2, 'status': 'running'}
    (control / 'receipt.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps({k: v for k, v in receipt.items() if k != 'command'}), flush=True)
    code = process.wait()
receipt.update(status='finished', exit_code=code, wall_seconds=time.monotonic()-started)
(control / 'receipt.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps({k: v for k, v in receipt.items() if k != 'command'}), flush=True)
sys.exit(code)

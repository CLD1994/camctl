import collections
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/opt/devcontainer/.codex/worktrees/de38/camctl')
control = Path(__file__).resolve().parent
output = Path('/tmp/camctl-resume-20261030/combined-d42')
python = '/workspaces/camctl/apps/camctl/.venv311/bin/python'
old = json.loads(Path('/tmp/camctl-resume-20261030/evidence/b-preparation-callers/facts.json').read_text())
coverage = old['confirmed_call_coverage']
targets = {item['file'] for name in ('already_executed', 'unrun_source_candidates_only') for item in coverage[name]}
for commit in ('c469bc72', '77127598'):
    for name in subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', commit], cwd=root, text=True).splitlines():
        if Path(name).name.startswith('test_') and name.endswith('.py'):
            targets.add(name)
targets.add('apps/camctl/tests/integration/capture/test_timelapse_wait_runtime.py')
targets = sorted(targets)
assert all((root / name).is_file() for name in targets)
assert subprocess.run(['git', 'diff', '--quiet', 'd42b4952', 'HEAD', '--', 'apps/camctl/src', 'apps/camctl/tests', 'scripts'], cwd=root).returncode == 0
(control / 'targets.txt').write_text('\n'.join(targets) + '\n')
selection = {'basis': 'Conservative candidate union; not a claim of exhaustive dynamic call coverage',
    'test_code_baseline': 'd42b4952', 'current_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'targets': targets, 'by_directory': dict(collections.Counter(Path(name).parent.name for name in targets)),
    'jobs': 2, 'scope': 'camctl'}
(control / 'selection.json').write_text(json.dumps(selection, indent=2))
runner = [python, 'scripts/run-integration.py', '--python', python, '--scope', 'camctl', '--jobs', '2', '--output', str(output)]
for target in targets:
    runner += ['--target', target]
command = [python, 'scripts/run-memory-budget.py', '--camctl-memory-limit', '2GiB', '--evidence-dir', str(control / 'delegation'), '--', *runner]
started = time.monotonic()
with (control / 'launcher.log').open('x') as log:
    process = subprocess.Popen(command, cwd=root, env=os.environ.copy(), stdout=log, stderr=subprocess.STDOUT)
    receipt = {'pid': process.pid, 'command': command, 'cwd': str(root), 'head': selection['current_head'],
        'targets': len(targets), 'target_directory_counts': selection['by_directory'], 'jobs': 2,
        'output': str(output), 'status': 'running'}
    (control / 'receipt.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps({key: value for key, value in receipt.items() if key != 'command'}), flush=True)
    code = process.wait()
receipt.update(status='finished', exit_code=code, wall_seconds=time.monotonic()-started)
(control / 'receipt.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps({key: value for key, value in receipt.items() if key != 'command'}), flush=True)
sys.exit(code)

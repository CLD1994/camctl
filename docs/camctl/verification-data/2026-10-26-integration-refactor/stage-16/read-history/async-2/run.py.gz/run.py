import os, subprocess, time, json, pathlib, hashlib
root='/tmp/camctl-resume-20261030/read-history-async'; evidence=pathlib.Path('/tmp/camctl-resume-20261030/evidence/read-history-async-2')
py='/workspaces/camctl/apps/camctl/.venv311/bin/python'; source='apps/camctl/tests/integration/bootstrap/test_read_history_replay_report.py'
env=os.environ.copy(); env['PYTHONPATH']=root+'/apps/camctl/src:'+root+'/apps/camctl/tests'
def digest(): return hashlib.sha256((pathlib.Path(root)/source).read_bytes()).hexdigest()
(evidence/'source-before.sha256').write_text(digest()+'  '+source+'\n')
(evidence/'change.patch').write_bytes(subprocess.check_output(['git','diff','--',source],cwd=root))
(evidence/'git-status.txt').write_bytes(subprocess.check_output(['git','status','--short'],cwd=root))
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(); tree=subprocess.check_output(['git','rev-parse','HEAD:apps/camctl/src'],cwd=root,text=True).strip()
module=subprocess.check_output([py,'-c','import camctl; print(camctl.__file__)'],cwd=root,env=env,text=True).strip()
cmd=[py,'-m','pytest',source,'-q','--basetemp',str(evidence/'tmp'),'--junitxml',str(evidence/'results.xml')]
start=time.monotonic()
with (evidence/'pytest.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 (evidence/'execution.json').write_text(json.dumps(dict(pid=p.pid,argv=cmd,cwd=root,head=sha,production_tree=tree,pythonpath=env['PYTHONPATH'],independent_import_precheck=module),indent=2))
 code=p.wait()
(evidence/'source-after.sha256').write_text(digest()+'  '+source+'\n')
(evidence/'result.json').write_text(json.dumps(dict(exit_code=code,wall_seconds=time.monotonic()-start,source_unchanged=(evidence/'source-before.sha256').read_text()==(evidence/'source-after.sha256').read_text()),indent=2))
print(code,time.monotonic()-start)

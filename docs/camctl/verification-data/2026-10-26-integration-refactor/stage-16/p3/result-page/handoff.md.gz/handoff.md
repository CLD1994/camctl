# 结果页事务协作边界迁移

基线 3e4d763570c238d21bcc13a01effbe42e49c75e1；生产源码树对象 9c2b982aa4050c25646e40b6500ebad3a84a8661。修改范围仅 `test_segment_result_page_inputs.py` 和 `test_page_read_cache.py`。原问题是七处测试直接构造仓储私有 `SaveResultPageCommand`，将业务命令实现当作契约；现在通过 `CaptureRepository.save_result_page` 交付边界捕获不透明命令，不执行计划或返回假结果，再由真实 `commit_operation` 在事务作用域内调用该命令的 `plan` 并装饰约定的事务协作输入。反例属于底层事务专项，不能说明正常业务会生成这些非法组合。

逐组对应：

- `test_bounded_zero_difference_preserves_raw_page_without_index`：2 个空页/非空零差分分区，仍用有界计划完成真实提交，检查原页、无索引、提交事件和结束回调。
- `test_atomic_page_guard_recomputes_the_difference_and_index_rows`：9 类普通提案篡改，仍检查原键没有事务、目标关系无落库，以及既有外部文件数。
- `test_bounded_entry_accepts_only_actual_append_then_index`：原 1、127、128 项全部保留，仍检查 APPEND/INDEX 顺序和实际索引成员数。
- `test_bounded_entry_rejects_mutated_page_group`：9 类有界篡改，仍检查整组回滚、原键、关系、文件及结束回调未调用。
- `test_fix1_i1_mismatched_caller_state_is_rejected_as_consistency_control`：16 类调用方事实乘普通/有界两种，仍核对原键和数据库状态。
- `test_fix1_i1_real_baseline_rejects_caller_task_scope_and_common_extra`：普通/有界两种，仍检查原基准、设备文件、页关系和尝试范围未改变。
- `test_uncommitted_page_never_gains_committed_read_qualification`：真实事务中检查候选页不可作为已提交读取依据，破坏关系后抛原一致性错误，核对事件和关系回滚。

以上合计 58 个参数化节点；两个文件的其他节点及其连续分页、当前读取、未来提案、跨事务和跨连接缓存等断言未修改。原请求、操作键、时钟、128 上界、参数和断言均未更改。其余底层格式和核心协议测试自建命令保持原样。

基线完整两文件 152 passed，pytest 22.96 秒，墙钟 24.21 秒；修改后相同两个文件 152 passed，pytest 21.46 秒，墙钟 22.52 秒。XML 逐节点身份和结果一致，无失败或跳过；两个独立临时目录各 152 个数据库，逐对应数据库的事务、事件、设备文件、页关系、尝试行数及事件类型计数一致（详见 comparison.json）。跨次随机键不做相等比较；原键回滚由各测试在各自事务内断言。该比较不是数据库全部字段的逐字节比对，也不替代完整其他组件验证。两次运行 PID、参数、源码哈希、退出及前后哈希见 baseline.json / after.json；日志和 XML 同目录，原始 DB 分别在 `/tmp/camctl-resume-20261030/p3-result-page-baseline-temp`、`/tmp/camctl-resume-20261030/p3-result-page-after-temp`。import-preflight.txt 为独立解释器启动前检验，不冒称 pytest 进程内观测。两次运行中三个关联文件哈希稳定。

# persistence 事务专项依赖审计

基线 d42b4952。inventory.json 是对该目录所有 Python 模块的 AST 候选清单：19 文件、256 个候选调用或引用；其中包含测试自建命令、正常事务调用及重复引用，不能当作 256 个私有依赖。直接搜索另核对不以 Command 结尾的 baseline 命令。现阶段只改配对两文件和共享装配；其余项是后续批次，不表示已经迁移或通过。

- 结果页：test_segment_result_page_inputs.py、test_page_read_cache.py 直接构造 SaveResultPageCommand；保留页面连续、128 限额、未来提案、当前事实及缓存边界。
- 结果集合及成员：test_segment_result_sets.py、test_segment_result_versions.py、test_segment_result_batches.py 使用 CreateResultSetCommand、ResultMembersCommand、BeginAttemptCommand 及计划组合；保留固定范围、键和拒绝分区。
- 结果结论：test_segment_check_conclusions.py、test_segment_result_conclusion_groups.py 使用 ConcludeResultCheckCommand；保留有限/有界、终态结论和原操作键。
- 基准读取：test_baseline_read_facts.py 使用 SaveBaselineReadIntent/Return/Unconfirmed；保留意图、返回、未知及原次数。
- 事件/成员与大组：test_segment_file_proofs.py、test_segment_transaction_batches.py 使用 plan_operation 或具体计划；test_segment_storage.py 组合自建序列。区分具体仓储命令、独立测试命令及事务协议；保留原完整组、批量和容量。
- 通用事务专项：test_transactions.py、test_saved_transactions.py、test_commit_recovery.py、test_repositories.py、test_software_recovery_upgrade.py 主要使用事务或仓储、真实错误和恢复；其自建协议命令并非自动归类为私有仓储依赖。test_transactions.py 中 PlanCreateCommand 一处需单独核类型来源与用途。
- transaction_fixtures.py 的旧 plan_operation 仍被其他文件使用并保留待迁移；本批配对两个文件不再调用它。新 capture_operation_command 只截获不透明命令，既不执行计划也不交付伪成功；组合反例仅在实际事务的计划阶段用子范围形成两项提案，以真实范围分配最终两事件，不表示业务组合入口。

候选需逐项判明真实依赖和原分区；inventory 列出文件和行号，不能根据名字机械替换或删除。保留原公开仓储正常入口、真实失败、回滚、提交未知、原键及恢复，按各批次对照源、DB 和完整文件复验。

补充单元目录：unit-inventory.json 列出两处直接仓储计划调用，test_attempt_reads.py:97 的 BeginAttemptCommand 和 test_segment_saved_finish_facts.py:98 的 _FinishCommand。后者是 SQLite 连接替身及多个内部端口替身下验证不重复核实旧事实的单元专项；它们不是本批真实事务集成通过项，是否迁移须按单元测试边界逐项判定，不因 concrete 名称自动删除。其他单元文件对仓储内部纯规则和读取端口的引用属于另外的依赖，不能仅由命令扫描宣布全部无私有实现依赖。

import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path('/tmp/camctl-resume-20261030/p3-result-set-ports'); out=pathlib.Path('/tmp/camctl-resume-20261030/evidence-p3-result-set-ports'); name=sys.argv[1]; py='/workspaces/camctl/apps/camctl/.venv311/bin/python'; env=os.environ.copy();env['PYTHONPATH']=str(root/'apps/camctl/src')+':'+str(root/'apps/camctl/tests')
def fingerprint():
 h=hashlib.sha256()
 for raw in subprocess.check_output(['git','ls-files','-z','apps/camctl/src','apps/camctl/tests','docs/camctl/persistence-runtime.md','docs/camctl/module-contracts.md','docs/superpowers/plans/2026-09-30-camctl-persistence.md'],cwd=root).split(b'\0'):
  if raw:
   f=root/os.fsdecode(raw);h.update(raw+b'\0');h.update(hashlib.sha256(f.read_bytes()).digest() if f.is_file() else b'missing')
 return h.hexdigest()
pre=subprocess.check_output([py,'-c','import sys,camctl; print(sys.version); print(camctl.__file__)'],cwd=root,env=env,text=True)
args=[py,'-m','pytest','apps/camctl/tests/integration/persistence/test_segment_result_sets.py::test_saved_result_set_prevents_another_actual_results_attempt','apps/camctl/tests/integration/persistence/test_segment_result_sets.py::test_canonical_members_fix_exact_original_sources','apps/camctl/tests/integration/persistence/test_segment_result_versions.py::test_unknown_cancel_create_closes_original_and_reuses_same_request_key','apps/camctl/tests/integration/persistence/test_segment_check_conclusions.py::test_decision_cannot_share_actual_transaction_with_another_legal_decision','apps/camctl/tests/integration/persistence/test_segment_result_conclusion_groups.py::test_result_decision_unknown_restores_original_complete_group_from_fresh_connection','-q','--basetemp',str(out/(name+'-tmp')),'--junitxml',str(out/(name+'.xml'))]
meta={'preflight':pre,'argv':args,'cwd':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=root,text=True),'before':fingerprint(),'PYTHONPATH':env['PYTHONPATH']};t=time.monotonic()
with (out/(name+'.log')).open('w') as log:
 p=subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);meta['pid']=p.pid;(out/(name+'.json')).write_text(json.dumps(meta,indent=2));print('pid',p.pid,flush=True);meta['exit_code']=p.wait()
meta.update(wall_seconds=time.monotonic()-t,after=fingerprint());(out/(name+'.json')).write_text(json.dumps(meta,indent=2));print(json.dumps(meta),flush=True)

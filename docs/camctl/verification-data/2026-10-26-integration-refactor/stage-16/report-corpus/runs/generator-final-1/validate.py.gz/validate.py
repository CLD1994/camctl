from pathlib import Path
from contextlib import closing
import gzip, shutil, hashlib, json, sqlite3, time
from integration.support.report_selection_corpus import corpus_watermarks
from camctl.contracts.history_values import HistoryBoundary
from camctl.history.queries import ReportScopeRequest
from camctl.persistence.repositories.history import HistoryRepository
base=Path('/tmp/camctl-resume-20261030/evidence/report-corpus-adoption/generator-final-1')
manifest_path=base/'generated/report-selection-4200.json'; manifest=json.loads(manifest_path.read_text());archive=base/'generated/report-selection-4200.sqlite.gz';dest=base/'validation';dest.mkdir(exist_ok=False);state=dest/'state.db'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
start=time.monotonic(); original={str(p):digest(p) for p in (manifest_path,archive)}
assert archive.stat().st_size==manifest['gzip_bytes'] and digest(archive)==manifest['gzip_sha256']
with gzip.open(archive,'rb') as src,state.open('xb') as out:shutil.copyfileobj(src,out,1024*1024)
assert state.stat().st_size==manifest['database_bytes'] and digest(state)==manifest['database_sha256']
with closing(sqlite3.connect(f'{state.as_uri()}?mode=ro',uri=True,isolation_level=None)) as c:
 c.execute('PRAGMA query_only=ON');assert c.execute('PRAGMA query_only').fetchone()==(1,)
 assert c.execute('PRAGMA integrity_check').fetchone()==('ok',)
 assert c.execute('PRAGMA journal_mode').fetchone()==(manifest['journal_mode'],)
 paths=manifest['metadata_paths'];metadata=c.execute('SELECT instance_id,format_version,staging_path,ready_path,processing_path FROM database_metadata').fetchone();assert metadata==(manifest['database_instance_id'],manifest['database_format_version'],paths['staging'],paths['ready'],paths['processing'])
 for table,n in manifest['counts'].items():assert c.execute(f'SELECT COUNT(*) FROM {table}').fetchone()==(n,)
 assert c.execute('SELECT plan_id,COUNT(*) FROM actions GROUP BY plan_id ORDER BY plan_id').fetchall()==[(1,3),(2,4200),(3,3)]
 assert c.execute('SELECT id,source_action_id FROM outputs ORDER BY id').fetchall()==[(1,1),(2,1),(3,1),(4,1)]
 boundary=HistoryBoundary(*c.execute('SELECT id,last_event_id FROM history_transactions ORDER BY id DESC LIMIT 1').fetchone());assert (boundary.txn_id,boundary.last_event_id)==(manifest['history_boundary']['transaction_id'],manifest['history_boundary']['last_event_id'])
 assert c.execute('SELECT MAX(id) FROM history_events').fetchone()==(boundary.last_event_id,)
 watermarks=corpus_watermarks(c);assert watermarks==(4,15,4216)
 to_wm=c.execute('SELECT MAX(change_seq) FROM history_events').fetchone()[0]
repo=HistoryRepository(state);pages=0;actions=[]
with repo.open_report_selection(ReportScopeRequest(boundary,0,to_wm,17)) as selection:
 cursor=None
 while True:
  page=selection.read_page('action',parent_id=2,cursor=cursor);pages+=1;actions.extend(page.items);cursor=page.next_cursor
  if cursor is None:break
 assert actions==list(range(4,4204)) and pages==248
with repo.open_report_selection(ReportScopeRequest(boundary,watermarks[0],watermarks[1],17)) as selection:
 assert selection.read_page('output',parent_id=1).items==(1,2,3,4)
assert digest(state)==manifest['database_sha256']; assert {str(p):digest(p) for p in (manifest_path,archive)}==original
result={'manifest_sha256':original[str(manifest_path)],'gzip_sha256':original[str(archive)],'database_sha256':digest(state),'metadata':metadata,'journal':manifest['journal_mode'],'boundary':[boundary.txn_id,boundary.last_event_id],'watermarks':watermarks,'selected_actions':len(actions),'pages':pages,'outputs':[1,2,3,4],'source_unchanged':True,'wall_s':time.monotonic()-start}
(base/'validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

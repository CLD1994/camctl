# 独立评审暂停点

评审者：audit_pending_stages。按 root 的收尾要求暂停，不再查询、测试或等待。此记录不是完整评审通过结论。

- 取消组工作区：`capture-cancellation`，已读 HEAD `876c105b524792f23c7fe33c79cf3070a4f6e3f0`；作者报告最终 123 passed／34.60 秒，PID 18229、exit 0。已读完整日志及收据，但尚未独立完成源清单、369 阶段记录和全部原节点映射核验。
- **已确认预算漂移，当前不宜按“原预算完整保留”批准集成。** `support/capture_cancellation_cases.py:198` 将全部 RESULTS 调用统一为 timeout=10、retry=0。原 `test_cancel_timelapse_exhaustion_files.py` 的 `_canceled_exhausted_world` 明确使用 `AttemptConfig(used, Decimal("1.25"), Decimal(0))`；新 14 项使用公共 world 的 10 秒。现存 final123 原始 DB `test_canceled_timelapse_keeps_0/state.db` 的 `results/1` 实际保存 `(max_attempts=1, timeout_s_json='10', retry_interval_s_json='0')`，证实不只是配置文本差异。
- 另有明确 1→10 秒漂移：原 `test_finite_cancel_review.py:29` 的 `_prior_and_current` 为 `AttemptConfig(2, Decimal('1'), Decimal('0'))`；新 `stored_result_case` 经上述统一配置。现存 DB `test_current_page_length_canno1/state.db` 的 RESULTS 实际为 `(2,'10','0')`。原有限取消部分测试也显式设 1 秒，新 world 未承接；逐节点完整影响数量尚未核完，不能将参数实例算成独立生产缺陷。
- 可执行修正建议：让共享 world 接受完整 RESULTS AttemptConfig 或 timeout/retry 参数；从各原场景传入原 max/timeout/retry，并在真实 operation_runs 与调用 request 上核对。先补旧→新完整预算矩阵，再验证受影响节点。尚未复核旧默认配置的 retry 等其他字段，不能只修两个已发现数字即宣告预算闭合。
- 已读源码的正面事实：新 world 由正式受理、SchedulingRepository、session_capture_assembly 工厂与 C1 推进，取消走真实 cancel_flow；冷重开会 drain 自有文件执行器并 restart 实际数据库 worker；晚到 START 使用真实端口门闩，唯一 STOP 的 `(1,10,1)` 在该 18 项显式保留。legacy `_cancel`／`_apply_public_cancel` 在本组业务测试中未调用。
- 18 项 bare `sent=True` 来源删除已由 root 按正式合同批准，本评审不重新要求恢复。新增 2 项是明确负向存储消费者合同，不能当作正常业务 SENT 来源。
- 尚未完成：四文件全量原断言与时刻映射、48 项存储/静态合同的完整独立核对、全部原始 DB 与 XML/阶段清单对照、剩余时钟及预算漂移排查。不得称“取消123独立评审通过”。
- cleanup 组：作者已自报 begin_read 的统一 AttemptConfig 漂移，root 暂停集成；新修正尚未验收。本评审仅初读作者报告与提交列表，没有继续检查或给出集成结论。

本次评审未修改生产或测试代码，未重跑任何测试。

# 暂停恢复现场清点（2026-10-30）

## 现场结论

主仓库当前为 `290f4ad39db1bffdf6b764e2ef77c97ce12a82fb`（父提交 `27713c14dbdf6dda445e3dd123745ba11d66a9cc`，分支 `fix/integration-failures-20261025`），清点前工作区干净。12 个清单目录都存在，各自仍有实际测试源码目录；但所有 `.git` 指针都指向不存在的 `/workspaces/camctl/.git/worktrees/...` 目标。因而无法读取真实 worktree HEAD、分支或当前未提交状态，manifest 中的 HEAD 只能保留为历史声明；12 个声明提交在主仓库对象库中也均不可读。`f060d999` 与 `876c105b` 对象不可读。

源码可从暂停目录直接取回，但 Git 提交身份及提交内外差异无法由这些目录验证。目标测试文件与当前主仓库同路径文件的字节均不同；三个支持文件在主仓库中缺失。因此只能确认源码快照仍可读取，不能据此声称行为已完整集成或验收。

## 12 个暂停目录

下表目录及后续文件路径都相对于 `/tmp/camctl-refactor-20261026/`。

下表的 Python 文件数是本次对各目录 `apps/camctl/tests/integration/**/*.py` 的枚举结果；HEAD 前缀来自 manifest，不是当前可读取的 Git HEAD。

| 目录 | 集成测试 Python 源文件 | manifest HEAD 声明 | Git 指针 |
| --- | ---: | --- | --- |
| `capture` | 553 | `1d3879a8` | `.git` 目标缺失 |
| `capture-cancellation` | 579 | `876c105b` | `.git` 目标缺失 |
| `bootstrap-runtime-owners` | 579 | `23849d29` | `.git` 目标缺失 |
| `capture-result-diagnostics` | 585 | `15b22e13` | `.git` 目标缺失 |
| `capture-media-consumers` | 572 | `32809198` | `.git` 目标缺失 |
| `capture-native` | 585 | `603a911f` | `.git` 目标缺失 |
| `bootstrap-cleanup-contracts` | 575 | `fbd538a4` | `.git` 目标缺失 |
| `capture-storage-guards` | 579 | `2c164401` | `.git` 目标缺失 |
| `bootstrap` | 553 | `094353b8` | `.git` 目标缺失 |
| `capture-recording-consumers` | 580 | `9c2a1acb` | `.git` 目标缺失 |
| `source-capacity-audit` | 581 | `9d36d1eb` | `.git` 目标缺失 |
| `evidence-stage4` | 584 | `a02f7549` | `.git` 目标缺失 |

## 三组目标源码

- **capture-cancellation：4 个测试文件和支持文件均在暂停目录。** manifest 归档本身只有报告与检查点，没有这五个完整源文件。当前主仓库中四个同名测试文件内容不同，`capture_cancellation_cases.py` 不存在。

- `capture-cancellation/apps/camctl/tests/integration/capture/test_cancel_late_start.py`
- `capture-cancellation/apps/camctl/tests/integration/capture/test_cancel_timelapse_exhaustion_files.py`
- `capture-cancellation/apps/camctl/tests/integration/capture/test_finite_cancel.py`
- `capture-cancellation/apps/camctl/tests/integration/capture/test_finite_cancel_review.py`
- `capture-cancellation/apps/camctl/tests/integration/support/capture_cancellation_cases.py`

- **bootstrap-cleanup-contracts：5 个测试文件和支持文件均在暂停目录。** 六个文件的现场 SHA-256 全部与压缩报告中的 `final_source_files` 相符；归档本身只有报告，没有完整源码。当前主仓库中五个同名测试文件内容不同，`bootstrap_cleanup_cases.py` 不存在。

- `bootstrap-cleanup-contracts/apps/camctl/tests/integration/bootstrap/test_cancel_obtain_settlement_transactions.py`
- `bootstrap-cleanup-contracts/apps/camctl/tests/integration/bootstrap/test_cancel_ready_transactions.py`
- `bootstrap-cleanup-contracts/apps/camctl/tests/integration/bootstrap/test_cleanup_original_config.py`
- `bootstrap-cleanup-contracts/apps/camctl/tests/integration/bootstrap/test_download_cleanup.py`
- `bootstrap-cleanup-contracts/apps/camctl/tests/integration/bootstrap/test_osmo_file_cleanup.py`
- `bootstrap-cleanup-contracts/apps/camctl/tests/integration/support/bootstrap_cleanup_cases.py`

- **capture-native：三个报告涉及的测试文件及支持文件都在暂停目录。** 归档里只有补丁、报告和检查点，没有完整源文件；manifest 声明工作区当时有 `test_timelapse_host_timer.py` 与 `native_capture_cases.py` 两项未提交变化，但该状态现无法从 Git 核实。当前主仓库的三个同名测试文件内容不同，`native_capture_cases.py` 不存在。

- `capture-native/apps/camctl/tests/integration/capture/test_native_segment_completion.py`
- `capture-native/apps/camctl/tests/integration/capture/test_record_file_completion_wait.py`
- `capture-native/apps/camctl/tests/integration/capture/test_timelapse_host_timer.py`
- `capture-native/apps/camctl/tests/integration/support/native_capture_cases.py`

## 压缩证据核验与边界

manifest 的 26 个压缩附件全部存在；逐一完整解压后，gzip 校验、未压缩字节数和清单 SHA-256（按解压载荷）均通过。分类为 20 份报告／检查点、4 个工作树补丁和 2 个完整支持源码文件。两个完整源码文件属于 `capture`，不是上面三组目标源码。每个附件的路径与核验状态见同目录 `inventory.json`。

本次没有运行测试、应用补丁、重建 Git 提交或改写源码；只在授权目录写入这份 Markdown 和 `inventory.json`。

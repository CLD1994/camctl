# persistence 首因归类（2026-10-30）

## 执行事实

`cases.json` 与 `inventory.json` 都列出 952 个相同顺序的 nodeid；其中 889 项通过、63 项失败。结果文件的 `package-resources` 外层准备退出码为 0。63 个失败的 pytest setup 与 teardown 都通过，失败都发生在 `call` 阶段。日志第 3946 行记录 `63 failed, 889 passed`。

## 首因

目前只识别到 **一个共享首因 C1**，覆盖全部 63 个失败身份。测试体在准备基础活动／计划时，调用链进入 `database_path(owned)`；日志中 `database_path` 的参数注解为 `OwnedConnection`，实际对象表示为 `BusinessDatabase`。第一个异常是：

```text
AttributeError: 'BusinessDatabase' object has no attribute 'connection'
```

代表完整链位于 `output.log:16-46`：测试从 `test_baseline_read_facts.py` 进入 `_intent`，经 `capture/test_baseline_history.py:35` 的 `_activity` 与 `scheduling/test_start_action.py:75` 的 `_accept_plan`，最后在 `support/database.py:45` 读取 `owned.connection` 时抛出异常。日志异常位于第 44 行，失败帧位于第 46 行。63 个失败段均各有一条相同异常，并包含相同的 `_activity`、`_accept_plan` 和 `database_path` 路径。
每个失败的测试栈第一条测试语句也都只是在调用 `_intent`（日志显示三种写法，合计 63 项）；因此没有用例越过公共前置活动准备进入自己的目标动作。

因此这 63 项是**共享准备链阻断**：这些用例的目标操作和目标断言均未到达；不能把它们计作 63 条独立生产行为失败。这里的“准备”发生在 pytest `call` 阶段的测试体内部；pytest fixture setup 已通过，外层资源准备也已通过。

## 文件与参数组

全部失败来自 `tests/integration/persistence/test_baseline_read_facts.py`，分布在 20 个测试函数／参数组。数量最多的五组如下；63 个完整 nodeid 到 C1 的映射、每个失败段的首异常行与原因帧行均保存在同目录 JSON。

| 测试函数 | 失败身份数 |
| --- | ---: |
| `test_return_group_is_complete_in_both_entrypoints` | 16 |
| `test_unknown_guard_checks_original_call_and_unique_group` | 16 |
| `test_intent_requires_actual_activity_binding_and_scope` | 4 |
| `test_kernel_checks_actual_binding_in_both_entrypoints` | 4 |
| `test_actual_return_saves_one_atomic_group` | 4 |

## 待契约判断

现有四份 artifacts 能确认 `database_path` 的日志注解与实际传入对象不一致，但不能确定该边界的预期公开契约，也不能据此归责到某个调用方或支持层。需要先核对这个边界约定；在此之前，这批结果只归类为 C1 准备失败，生产行为结论保持未定。

本次只读取指定的四份 artifacts；没有读取源文件或运行器，没有重跑测试，也没有读取或干扰其他仍运行的目录。

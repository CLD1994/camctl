# diagnostic-other14 剩余失败首因清点（2026-10-30）

## 汇总与身份核对

只展开 outputs 22、reporting 3、operations 6，共 31 个失败身份。14 个任务均已终态；`summary.json` 状态为 `finished`、任务数 14、`jobs=1`。14 组 `inventory.json` 与 `cases.json` 的身份顺序逐组完全一致；总数 6,635、唯一身份并集 6,635、跨任务重复 0。cases 聚合为 6,539 通过、94 失败、2 跳过，与 summary 中各任务 progress 汇总相符。报告不重查 persistence 的 63 个失败。

## 时间口径

| 记录 | 汇总秒数 |
| --- | ---: |
| pytest setup 阶段时长合计 | 171.385 |
| pytest call 阶段时长合计 | 990.288 |
| pytest teardown 阶段时长合计 | 33.241 |
| 各任务 progress elapsed 合计 | 1233.498 |
| 14 个任务 wall_seconds 合计 | 1296.133 |
| summary 总墙钟 | 1302.624 |

这些是分别记录的阶段、任务和 summary 时长；不据此外推提速或生产延迟。

## 31 个失败身份的首因组

所有 31 项均是 pytest `call` 阶段失败，pytest setup/teardown 通过。日志得到 11 个可区分的首因观察，按五类汇总：awaitable／异步迭代对象的调用形态 17 项、数据库结果期望不符 9 项、baseline 资源范围拒绝 2 项、停止读取后记录 ERROR 1 项、数值边界断言 2 项。分类只说明本次测试如何失败，不判定生产缺陷。

| 原因 | 身份数 | 文件范围 | 首个可见失败 | 代表日志段 |
| --- | ---: | --- | --- | --- |
| C1 | 4 | `tests/integration/outputs/test_cleanup_source_resolution.py` | 测试体内准备失败 | `tasks/003-camctl-outputs/artifacts/output.log:38-49` |
| C2 | 3 | `tests/integration/outputs/test_cleanup_terminal_absence.py` | 测试观察表达式失败 | `tasks/003-camctl-outputs/artifacts/output.log:84-112` |
| C3 | 4 | `tests/integration/outputs/test_cleanup_terminal_absence.py` | 恢复装配阶段失败 | `tasks/003-camctl-outputs/artifacts/output.log:171-236` |
| C4 | 3 | `tests/integration/outputs/test_grant_reuse.py` | 数据库结果断言不符 | `tasks/003-camctl-outputs/artifacts/output.log:408-422` |
| C5 | 1 | `tests/integration/outputs/test_read_diagnostics.py` | 实际读取链记录了错误结果 | `tasks/003-camctl-outputs/artifacts/output.log:453-486` |
| C6 | 3 | `tests/integration/outputs/test_segment_copy_maintenance.py` | 测试支持准备失败 | `tasks/003-camctl-outputs/artifacts/output.log:487-509` |
| C7 | 1 | `tests/integration/outputs/test_source_resolution_batches.py` | 测量断言超过测试阈值 | `tasks/003-camctl-outputs/artifacts/output.log:559-644` |
| C8 | 3 | `tests/integration/outputs/test_video_scope_photos.py` | 测试读回表达式失败 | `tasks/003-camctl-outputs/artifacts/output.log:645-674` |
| C9 | 2 | `tests/integration/reporting/test_software_recovery_reports.py` | 测试场景前置范围被拒绝 | `tasks/005-camctl-reporting/artifacts/output.log:9-34` |
| C10 | 1 | `tests/integration/reporting/test_worker_diagnostics.py` | 诊断长度断言超过测试上限 | `tasks/005-camctl-reporting/artifacts/output.log:99-102`（异常与原因帧） |
| C11 | 6 | `tests/integration/operations/test_read_attempt_slot.py` | 数据库结果断言不符 | `tasks/007-camctl-operations/artifacts/output.log:7-26` |

C4 和 C11 的结果对象分别显示调用返回 `COMPLETED/GRANTED`、`error=None`，测试期待 `ROLLED_BACK`；日志没有证明各自的读故障注入是否命中。C2、C3、C8 的异常发生在读取／恢复装配表达式；异常之前的业务步骤是否完成不由该失败段裁决。C1、C6、C9 的失败发生在测试前置环境尚未构建完成时。

C5 的完整读取诊断位于 `tasks/003-camctl-outputs/artifacts/output.log:453-486`。记录显示读取结束为 5 字节、`error=null`、`stopped=true`，流程返回 `local_read_failed` 并记为 `ERROR`；其嵌入错误链为：`apps/camctl/src/camctl/outputs/obtain_flow.py:920 _copy_delivery` → `apps/camctl/src/camctl/capture/media_flow.py:216 transfer` → `apps/camctl/src/camctl/outputs/copy.py:538 copy_next_segment` → `apps/camctl/src/camctl/outputs/copy.py:545 _owned_copy_operation` → `apps/camctl/tests/integration/outputs/test_read_diagnostics.py:231 run_owned_async_file_task` → `apps/camctl/src/camctl/host_files/tasks.py:300 run_owned_async_file_task` → `apps/camctl/tests/integration/outputs/test_read_diagnostics.py:230 run` → `apps/camctl/src/camctl/outputs/copy.py:575 _copy_next_segment`。该事实未被提升为生产缺陷结论。

每个 nodeid 对应的原因编号、日志段、所有 `E` 行和最后异常帧行见同目录 JSON。需要契约判断的边界包括异步辅助入口的调用方式、baseline 资源范围、读错误注入是否命中及其结果约定、停止读取的诊断语义，以及 2,000,000 字节／65,536 字节断言的边界规则。当前 artifacts 不足以裁决这些契约。

本次仅读取 summary 与 14 组 cases/inventory 元数据，以及 outputs、reporting、operations 三份失败日志；没有重跑测试、读取源文件／运行器／数据库，或干扰其他任务目录。

import functools
import json
from pathlib import Path
import time

_OUTPUT = Path('/tmp/camctl-cleanup-refactor-evidence-20261107/before/phases.jsonl')

def pytest_collection_modifyitems(items):
    from _cleanup_roundtrip_support import World
    from _cleanup_source_snapshot import CompletedOsmoSource
    for cls, names in (
        (World, ('__init__', '__exit__', 'prepare_osmo', 'prepare_hasselblad', 'publish_copies', 'clean_exact', 'assert_report_ack_and_history', 'export', 'start', 'stop')),
        (CompletedOsmoSource, ('__init__',)),
    ):
        for name in names:
            original = getattr(cls, name)
            label = f'{cls.__name__}.{name}'
            @functools.wraps(original)
            def timed(self, *args, __original=original, __label=label, **kwargs):
                started = time.monotonic()
                outcome = 'returned'
                try:
                    return __original(self, *args, **kwargs)
                except BaseException:
                    outcome = 'raised'
                    raise
                finally:
                    record = dict(phase=__label, argument=str(args[0]) if args and isinstance(args[0], str) else None, started=started, ended=time.monotonic(), outcome=outcome)
                    with _OUTPUT.open('a') as output:
                        output.write(json.dumps(record) + '\n')
            setattr(cls, name, timed)

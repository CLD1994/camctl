媒体保存并发冲突的只读交接

这份证据确认默认会话会在媒体拥有者仍占用输入文件时，从另一条恢复入口为原申请再申请同文件资格。执行器正确拒绝该并发申请，调度因此先进入状态库错误退出。随后原媒体拥有者收到停止请求，在 ffprobe 尚未启动时形成 FAILED/tool_cancelled 观察；测试在这份失败观察的保存上注入 COMMIT 后丢回执 UNKNOWN。不能把这次执行记为“真实 probe 已完成后，UNKNOWN 重送导致文件冲突”。

来源及范围

- 只读来源：/tmp/camctl-resume-20261030/evidence/work-files-media-6，证据提交6fc6a59cbff01b56814156d6d089e23e55d2e9bc，生产树9c2b982aa4050c25646e40b6500ebad3a84a8661。
- execution.json记录PID60992、解释器Python3.11、隔离工作树、本树camctl.__file__及命令。result.json记录退出1、墙钟1.567秒；pytest.log为1failed/0.96秒。
- 唯一失败是 tools.calls == ["probe"]，实际为空。此前 outcome.state_db_error、一次非RUNNING保存UNKNOWN以及原错误出现在公共details的断言均已通过。
- 本次未修改任何仓库或原始证据，未运行pytest或heavy任务。仅以mode=ro读取保留的DB；派生read-only-facts.json逐行保留以下事实。其它轮询配置通过与这次0.001配置失败分别成立，不能互相替代。

公开准备与原参数

RecordingCase经真实accept_input、SchedulingRepository.observe_window/start_action、session_capture_assembly→capture_handler发出START。驱动返回正式recording_sent证据，受理目录在原任务定义中指定SENT。目标时长60秒、启动余量10秒、启动窗口max_delay_ms=5000均保留；started_at为1749999925000000，恢复NOW为1750000000000000，UTC相差75秒。原单调钟5_000_000_000ns；defaultsession的capture时间替身返回80_000_000_000ns，SystemClock替身FixedClock返回0ns，二者UTC同为NOW。准备的真实worker重开，case与capture_resources显式关闭，然后build_runtime(CommandMode.RUN)+run_default_session以poll_interval_s=0.001运行。

完整性边界：候选使用了两个不同单调钟读数。没有证据表明两个读数相互比较后触发本次冲突，但后续准备宜让这两个正式时钟入口共享同一受控读数；不能仅以UTC相同宣称时钟替身完整验收。这个核对不能替代已经直接发生的文件拥有者并发事实。

恢复时仍使用已保存的execution_spec：DB actions[1]为target_duration_ms=60000、start_return_meaning=1(SENT)、startup_margin_ms=10000；event1同样保存该定义，故defaultsession使用_Catalog不把旧定义改回STARTED。当前注册表的DriverEntry保留原证据契约和READ/digest能力，只将result_supported设为true并提供正式ResultDriver.list_results。真实STOP保存stop_confirmed，结果/输入复制按生产链产生；event18已经把检查决定保存为required(3)，reason2。intermediate_file1是recording-inputs/1.mp4，10字节及SHA256已可靠保存。源工具设置为200秒h264视频，检查完成后应先保存该观察；非RUNNING保存失败时不应推进依赖它的修复决定。真实脚本通过PATH的ffprobe/ffmpeg包装进入，未替换生产工具执行算法。

直接证实的事实

1. test.patch:107-108明确对CheckPhase.RUNNING调用真实仓储，不注入UNKNOWN；:109-113仅非RUNNING才使用TransactionFault(after_commit=True)，要求真正一次COMMIT及UNKNOWN。
2. camctl.log唯一主错误是“流程scheduling异常：同文件已有未结束任务：file1任务media_check/1/67ab8d3e1485574c04653d06fad6e436”。栈依次为session/service.py:1421、bootstrap/flows.py:216/:94、work_file_assembly.py:63、capture/media_flow.py:466、host_files/tasks.py:313/:287/:404。
3. DB event39/transaction27为check_state NOT_PERFORMED→RUNNING及media.check_status=running。event40/transaction28为RUNNING→FAILED，source_probe.error是“tool_cancelled: 工具尚未启动，停止请求已生效”，tool_control=true。最终recording_processing.media_json同为FAILED/tool_cancelled。
4. 事务28的operation_key为c540d9803dc370293553bde319bcceda，和退出诊断中尚未确认的原媒体保存key完全相同。因此候选实际注入的command.phase是FAILED；CheckResultSave.phase定义为media.phase。它不是COMPLETED探测结果。
5. UNKNOWN及“原媒体申请尚未可靠保存”的错误均在camctl.log的shutdown secondary_errors。host_files/media.py:418仅在受管工具stopped_before_start时产生上述tool_cancelled结果；没有calls.jsonl，pytest实际tools.calls=[]。本次没有ffprobe启动、退出、JSON解析失败的原始工具错误。应保留原FileTaskError、停止控制观察与后来SQLite COMMIT丢回执三种事实，不将它们合并成一个工具错误。
6. FileTaskExecutor._admit只查询当前执行器实例自己的_files字典；字典在构造时新建。出现这条冲突意味着报错瞬间同一执行器中file1还属于media_check，不能由另一个旧执行器的残留记录直接造成。对方是实际文件占用尚未释放的原媒体拥有者，不只是保存的RUNNING投影。
7. 原准备历史event1-10仅含受理、动作开始和START结果，没有intermediate_files或媒体检查事件。默认lifecycle新建WorkFileRuntime及FileTaskExecutor，已关闭的准备factory没有向它转移任务字典。故“准备阶段残留旧media task跨执行器污染”的解释与现有数据流不符。

直接证据尚未覆盖的细节

没有冲突瞬间的held.command快照、协程ID或高分辨率提交时间戳，不能把“恢复入口当时正看见RUNNING申请”说成日志直接捕获。由probe未启动、停止控制FAILED只在退出收场形成，以及_save_held在首次RUNNING保存前发布pending的代码顺序，可以强推断冲突窗口是原RUNNING保存仍在途；若需精确到原申请phase和stage_owner实际任务，须另立窄观察收据。也未观察原媒体任务当时处于数据库读取、写入或回执应用中的哪一步；_admit只直接证明其文件拥有范围未结束。

根因与正式契约

- lifecycle.py:808将deps.capture_media_results交给WorkFileRuntime；:878/:888将同一集合与work_files.executor交给scheduling的生产拍摄工厂；残留工厂也按:916/:926共享。WorkFileRuntime.resume_media_results(:63)再次将同一executor及pending集合传至resume_media_saves。
- CaptureProcessingSaves._save_held(media_flow.py:316-329)在首个DB读取/写入之前发布完整原申请和文件集合，然后通过RequiredSaveStage.run提交。RequiredSaveStage(save_stage.py:8-24)原本允许并发入口加入同一个正在执行的必需阶段。
- resume_media_saves(media_flow.py:456-468)却在加入该阶段之前，先以另一个任务media_save/<key>为held.file_ids申请文件资格。原media_check拥有范围包含检查运行阶段、工具和结果保存(media.py:415-447)，尚未释放file1。执行器tasks.py:398-406按契约拒绝并发文件占用；它没有错误地释放原文件。
- 正式file-runtime.md:184-192规定文件资格随实际结束释放，媒体与同步任务共用占用登记；2026-10-09 work-file-runtime计划“实际文件入口”及完整异步拥有范围要求同一拥有者沿原申请/key/时刻继续，内部同协程子集继承、派生并行任务不继承。当前恢复入口同时承担原申请协作与异任务新占用，两种责任在准入前未协调。
- 可确证的生产问题是：正式恢复消费者与仍活动的原媒体保存竞争相同文件资格，导致普通合法轮询窗口下自我终止。它不依赖注入UNKNOWN才能在逻辑上成立；但本次没有额外运行不带故障注入的复现，不能声称已有该独立运行收据。

修复责任与不变量（只交接，不实施）

责任属于capture.media_flow的原保存协调与bootstrap默认消费者接线，需要统一核对scheduling、residual、取消目标入口和run_recording_media中的所有resume调用。FileTaskExecutor的跨拥有者独占拒绝应保留。

修复要明确区分：原拥有者仍在执行原保存阶段、原拥有者结束但同会话仍持原未确认结果、以及新run只剩持久化事实。第一类应加入原必需保存阶段，不能先作为异任务重占原文件；第二类仍须在原身份/key/时刻及全部关联文件范围下核实，不重新probe/READ/造输出；第三类沿正式历史恢复，不能补造旧内存结果。设计可以选择实际协调接口，但不能按任务名前缀或只因file_id相同就放宽外部占用，也不能移除某一个默认消费者来隐藏其它入口的同类问题。

阶段替换与快照同样需核对：旧RUNNING已提交、pending原身份已移除并换为后续观察申请时，恢复者不能将旧stage_owner误用于新申请；并发加入、回执消费、申请移除分别保持一次性。等待者取消只停止该等待；原实际任务及必要保存继续收场，文件、连接和会话锁在结束前保持。

待验证矩阵

| 状态/组合 | 必须证明的结果 |
|---|---|
| 原CHECK RUNNING保存仍在途，scheduling/residual/动作自身恢复入口并发到达 | 加入同一原阶段；不发第二probe，不申请异任务的同文件占用，不产生FileTaskError。真实提交后再开始工具。 |
| probe正在真实执行，无待存原申请 | 后续调度不重复媒体执行；输入仍独占；外部取消后等待真实退出及保存。 |
| probe已完成，CHECK观察保存仍在途 | 原phase/source_probe/完整观察/key/时刻相同；恢复只加入原保存；零重复READ/probe。 |
| RUNNING及终态观察分别发生回滚、COMMIT前UNKNOWN、COMMIT后UNKNOWN | 回滚和未知分别保留真实边界；未可靠确认前不启动依赖阶段；原键核实，不退回新工具调用。 |
| 原媒体拥有者已结束、同会话保留未确认申请 | 正式LocalWorkPort仍表达责任；原结果保存前会话锁和DB责任不能提前完成；核实成功后只消费一次。 |
| REPAIR决定、输出登记、实际修复结果、输出完整性保存 | 原输入/输出全部文件集合、阶段接续与原输出身份保持；不能扩大文件集的内层任务死锁或重造输出。 |
| 相同原申请并发加入 / 不同申请占同文件 / 两个处理对象占不同文件 | 只有第一类共享原阶段；第二类仍明确拒绝；第三类允许并行且错误分别交付。 |
| 同阶段原token已移除、下一申请替换；等待者取消及重复取消 | 不将旧回执应用到新申请，不释放仍在使用的文件，不遗漏原异常、回执和资源关闭。 |
| 默认轮询与0.001配置 | 分别保留真实输入、工具启动/退出、保存阶段及收场收据；默认轮询的成功不能抹掉0.001失败。 |
| 两份真实媒体保存失败叠加四类原主错误 | 先证明两个工具都真实进入并取得各自结果、各原保存错误形成；只验证业务时序可达的主错误组合，保留全部原错误、必要停止及锁/worker收场。 |

可继续工作的边界

1. 本候选默认会话暂时不能充当“probe完成后结果UNKNOWN”的见证。将门闩加在probe内只能在已进入工具后控制结束，挡不住本次发生在工具启动前的原RUNNING保存窗口；增加轮询间隔或依赖线程更快提交也不能形成可靠承接。
2. 可独立补一个生产者组件见证：仍用相同SENT/60/10/75秒公开受理与正式session_capture_assembly→capture_handler，直接等待这一次正式handler推进；真实工具脚本记录启动/退出后，公开CaptureRepository.save_check_result限定phase=COMPLETED且source_probe无error再一次性注入真正COMMIT后丢回执。断言工具恰一次、原媒体观察真实、DB完整保存以及原错误。之后若验证同拥有者原键重送，仍调用同一正式factory的handler，关闭一次故障，比较公开仓储记录的完整command/key/time和工具/READ次数；不能构造WorkFileRuntime或注入pending。这是实际生产者及原保存组件目标，不宣称完整默认会话聚合已经承接。
3. 若要从已保存RUNNING恢复后进入默认会话，必须先经真实handler在公开RUNNING保存边界中断并实际结束旧worker，不可SQL置check_state或植入pending。这个准备可以排除首次RUNNING保存的窗口，但完成观察保存时仍可能触发同一并发缺口，不能据此保证完整旧目标可验收。
4. 原8个测试中有关默认会话主/次错误、两份本地责任及维护聚合的目标仍须逐目标保留，不能由上面的窄生产者见证自动替代。其它first-result/ready/cancel公开路径可继续独立推进。是否保留某个纯内部聚合输入为局部端口测试，仍由root与用户处理边界，不由本诊断默认批准。

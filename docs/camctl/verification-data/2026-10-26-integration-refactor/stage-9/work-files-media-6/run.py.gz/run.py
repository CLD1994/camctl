import os, subprocess, time, json, pathlib
root='/tmp/camctl-resume-20261030/boundary-work-files'
evidence=pathlib.Path('/tmp/camctl-resume-20261030/evidence/work-files-media-6')
py='/workspaces/camctl/apps/camctl/.venv311/bin/python'
env=os.environ.copy(); env['PYTHONPATH']=root+'/apps/camctl/src:'+root+'/apps/camctl/tests'
cmd=[py,'-m','pytest','apps/camctl/tests/integration/bootstrap/test_media_local_settlement.py::test_default_session_reports_unconfirmed_media_save_after_real_probe','-q','--basetemp',str(evidence/'tmp'),'--junitxml',str(evidence/'results.xml')]
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
module=subprocess.check_output([py,'-c','import camctl; print(camctl.__file__)'],cwd=root,env=env,text=True).strip()
start=time.monotonic()
with (evidence/'pytest.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 (evidence/'execution.json').write_text(json.dumps(dict(pid=p.pid,argv=cmd,cwd=root,git_sha=sha,camctl_file=module),indent=2))
 code=p.wait()
 (evidence/'result.json').write_text(json.dumps(dict(exit_code=code,wall_seconds=time.monotonic()-start),indent=2))
print(code, time.monotonic()-start)

import json,sqlite3,pathlib,xml.etree.ElementTree as ET
base=pathlib.Path('/tmp/camctl-resume-20261030/evidence/ready-remaining'); root=base/'baseline-tmp'; records={}
for d in sorted(root.glob('test_*')):
 p=d/'state.db'
 if not p.is_file(): continue
 c=sqlite3.connect(p); c.row_factory=sqlite3.Row
 tables={r[0] for r in c.execute("select name from sqlite_master where type='table'")}; rec={}
 for t in ('actions','deliveries','cancel_items','cancel_delivery_items','file_copies','history_transactions'):
  if t in tables: rec[t]=[dict(r) for r in c.execute('select * from '+t)]
 rec['files']={str(f.relative_to(d)): {'size':f.stat().st_size} for folder in ('ready','processing','staging') for f in (d/folder).rglob('*') if f.is_file()}
 records[d.name]=rec; c.close()
(base/'baseline-db-facts.json').write_text(json.dumps(records,ensure_ascii=False,indent=2,default=str))
print('databases',len(records)); print('nodes',len(ET.parse(base/'baseline.xml').findall('.//testcase')))

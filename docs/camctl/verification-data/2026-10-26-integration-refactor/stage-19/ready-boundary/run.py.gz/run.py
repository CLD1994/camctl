import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path('/tmp/camctl-resume-20261030/ready-remaining'); out=pathlib.Path('/tmp/camctl-resume-20261030/evidence/ready-remaining'); name=sys.argv[1]
def hashes():
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for base in ('apps/camctl/src','apps/camctl/tests') for p in sorted((root/base).rglob('*')) if p.is_file() and '__pycache__' not in p.parts and not p.suffix=='.pyc'}
(out/f'{name}-before.json').write_text(json.dumps(hashes(),indent=2))
argv=['/workspaces/camctl/apps/camctl/.venv311/bin/python','-m','pytest','apps/camctl/tests/integration/bootstrap/test_cancel_ready_runtime.py','-vv','--durations=0',f'--junitxml={out}/{name}.xml',f'--basetemp={out}/{name}-tmp']
env=os.environ.copy(); env['PYTHONPATH']=f'{root}/apps/camctl/src:{root}/apps/camctl/tests'; start=time.time()
with (out/f'{name}.log').open('w') as log:
 p=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/f'{name}-process.json').write_text(json.dumps({'pid':p.pid,'argv':argv,'cwd':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'start':start,'PYTHONPATH':env['PYTHONPATH']},indent=2))
 rc=p.wait()
(out/f'{name}-after.json').write_text(json.dumps(hashes(),indent=2)); (out/f'{name}-exit.json').write_text(json.dumps({'exit':rc,'elapsed':time.time()-start},indent=2)); print(name,rc,time.time()-start)

# 取消交付的九个待迁移参数实例

基线 d5bc909b8998a44a2946b80ae2107ddf0e6f8931；生产树 9c2b982aa4050c25646e40b6500ebad3a84a8661。15 个实例的完整运行、节点身份和耗时见 baseline.xml、baseline.log；逐文件运行前后摘要见 baseline-before.json 和 baseline-after.json。没有修改测试或生产源码。

三项 `test_actual_withdrawal_result_is_held_with_original_key_after_save_failure[projection|commit_before|commit_after]`：两张照片来自受理请求 1，经请求 2 取回，两个 delivery 已实际发布，取消请求 3 寻址取回动作。实际 unlink 一次后，在 WITHDRAWN 结果更新 cancel_delivery_items 的投影、COMMIT 前、COMMIT 后分别注入错误；要求再次传递同一完整 command 与 key，且各文件只 unlink 一次，两个撤回成功，取消动作成功。

六项 `test_held_actual_withdrawal_failure_remains_cancel_failure_after_save_recovery[projection|commit_before|commit_after-failed|unknown]`：同样的合法准备；两个 unlink 分别注入 OSError 或 InterruptedError，第二份交付的 FAILED 或 UNKNOWN 原结果分别在上述三处保存失败。要求重送同一 command/key，两个文件都不再次操作，分别保存 withdrawal_state 5 或 6、成员错误 1 或 2、取消动作失败、原动作结束且取消标记清除；再次调用不改变数据库。XML 给出参数完整顺序。

基线实际数据库 facts 在 baseline-db-facts.json，每个世界有两项 copy，round 1、recopies_used 0、max_recopies_used 0、source_size 和 committed_bytes 都为 19；工作文件限额 batch_size 32、limit_per_run 1，获取段大小 4，UTC 为 _NOW，monotonic_ns 为 0。操作 key 留存在 history_transactions；旧测试仅在内存比较两次输入相等，并未输出它们与特定数据库事务的映射，不能从这些数据声称已直接记录原申请 key。

公开默认会话由 build_runtime/execute_command 装配。取消流程保存失败转换为 StateDbFailure；session.service._drive_flows 立即返回 state_db_error，错误路径停止新增工作并收场。WorkFileRuntime.settle 排空监督器且检查媒体保存，但不重新提交 pending_withdrawals。旧测试自行创建 WorkFileRuntime、在两次 cancel_flow 调用间持有该对象，再次调用取消流程。仅能导入 WithdrawalContext/withdraw_delivery 不证明其为文档约定的公开入口；它要求调用方提供内部 pending 字典和 FileTaskExecutor。当前未找到可向同一默认会话拥有者交付重送命令的公开入口，故无法以公开接口证实原 command/key 不变、文件只操作一次及后续汇总的联合不变量。新会话只凭持久化状态恢复，不能承接同一内存拥有者的原申请。需要设计方确认生产责任及正式入口后再迁移；不修改生产代码，也不删除、跳过或减弱原九项。

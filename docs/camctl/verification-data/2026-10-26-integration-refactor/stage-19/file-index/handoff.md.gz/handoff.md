# 519d 清单静态计数修正交接

本次仍审计冻结提交 `519d1e8e4339e53d34059eb41c0250a2f65d9405`。正式JSON与摘要只改文档；没有运行pytest或构建，也没有修改生产代码或测试代码。

## 原校验错误及修正

旧校验器仅对 `file_role == test_source` 的文件运行 AST。它因此把 `tests/integration/test_action6_segmented_media_fixtures.py` 当作纯支持文件，未计入第28行定义的顶层 `test_action6_media_fixture_contains_real_ordered_segments_and_photo`。函数第16行有环境 `skipif`，第20至26行有两个参数值。静态定义计1；当前环境是否收集、是否有边界迁移事项仍未确认，所以没有把两个参数值登记为待迁节点。

旧计数还只统计 `Test*` 类方法，漏掉 `tests/integration/test_database_history_sql.py` 两个直接继承 `unittest.TestCase` 的类：`DatabaseRuntimeRequirements`（第18行，2个 `test_*` 方法）和 `DatabaseStructure`（第44行，25个 `test_*` 方法）。已在AST计数器中识别 `unittest` 模块别名及 `from unittest import TestCase as ...` 直接父类写法；该冻结源码中两类共27个方法。

修正后在全部651个 `.py` blob 上逐文件解析AST，统计模块级 `test_*` 函数、`Test*` 类方法和直接继承 `unittest.TestCase` 的类方法：3866个定义，分布在546个文件。`skipif` 不剔除静态定义，参数化实例不展开。媒体夹具文件现标为 `test_source`，同时说明它也承载支持代码；状态改为“尚未关联既有边界评审证据”，不当成已确认待迁。

## 非Python文件的角色依据

- 四个MJS模块均导入 `node:test` 的 `test` 并含实际 `test()` 调用点：`event-transitions.test.mjs` 15处、`report-dependencies.test.mjs` 29处、`report-dependency-conditions.test.mjs` 8处、`video-coverage-protocol.test.mjs` 3处，合计55处。没有展开循环及参数化案例。
- `client_driver.ts` 由集成测试经Node子进程运行；`tests/integration/README.md` 第117、135、153、164行说明其客户端服务命令。文件有 `main()`（第1357行），不是 `node:test` 测试模块。
- `device_capability_browser.ts` 由 `test_device_capability_declarations.py` 启动（调用在第264行附近），文件有 `main()`（第27行），编排浏览器与客户端服务流程，不注册 `node:test` 测试。
- `motor_host_driver.c` 由 `test_camctl_motor_notifications.py` 编译并启动（编译入口在第37行附近）。其 `main()` 在第29行，调用公共 `camctl_host_register_motor_control_callback`、`camctl_host_init`、`camctl_host_submit` 和 `camctl_host_claim`。

## 可复核文件

- 全量静态校验器：`validate_all_sources.py`。它从冻结Git对象独立取出并解析每一个Python源文件，再逐行比较JSON；不使用角色字段决定是否解析。
- 完整校验结果：`validation.json`。其中 `prior_validation_failure` 保留旧校验器的失败根因。
- 首次计数校验收据：`validation-before-ast-correction.json`，作为已被后续复核推翻的历史记录保留。

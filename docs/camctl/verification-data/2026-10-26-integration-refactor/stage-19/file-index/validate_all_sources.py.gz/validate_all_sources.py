import ast, collections, gzip, hashlib, json, re, subprocess
from pathlib import Path

W = Path('/tmp/camctl-resume-20261030/refactor-status-ledger')
COMMIT = '519d1e8e4339e53d34059eb41c0250a2f65d9405'
J = W / 'docs/camctl/integration-test-refactor-status.json'
M = W / 'docs/camctl/integration-test-refactor-status.md'
R = W / 'docs/camctl/README.md'
E = Path('/tmp/camctl-resume-20261030/evidence/refactor-status-ledger')

def blob(path):
    return subprocess.check_output(['git', 'show', f'{COMMIT}:{path}'], cwd=W)

def py_test_definitions(source):
    tree = ast.parse(source.decode('utf-8'))
    unittest_aliases = set()
    testcase_aliases = set()
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == 'unittest':
                    unittest_aliases.add(alias.asname or 'unittest')
        elif isinstance(node, ast.ImportFrom) and node.module == 'unittest':
            for alias in node.names:
                if alias.name == 'TestCase':
                    testcase_aliases.add(alias.asname or alias.name)
    count = 0
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('test_'):
            count += 1
        elif isinstance(node, ast.ClassDef):
            is_test_class = node.name.startswith('Test')
            is_unittest_case = any(
                ast.unparse(base) in testcase_aliases or
                any(ast.unparse(base) == f'{alias}.TestCase' for alias in unittest_aliases)
                for base in node.bases
            )
            if is_test_class or is_unittest_case:
                count += sum(
                    isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and method.name.startswith('test_')
                    for method in node.body
                )
    return count

D = json.loads(J.read_text())
assert D['snapshot']['commit'] == COMMIT
assert subprocess.check_output(['git', 'merge-base', '--is-ancestor', COMMIT, 'HEAD'], cwd=W) == b''
changed_since_snapshot = subprocess.check_output(['git', 'diff', '--name-only', f'{COMMIT}..HEAD'], cwd=W, text=True).splitlines()
assert set(changed_since_snapshot) <= {
    'docs/camctl/README.md',
    'docs/camctl/integration-test-refactor-status.json',
    'docs/camctl/integration-test-refactor-status.md',
}, changed_since_snapshot
tracked = subprocess.check_output(['git', 'ls-files', '-z', 'apps/camctl/tests/integration', 'tests/integration'], cwd=W)
actual_paths = sorted(item.decode() for item in tracked.split(b'\0') if item and item.decode().endswith(('.py', '.ts', '.tsx', '.js', '.mjs', '.c')))
rows = D['files']
by_path = {row['path']: row for row in rows}
assert len(rows) == len(by_path) == 658
assert set(actual_paths) == set(by_path)
assert D['snapshot']['tree'] == subprocess.check_output(['git', 'rev-parse', f'{COMMIT}^{{tree}}'], cwd=W, text=True).strip()

lang_counts = collections.Counter()
role_counts = collections.Counter()
status_counts = collections.Counter()
py_counts = {}
mjs_counts = {}
source_hash_matches = True
python_count_matches = True
mjs_count_matches = True
for path in actual_paths:
    row = by_path[path]
    source = blob(path)
    source_hash_matches &= hashlib.sha256(source).hexdigest() == row['source_sha256']
    source_hash_matches &= len(source.decode('utf-8').splitlines()) == row['source_line_count']
    lang_counts[row['language']] += 1
    role_counts[row['file_role']] += 1
    status_counts[row['current_status']] += 1
    if path.endswith('.py'):
        # Deliberately parse all tracked Python sources; file_role is not a filter.
        count = py_test_definitions(source)
        py_counts[path] = count
        python_count_matches &= count == row['static_test_function_count']
        if count:
            python_count_matches &= row['file_role'] == 'test_source'
        else:
            python_count_matches &= row['file_role'] != 'test_source'
    elif path.endswith('.mjs'):
        text = source.decode('utf-8')
        has_node_test_import = bool(re.search(r"\bfrom\s+['\"]node:test['\"]", text))
        sites = len(re.findall(r'(?<![\w$])(?:test|it)\s*\(', text))
        mjs_counts[path] = sites
        mjs_count_matches &= has_node_test_import and sites == row['static_test_function_count'] and row['file_role'] == 'test_source'
    elif path.endswith('.ts'):
        text = source.decode('utf-8')
        mjs_count_matches &= 'node:test' not in text and row['static_test_function_count'] == 0 and row['file_role'] == 'shared_support_source'
        mjs_count_matches &= 'async function main()' in text and 'void main().catch' in text
        if path.endswith('/client_driver.ts'):
            mjs_count_matches &= 'client_driver.ts' in blob('tests/integration/README.md').decode('utf-8')
            mjs_count_matches &= 'client_driver.ts' in blob('tests/integration/camctl_fixtures.py').decode('utf-8')
        if path.endswith('/device_capability_browser.ts'):
            mjs_count_matches &= 'device_capability_browser.ts' in blob('tests/integration/test_device_capability_declarations.py').decode('utf-8')
    elif path.endswith('.c'):
        text = source.decode('utf-8')
        mjs_count_matches &= 'int main(' in text and 'camctl_host_init(' in text and row['static_test_function_count'] == 0 and row['file_role'] == 'shared_support_source'
        mjs_count_matches &= 'tests/integration/motor_host_driver.c' in blob('tests/integration/test_camctl_motor_notifications.py').decode('utf-8')

assert source_hash_matches
assert python_count_matches
assert mjs_count_matches
assert lang_counts == {'py': 651, 'ts': 2, 'mjs': 4, 'c': 1}, lang_counts
assert sum(py_counts.values()) == 3866, sum(py_counts.values())
assert sum(count > 0 for count in py_counts.values()) == 546
assert sum(mjs_counts.values()) == 55
assert role_counts == D['summary_counts']['tracked_source_count_by_role']
assert status_counts == D['summary_counts']['current_status_file_counts']
assert D['summary_counts']['python_static_test_function_count'] == sum(py_counts.values())
assert D['summary_counts']['python_test_module_count'] == sum(count > 0 for count in py_counts.values())
assert D['summary_counts']['mjs_static_test_registration_call_site_count'] == sum(mjs_counts.values())
assert D['summary_counts']['non_python_test_module_count'] == 4
assert D['summary_counts']['python_ast_parse_failures'] == 0
assert D['summary_counts']['current_status_file_counts']['existing_boundary_review_not_linked_in_ledger'] == 523
assert D['summary_counts']['current_status_file_counts']['support_or_helper_not_a_case'] == 108
assert D['summary_counts']['remaining_total_case_count'] is None
media = by_path['tests/integration/test_action6_segmented_media_fixtures.py']
assert media['static_test_function_count'] == 1 and media['file_role'] == 'test_source'
assert media['current_status'] == 'existing_boundary_review_not_linked_in_ledger'
assert media['confirmed_unmigrated_case']['count'] is None
assert D['scope']['static_count_definition'].find('全部651') >= 0
assert D['scope']['static_count_definition'].find('unittest.TestCase') >= 0
assert 'skipif' in D['scope']['static_count_definition']
assert sum(group['count'] for group in D['known_case_registers']['pending_groups']) == 32
assert sum(group['count'] for group in D['known_case_registers']['paused_groups']) == 16
assert D['known_case_registers']['registered_lower_bound'] == 48

archive_refs = list(D['historical_audits']) + [D['references'][k] for k in ('p3_final_audit', 'p3_baseline_handoff', 'p3_result_page_handoff')]
archive_hash_matches = True
for ref in archive_refs:
    archive_path = ref['path']
    assert ref.get('sha256_is_uncompressed') is True
    archive = W / archive_path
    assert archive.is_file()
    subprocess.run(['git', 'cat-file', '-e', f'{COMMIT}:{archive_path}'], cwd=W, check=True)
    with gzip.open(archive, 'rb') as stream:
        archive_hash_matches &= hashlib.sha256(stream.read()).hexdigest() == ref['sha256']
assert archive_hash_matches
assert '/tmp/' not in J.read_text() and '.local/' not in J.read_text()
assert D['title'] == 'camctl 集成测试重构状态清单'

md = M.read_text()
assert '`3866`个' in md and '`546`个文件' in md and '| 尚未在本清单关联既有边界评审证据的测试源 | 523 |' in md
assert '| 支持或辅助源 | 108 |' in md and '| 合计 | 658 |' in md
assert '受`skipif`控制' in md and 'unittest.TestCase' in md
assert '不代表此刻工作树的全库剩余文件或用例数量' in md
assert 'integration-test-refactor-status.json' in R.read_text() and 'integration-test-refactor-status.md' in R.read_text()
for file in (J, M, R):
    for number, line in enumerate(file.read_text().splitlines(), 1):
        assert line.rstrip() == line, (str(file), number)
subprocess.run(['git', 'diff', '--check'], cwd=W, check=True)
status = subprocess.check_output(['git', 'status', '--short'], cwd=W, text=True)
assert all(line.endswith('docs/camctl/integration-test-refactor-status.json') or line.endswith('docs/camctl/integration-test-refactor-status.md') for line in status.splitlines()), status

old_validation_path = E / 'validation-before-ast-correction.json'
current_validation_path = E / 'validation.json'
if current_validation_path.exists() and not old_validation_path.exists():
    old_validation_path.write_bytes(current_validation_path.read_bytes())
validation = {
    'snapshot_commit': COMMIT,
    'snapshot_tree': D['snapshot']['tree'],
    'git_ls_files_source_count': len(actual_paths),
    'ledger_entry_count': len(rows),
    'duplicates_or_gaps': False,
    'count_by_language': dict(lang_counts),
    'count_by_role': dict(role_counts),
    'count_by_status': dict(status_counts),
    'python_sources_parsed_independently': len(py_counts),
    'python_test_modules_with_static_definitions': sum(count > 0 for count in py_counts.values()),
    'python_static_test_function_count_recomputed': sum(py_counts.values()),
    'all_651_python_ast_counts_match_ledger': True,
    'mjs_node_test_modules_manually_confirmed': len(mjs_counts),
    'mjs_static_registration_sites_recomputed': sum(mjs_counts.values()),
    'ts_and_c_actual_entry_roles_checked': True,
    'all_658_source_sha256_match_frozen_git_blob': True,
    'status_totals_match_json': True,
    'markdown_summary_matches_json': True,
    'archive_reference_count': len(archive_refs),
    'all_uncompressed_archive_sha256_match': True,
    'formal_json_has_no_tmp_or_local_paths': True,
    'snapshot_scope_is_explicit_in_json_and_markdown': True,
    'known_pending_group_sum': 32,
    'paused_group_sum': 16,
    'registered_lower_bound': 48,
    'remaining_total_case_count': None,
    'count_correction_evidence': {
        'media_fixture': {
            'path': 'tests/integration/test_action6_segmented_media_fixtures.py',
            'line': 28,
            'skipif_line': 16,
            'parameterize_line': 20,
            'parameter_value_lines': [23, 24],
            'definition_count': 1,
        },
        'unittest_classes': {
            'path': 'tests/integration/test_database_history_sql.py',
            'classes': [
                {'name': 'DatabaseRuntimeRequirements', 'line': 18, 'test_method_count': 2},
                {'name': 'DatabaseStructure', 'line': 44, 'test_method_count': 25},
            ],
            'method_definition_count': 27,
        },
    },
    'non_python_role_evidence': [
        {'path': 'tests/integration/client_driver.ts', 'role': 'shared_support_source', 'basis': '由集成测试通过Node子进程启动；README列出命令，main()分派客户端流程。'},
        {'path': 'tests/integration/device_capability_browser.ts', 'role': 'shared_support_source', 'basis': '由test_device_capability_declarations.py启动；main()编排浏览器与客户端流程。'},
        {'path': 'tests/integration/event-transitions.test.mjs', 'role': 'test_source', 'registration_count': 15},
        {'path': 'tests/integration/report-dependencies.test.mjs', 'role': 'test_source', 'registration_count': 29},
        {'path': 'tests/integration/report-dependency-conditions.test.mjs', 'role': 'test_source', 'registration_count': 8},
        {'path': 'tests/integration/video-coverage-protocol.test.mjs', 'role': 'test_source', 'registration_count': 3},
        {'path': 'tests/integration/motor_host_driver.c', 'role': 'shared_support_source', 'basis': '由test_camctl_motor_notifications.py编译并启动；main()调用camctl_host_*公共函数。'},
    ],
    'prior_validation_failure': {
        'first_independent_review': '此前清单将 test_action6_segmented_media_fixtures.py 按支持文件角色排除，漏计一个受 skipif 控制、含两个参数值的顶层测试函数。',
        'counter_root_cause': '旧校验器仅在 file_role == test_source 时运行 AST，支持文件中的测试定义默认写成0，且未由独立全量AST校验发现。',
        'additional_counting_gap': '旧计数只纳入 Test* 命名类方法；test_database_history_sql.py 有两个直接继承 unittest.TestCase 的类，另有27个 test_* 方法。',
        'correction': '对全部651个.py源逐文件解析AST；计入模块级 test_*、Test* 类方法和直接继承 unittest.TestCase 的类方法；按AST结果重新核定测试源角色与状态数。'
    },
    'pytest_or_build_run': False,
    'production_or_test_source_changed': False,
    'docs_changed': ['docs/camctl/integration-test-refactor-status.json', 'docs/camctl/integration-test-refactor-status.md'],
    'worktree_status_before_staging': status,
}
current_validation_path.write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(validation, ensure_ascii=False, indent=2))

import json,os,subprocess,sys,time
root='/tmp/camctl-resume-20261031/copy-read-errors'; out='/tmp/camctl-resume-20261031/evidence/copy-read-errors'; label=sys.argv[1]; env=os.environ.copy(); env['PYTHONPATH']=root+'/apps/camctl/src:'+root+'/apps/camctl/tests'; argv=['/workspaces/camctl/apps/camctl/.venv311/bin/python','-m','pytest','apps/camctl/tests/integration/capture/test_input_copy.py','apps/camctl/tests/integration/capture/test_recording_start.py','-vv','--durations=0',f'--junitxml={out}/{label}.xml',f'--basetemp={out}/{label}-temp']; start=time.time()
with open(f'{out}/{label}.log','w') as log:
 p=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT); open(f'{out}/{label}-process.json','w').write(json.dumps({'pid':p.pid,'argv':argv,'cwd':root,'PYTHONPATH':env['PYTHONPATH']},indent=2));rc=p.wait()
open(f'{out}/{label}-exit.json','w').write(json.dumps({'exit':rc,'elapsed':time.time()-start},indent=2));print(label,rc,time.time()-start)

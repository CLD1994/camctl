import json,os,subprocess,time
root='/tmp/camctl-resume-20261031/bootstrap-collection-fix'; out='/tmp/camctl-resume-20261031/evidence/bootstrap-collection-fix'; env=os.environ.copy(); env['PYTHONPATH']=root+'/apps/camctl/src:'+root+'/apps/camctl/tests'; argv=['/workspaces/camctl/apps/camctl/.venv311/bin/python','-m','pytest','apps/camctl/tests/integration/bootstrap/test_binding_canceled_result_transactions.py','-vv','--durations=0',f'--junitxml={out}/result.xml',f'--basetemp={out}/temp']; start=time.time()
with open(out+'/pytest.log','w') as log:
 p=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);open(out+'/process.json','w').write(json.dumps({'argv':argv,'cwd':root,'pid':p.pid,'PYTHONPATH':env['PYTHONPATH']},indent=2));rc=p.wait()
open(out+'/exit.json','w').write(json.dumps({'exit':rc,'elapsed':time.time()-start},indent=2));print(rc,time.time()-start)

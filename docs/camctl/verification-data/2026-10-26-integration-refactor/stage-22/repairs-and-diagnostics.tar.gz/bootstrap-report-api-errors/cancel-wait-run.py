import json,os,subprocess,time
root='/tmp/camctl-resume-20261031/bootstrap-report-api-errors';out='/tmp/camctl-resume-20261031/evidence/bootstrap-report-api-errors';env=os.environ.copy();env['PYTHONPATH']=root+'/apps/camctl/src:'+root+'/apps/camctl/tests';argv=['/workspaces/camctl/apps/camctl/.venv311/bin/python','-m','pytest','apps/camctl/tests/integration/bootstrap/test_restricted_report_cancellation.py','-vv','--durations=0',f'--junitxml={out}/cancel-wait.xml',f'--basetemp={out}/cancel-wait-temp'];t=time.time()
with open(f'{out}/cancel-wait.log','w') as log:
 p=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);open(f'{out}/cancel-wait-process.json','w').write(json.dumps({'pid':p.pid,'argv':argv,'cwd':root,'PYTHONPATH':env['PYTHONPATH']},indent=2));rc=p.wait()
open(f'{out}/cancel-wait-exit.json','w').write(json.dumps({'exit':rc,'elapsed':time.time()-t},indent=2));print(rc,time.time()-t)

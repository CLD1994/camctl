import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path('/tmp/camctl-resume-20261031/bootstrap-registry-errors');out=pathlib.Path('/tmp/camctl-resume-20261031/evidence/bootstrap-registry-errors');name=sys.argv[1];py='/workspaces/camctl/apps/camctl/.venv311/bin/python';env=os.environ.copy();env['PYTHONPATH']=str(root/'apps/camctl/src')+':'+str(root/'apps/camctl/tests')
def source():
 paths=['apps/camctl/tests/integration/support/session.py','apps/camctl/tests/integration/support/bootstrap_read_cases.py','apps/camctl/tests/integration/bootstrap/conftest.py']
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
args=[py,'-m','pytest',*sys.argv[2:],'-q','--tb=short','--basetemp',str(out/(name+'-tmp')),'--junitxml',str(out/(name+'.xml'))]
meta={'argv':args,'cwd':str(root),'PYTHONPATH':env['PYTHONPATH'],'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'production_tree':subprocess.check_output(['git','rev-parse','HEAD:apps/camctl/src'],cwd=root,text=True).strip(),'before':source(),'status':subprocess.check_output(['git','status','--short'],cwd=root,text=True),'import_preflight':subprocess.check_output([py,'-c','import sys,camctl; print(sys.version); print(camctl.__file__)'],cwd=root,env=env,text=True)};start=time.monotonic()
with (out/(name+'.log')).open('w') as log:
 p=subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);meta['pid']=p.pid;(out/(name+'.json')).write_text(json.dumps(meta,indent=2));print('PID',p.pid,flush=True);meta['exit_code']=p.wait()
meta.update(wall_seconds=time.monotonic()-start,after=source());(out/(name+'.json')).write_text(json.dumps(meta,indent=2));print('EXIT',meta['exit_code'],'WALL',meta['wall_seconds'],flush=True)

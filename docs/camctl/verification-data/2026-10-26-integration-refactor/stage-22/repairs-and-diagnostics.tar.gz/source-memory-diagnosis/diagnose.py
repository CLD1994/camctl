import ast
import asyncio
import gc
import json
import os
from pathlib import Path
import tempfile
import time
import tracemalloc

from integration.outputs.test_source_resolution_batches import _real_environment
from camctl.contracts.values import new_operation_key
from camctl.persistence.models import DbOutcomeKind
from camctl.persistence.runtime import OwnedConnection
from camctl.persistence.repositories import outputs
from camctl.persistence import fact_reads

source = Path('apps/camctl/tests/integration/outputs/test_source_resolution_batches.py')
module = ast.parse(source.read_text())
test = next(node for node in module.body if isinstance(node, ast.AsyncFunctionDef) and node.name == 'test_source_write_and_original_key_keep_bounded_residency')
loop = next(node for node in ast.walk(test) if isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == 'count')
classes = [node for node in loop.body if isinstance(node, ast.ClassDef) and node.name in ('Cursor', 'Measured')]
assert [node.name for node in classes] == ['Cursor', 'Measured']
classes_code = compile(ast.fix_missing_locations(ast.Module(body=classes, type_ignores=[])), str(source), 'exec')

original_remember = fact_reads._remember
original_discard = fact_reads._Facts.discard
metrics = None

def remember(state, key, value):
    original_remember(state, key, value)
    if metrics is not None and state is not None:
        metrics['remember_calls'] += 1
        metrics['max_entries'] = max(metrics['max_entries'], len(state.entries))
        metrics['max_estimated_bytes'] = max(metrics['max_estimated_bytes'], state.retained_bytes)

def discard(state):
    if metrics is not None:
        metrics['discard_calls'] += 1
        metrics['max_entries'] = max(metrics['max_entries'], len(state.entries))
        metrics['max_estimated_bytes'] = max(metrics['max_estimated_bytes'], state.retained_bytes)
    original_discard(state)
    if metrics is not None:
        metrics['discard_not_empty'] += int(bool(state.entries) or state.retained_bytes != 0 or state.active)

fact_reads._remember = remember
fact_reads._Facts.discard = discard

def measure(label, repo, request, key, owned):
    global metrics
    gc.collect()
    metrics = {'remember_calls': 0, 'max_entries': 0, 'max_estimated_bytes': 0, 'discard_calls': 0, 'discard_not_empty': 0}
    tracemalloc.start()
    tracemalloc.reset_peak()
    start = time.perf_counter()
    result = repo.resolve_sources(request, key, owned)
    elapsed = time.perf_counter() - start
    current, peak = tracemalloc.get_traced_memory()
    gc.collect()
    after_gc = tracemalloc.get_traced_memory()[0]
    tracemalloc.stop()
    scalar = metrics
    metrics = None
    assert result.kind is DbOutcomeKind.COMPLETED, result.error
    assert fact_reads._CURRENT.get() is None
    return result, {'stage': label, 'seconds': elapsed, 'peak': peak, 'returned_current': current, 'after_gc_current': after_gc, 'fact_cache_diagnostic': scalar}

async def main():
    print(json.dumps({'pid':os.getpid(), 'cwd':str(Path.cwd()), 'order':'write measured, reuse raw, reuse measured', 'instrumentation':'private _remember/_Facts.discard wrappers count scalars only; raw and measured both instrumented; tracked values include wrappers', 'source':'AST copied from test_source_write_and_original_key_keep_bounded_residency', 'python':os.sys.version}), flush=True)
    with tempfile.TemporaryDirectory(prefix='camctl-source-diagnosis-') as root:
        for count in (20, 200, 600):
            directory = Path(root) / str(count)
            directory.mkdir()
            _, owned, request = await _real_environment(directory, captures=count)
            db = owned.connection
            try:
                stats = {'max_fetch':0,'fetched':0,'sql_calls':0,'group_checks':0,'body_rows':0,'first_body_limit':None}
                txn = db.execute('SELECT MAX(id)+1 FROM history_transactions').fetchone()[0]
                ns = {'__package__':'integration.outputs','db':db,'txn':txn,'stats':stats}
                exec(classes_code, ns)
                measured = OwnedConnection(ns['Measured'](), None)
                repository = outputs.OutputsRepository(4)
                key = new_operation_key()
                written, first = measure('write_measured', repository, request, key, measured)
                assert written.value.member_count == count
                before = db.execute('SELECT COUNT(*), MAX(id) FROM history_events').fetchone()
                before_tx = db.execute('SELECT COUNT(*), MAX(id) FROM history_transactions').fetchone()
                raw_result, raw = measure('reuse_raw', repository, request, key, owned)
                raw_history = db.execute('SELECT COUNT(*), MAX(id) FROM history_events').fetchone()
                raw_tx = db.execute('SELECT COUNT(*), MAX(id) FROM history_transactions').fetchone()
                measured_result, observed = measure('reuse_measured', repository, request, key, measured)
                assert db.execute('SELECT COUNT(*), MAX(id) FROM history_events').fetchone() == raw_history == before
                assert db.execute('SELECT COUNT(*), MAX(id) FROM history_transactions').fetchone() == raw_tx == before_tx
                assert written.value == raw_result.value == measured_result.value
                assert all(item['fact_cache_diagnostic']['discard_not_empty'] == 0 for item in (first,raw,observed))
                assert all(item['fact_cache_diagnostic']['discard_calls'] > 0 for item in (first,raw,observed))
                print(json.dumps({'count':count,'batch_size':4,'event_count_and_max_after_write':before,'transaction_count_and_max_after_write':before_tx,'equal_results':True,'no_new_history':True,'measures':[first,raw,observed],'measured_stats':{k:v for k,v in stats.items() if k != 'original_id_query'}}, ensure_ascii=False), flush=True)
            finally:
                db.close()

asyncio.run(main())

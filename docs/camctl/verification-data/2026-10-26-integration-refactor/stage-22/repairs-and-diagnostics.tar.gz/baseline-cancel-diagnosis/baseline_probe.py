"""Temporary read-only pytest diagnostic; no production or test edits."""
import asyncio
import json
import pathlib
import sys
import pytest

OUT = pathlib.Path('/tmp/camctl-resume-20261031/evidence/baseline-cancel-diagnosis/probe.jsonl')
NAMES = {'prepare_segment_baseline', 'advance_baseline_read', 'resume_baseline_read_call', '_finish_canceled_capture', 'abort_unstarted_baseline_read', 'resume_baseline_read_save'}
events = []

def task_state(task):
    if task is None:
        return None
    if not isinstance(task, asyncio.Task):
        return type(task).__name__
    return {'id': id(task), 'done': task.done(), 'cancelled': task.cancelled(), 'cancelling': task.cancelling()}

def owner_state(owner):
    if owner is None:
        return None
    return {'id': id(owner), 'task': task_state(getattr(owner, 'task', None)),
            'locally_created': getattr(owner, 'locally_created', None),
            'aborted_before_call': getattr(owner, 'aborted_before_call', None),
            'intent_view': getattr(getattr(owner, 'intent_view', None), 'state', None).__str__() if getattr(owner, 'intent_view', None) is not None else None,
            'return_request': getattr(owner, 'return_request', None) is not None,
            'unconfirmed_request': getattr(owner, 'unconfirmed_request', None) is not None,
            'result': getattr(owner, 'result', None) is not None,
            'settlement_clock_attempted': getattr(owner, 'settlement_clock_attempted', None),
            'pending_save': type(getattr(getattr(owner, 'saves', None), 'pending', None).request).__name__ if getattr(getattr(owner, 'saves', None), 'pending', None) is not None else None}

def snapshot(frame, event):
    data = {'event': event, 'function': frame.f_code.co_name, 'file': frame.f_code.co_filename.rsplit('/', 1)[-1], 'line': frame.f_lineno}
    f = frame.f_locals
    owner = f.get('owner')
    if owner is not None:
        data['owner'] = owner_state(owner)
    pending = f.get('pending')
    if pending is not None and hasattr(pending, 'read_owner'):
        data['pending'] = {'id': id(pending), 'in_call': getattr(pending, 'in_call', None), 'read_owner': owner_state(pending.read_owner)}
    runtime = f.get('runtime')
    if runtime is not None and hasattr(runtime, 'pending_baselines'):
        data['runtime_map'] = {str(k): {'pending_id': id(v), 'in_call': getattr(v, 'in_call', None), 'read_owner': owner_state(getattr(v, 'read_owner', None))} for k,v in runtime.pending_baselines.items()}
    return data

def profile(frame, event, arg):
    if event in ('call', 'return') and frame.f_code.co_name in NAMES and len(events) < 100:
        try:
            events.append(snapshot(frame, event))
        except Exception as error:
            events.append({'probe_error': repr(error)})

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    if 'test_baseline_read_owner.py' not in item.nodeid:
        yield
        return
    events.clear()
    old = sys.getprofile()
    sys.setprofile(profile)
    try:
        yield
    finally:
        sys.setprofile(old)

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    if call.when != 'call' or 'test_baseline_read_owner.py' not in item.nodeid:
        return
    data = {'nodeid': item.nodeid, 'outcome': report.outcome, 'events': events.copy()}
    if call.excinfo is not None:
        frames = list(call.excinfo.traceback)
        for entry in reversed(frames):
            if entry.frame.code.name.startswith('test_') and 'test_baseline_read_owner.py' in str(entry.frame.code.path):
                f = entry.frame.f_locals
                data['test_frame'] = {'line': entry.lineno, 'outer_task': task_state(f.get('task')),
                    'runtime_map': {str(k): {'pending_id': id(v), 'in_call': getattr(v, 'in_call', None), 'read_owner': owner_state(getattr(v, 'read_owner', None))} for k,v in getattr(f.get('runtime'), 'pending_baselines', {}).items()},
                    'resumed_map': {str(k): {'pending_id': id(v), 'in_call': getattr(v, 'in_call', None), 'read_owner': owner_state(getattr(v, 'read_owner', None))} for k,v in getattr(f.get('resumed'), 'pending_baselines', {}).items()}}
                break
    with OUT.open('a') as stream:
        stream.write(json.dumps(data, ensure_ascii=False, default=str) + '\n')

#!/bin/sh
exec "/tmp/camctl-bootstrap-20261031-e0b511bb/tasks/001-camctl-bootstrap/source/apps/camctl/.venv311/bin/python" "/tmp/camctl-bootstrap-20261031-e0b511bb/tasks/001-camctl-bootstrap/tmp/pytest/test_internal_held_end_reliabl1/read-world-probe.py" "$@"

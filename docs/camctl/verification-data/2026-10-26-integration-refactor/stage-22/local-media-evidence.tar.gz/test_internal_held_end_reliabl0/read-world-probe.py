from pathlib import Path
import json
with Path('/tmp/camctl-bootstrap-20261031-e0b511bb/tasks/001-camctl-bootstrap/tmp/pytest/test_internal_held_end_reliabl0/media-tools.log').open('a') as log: log.write('probe\n')
print(json.dumps({'streams': [{'codec_type': 'video'}], 'format': {'duration': '61'}}))

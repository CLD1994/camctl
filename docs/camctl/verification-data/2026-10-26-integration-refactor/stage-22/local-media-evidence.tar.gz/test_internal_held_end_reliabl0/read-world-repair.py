from pathlib import Path
import shutil,sys
with Path('/tmp/camctl-bootstrap-20261031-e0b511bb/tasks/001-camctl-bootstrap/tmp/pytest/test_internal_held_end_reliabl0/media-tools.log').open('a') as log: log.write('repair\n')
shutil.copyfile(sys.argv[sys.argv.index('-i')+1], sys.argv[-1])

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/tmp/camctl-resume-20261030/consumer-preparation-ports')
out = Path(__file__).resolve().parent
python = '/workspaces/camctl/apps/camctl/.venv311/bin/python'
env = os.environ.copy()
env['PYTHONPATH'] = f'{root}/apps/camctl/src:{root}/apps/camctl/tests'

def source_manifest():
    names = subprocess.check_output(
        ['git', 'ls-files', '-z', 'apps/camctl/src', 'apps/camctl/tests', 'scripts'], cwd=root
    ).split(b'\0')
    return {os.fsdecode(name): hashlib.sha256((root / os.fsdecode(name)).read_bytes()).hexdigest()
            for name in names if name and (root / os.fsdecode(name)).is_file()}

subprocess.run([python, 'apps/camctl/scripts/sync_resources.py'], cwd=root, env=env, check=True)
preflight = subprocess.run([python, '-c',
    'import json,sys,camctl; import integration.capture.result_consumer_fixtures as f; '
    'print(json.dumps({"python":sys.version,"camctl":camctl.__file__,"fixture":f.__file__}))'],
    cwd=root, env=env, capture_output=True, text=True, check=True)
(out / 'preflight-import.json').write_text(preflight.stdout)
before = source_manifest()
(out / 'source-manifest.json').write_text(json.dumps(before, indent=2))
command = [python, 'scripts/run-memory-budget.py', '--camctl-memory-limit', '2GiB',
    '--evidence-dir', str(out / 'delegation'), '--', python, '-m', 'pytest',
    'apps/camctl/tests/integration/persistence/test_segment_transaction_batches.py::test_fixed_batch_write_and_verification_have_bounded_residency',
    '-q', '--basetemp', str(out / 'temp'), '--junitxml', str(out / 'results.xml')]
started = time.monotonic()
with (out / 'pytest.log').open('x') as log:
    process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt = {'pid': process.pid, 'command': command, 'cwd': str(root),
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
        'dirty': subprocess.check_output(['git', 'status', '--short'], cwd=root, text=True),
        'source_manifest_sha256': hashlib.sha256((out / 'source-manifest.json').read_bytes()).hexdigest(),
        'preflight_scope': 'Actual imports in independent interpreter; not pytest runtime instrumentation',
        'status': 'running'}
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps(receipt), flush=True)
    code = process.wait()
after = source_manifest()
receipt.update(status='finished', exit_code=code, wall_seconds=time.monotonic()-started,
    changed_sources=[name for name in before.keys() | after.keys() if before.get(name) != after.get(name)])
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt), flush=True)
sys.exit(code)

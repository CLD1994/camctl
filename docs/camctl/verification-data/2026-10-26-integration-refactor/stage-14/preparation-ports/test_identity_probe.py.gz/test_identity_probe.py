import os
from types import SimpleNamespace
import pytest
from integration.capture import result_consumer_fixtures as module

@pytest.mark.asyncio
async def test_configured_repository_identity_diagnostic(monkeypatch):
    repository=object()
    runtime=SimpleNamespace(capture=repository)
    async def handler(action, current):
        assert action==42 and current is runtime
    monkeypatch.setattr(module,'capture_handler',lambda name: handler)
    await module._prepare_through_handler(runtime,42,'identity-probe',None)
    preserved=runtime.capture is repository
    print('REPOSITORY_IDENTITY_PRESERVED',preserved)
    assert preserved == (os.environ.get('EXPECT_PRESERVED') == '1')

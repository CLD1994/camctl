import hashlib, json, os, subprocess, sys, time
from pathlib import Path
root = Path('/tmp/camctl-resume-20261030/consumer-preparation-baseline')
out = Path('/tmp/camctl-resume-20261030/evidence-preparation-ports')
name, target = sys.argv[1:]
python = '/workspaces/camctl/apps/camctl/.venv311/bin/python'
args = [python, '-m', 'pytest', target, '-q', '-s', '--basetemp', str(out / (name + '-tmp')), '--junitxml', str(out / (name + '.xml'))]
env = os.environ.copy(); env['PYTHONPATH'] = f'{root}/apps/camctl/src:{root}/apps/camctl/tests'
def fingerprint():
    paths = subprocess.check_output(['git', 'ls-files', '-z', 'apps/camctl/src', 'apps/camctl/tests'], cwd=root).split(b'\0')
    h = hashlib.sha256()
    for raw in paths:
        if raw:
            p = root / os.fsdecode(raw)
            h.update(raw + b'\0')
            h.update(hashlib.sha256(p.read_bytes()).digest() if p.is_file() else b'missing')
    return h.hexdigest()
source = fingerprint(); start = time.monotonic()
with (out / (name + '.log')).open('w') as log:
    p = subprocess.Popen(args, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    meta = {'pid':p.pid, 'argv':args, 'cwd':str(root), 'git_head':subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip(), 'source_sha256_before':source, 'import_path':str(root/'apps/camctl/src/camctl/__init__.py'), 'python':'3.11.17'}
    (out/(name+'.json')).write_text(json.dumps(meta, indent=2)); print(json.dumps(meta), flush=True)
    code = p.wait(); meta.update(exit_code=code, wall_seconds=time.monotonic()-start, source_sha256_after=fingerprint())
    (out/(name+'.json')).write_text(json.dumps(meta, indent=2)); print(json.dumps(meta),flush=True)

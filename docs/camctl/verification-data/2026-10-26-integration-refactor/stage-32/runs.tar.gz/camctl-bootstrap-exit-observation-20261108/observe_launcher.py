import importlib.util, json, os, sys, time
from pathlib import Path
root=Path('/opt/devcontainer/.codex/worktrees/de38/camctl')
sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('budget_launcher',root/'scripts/run-memory-budget.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
original=module._settle_command_group
def snapshot(pgid):
    rows=[]
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            text=path.read_text(); fields=text[text.rindex(')')+2:].split()
            if int(fields[2])!=pgid: continue
            rows.append({'pid':int(path.parent.name),'state':fields[0],'ppid':int(fields[1]),'pgid':pgid,'command':(path.parent/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')})
        except (OSError,ValueError): pass
    return rows
def observe(process,evidence):
    out=Path('/tmp/camctl-bootstrap-exit-observation-20261108/group-exit.jsonl')
    with out.open('a') as f:f.write(json.dumps({'phase':'before','time':time.time(),'pgid':process.pid,'processes':snapshot(process.pid)})+'\n')
    original(process,evidence)
    with out.open('a') as f:f.write(json.dumps({'phase':'after','time':time.time(),'pgid':process.pid,'processes':snapshot(process.pid)})+'\n')
module._settle_command_group=observe
raise SystemExit(module.main())

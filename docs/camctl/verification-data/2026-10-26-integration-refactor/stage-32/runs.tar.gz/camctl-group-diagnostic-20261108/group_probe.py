import json, os
from pathlib import Path

def snapshot(stage):
    group=os.getpgrp(); rows=[]
    for path in Path('/proc').glob('[0-9]*'):
        try:
            stat=(path/'stat').read_text(); fields=stat.rsplit(') ',1)[1].split()
            if int(fields[2])!=group:continue
            rows.append(dict(pid=int(path.name),name=stat.split('(',1)[1].rsplit(')',1)[0],state=fields[0],ppid=int(fields[1]),pgid=int(fields[2]),command=(path/'cmdline').read_bytes().decode(errors='replace').replace('\0',' ')))
        except (OSError,ValueError):pass
    with Path('/tmp/camctl-group-diagnostic-20261108/processes.jsonl').open('a') as output:
        output.write(json.dumps(dict(stage=stage,processes=rows))+'\n')

def pytest_sessionfinish(session,exitstatus):snapshot('sessionfinish')
def pytest_unconfigure(config):snapshot('unconfigure')
